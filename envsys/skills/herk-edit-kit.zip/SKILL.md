﻿---
name: herk-edit-kit
description: Nate Herk's video-editing kit (HyperFrames) - edit videos, reels, YouTube Shorts with transcript-driven cuts, storytelling, and 406 motion-graphics cards. Use when the user wants to edit a recording, cut silences/mistakes, make a reel or Short, or build motion graphics/animations.
---

# Herk Edit Kit

Nate Herk's video-editing kit (HyperFrames). See `README.md` and `CLAUDE.md` for full usage.
Sub-skills in `.claude/skills/` and `.agents/skills/`: cut-mistakes, cut-silences, edit-video, gsap, hyperframes, hyperframes-cli, hyperframes-registry, hyperframes-video-beats, make-a-video, motion-showreel, patch-reel, rate-reel, render-card, short-form, transcribe-video, web-design.
Scripts in `scripts/`, styles in `style-library/` and `style-templates/`.