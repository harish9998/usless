# cloudflare-tunnel
Qoder & OpenCode skill: use `cloudflared tunnel` to expose a local port and transfer files between your PC and the RDP runner (or any two machines).

## Quick start
1. Start a tunnel: `cloudflared tunnel --url http://localhost:8080`
2. Cloudflare gives you a URL like `https://abc123.trycloudflare.com`.
3. From another machine, `curl` or `wget`/`scp` that URL to transfer files.

## RDP‑use example
```powershell
# On the RDP runner, in an RDP terminal:
cloudflared tunnel --url http://localhost:5000   # starts a tunnel; keeps running in background
# Then from your own PC:
curl -O https://<sub>.trycloudflare.com/file.txt
```