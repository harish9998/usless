# Audio Workflow Automation — Project Specification

**Document type:** Portable project specification for AI coding agents  
**Status:** Idea / implementation brief  
**Target platform:** Windows 11  
**Primary generation website:** https://freevoicegen.com/

## 1. Objective

Build a lightweight local application that turns text into a finished speech audio file through one automated workflow:

1. Generate speech using FreeVoiceGen.
2. Download the complete generated audio.
3. Detect and remove unwanted silence.
4. Increase speech speed to at least 1.10× while preserving natural pitch.
5. Save and let the user preview/download the final audio.

The application must be genuinely usable. Do not deliver mock buttons, placeholder processing, or a proposal instead of working functionality.

## 2. Scope — exactly three core functions

### Function A: Text-to-speech generation

- Use FreeVoiceGen as the primary generation service: https://freevoicegen.com/
- Provide a text input area.
- Where the website supports it, allow the user to select a voice and available generation settings.
- Submit the text, wait for generation to finish, and download the complete resulting audio file.
- Preserve the original downloaded file unchanged.
- Inspect the live website before implementing automation. Do not assume that controls, APIs, selectors, or endpoints exist.
- Prefer supported website functionality. Browser automation (for example, Playwright) may be used where appropriate.
- Do not bypass CAPTCHA, authentication, access controls, rate limits, or other website restrictions.
- If reliable automation is unavailable or the website changes, provide a clear manual fallback: the user downloads the generated file from the website and imports it into the application.

### Function B: Silence removal

- Automatically pass each downloaded/imported audio file into silence processing.
- Detect unwanted silence at the beginning, between speech segments, and at the end.
- Remove unwanted silent regions without cutting words, consonants, breaths that are important for intelligibility, or speech endings.
- Preserve configurable short natural pauses so the result does not sound rushed or unnaturally joined.
- Use FFmpeg or another reliable local audio-processing library.
- Make detection threshold and minimum silence duration configurable internally or through a simple advanced-settings section. Provide sensible defaults.
- Save an intermediate processed file; never overwrite the original.

### Function C: Speech speed adjustment

- Automatically run after silence removal.
- Default playback speed: **1.10×**.
- Minimum permitted speed: **1.10×**. Do not allow a setting below 1.10×.
- Allow the user to choose a higher speed if practical.
- Preserve natural pitch; do not simply raise pitch by changing sample rate.
- Use FFmpeg `atempo` or an equivalent pitch-preserving time-stretch method.
- Apply the speed adjustment to the entire silence-processed recording.

## 3. Required end-to-end workflow

```text
User enters text
       |
       v
FreeVoiceGen generates speech
       |
       v
Download complete original audio
       |
       v
Detect and remove unwanted silence
       |
       v
Increase speed (minimum 1.10x, pitch preserved)
       |
       v
Save final audio
       |
       v
Preview and download final file
```

The user should not need to manually move files between processing stages. The manual fallback applies only to obtaining the source audio from FreeVoiceGen when browser automation is unavailable.

## 4. Minimal user interface

Include only:

- Text input for speech generation.
- Voice/settings controls that reflect options actually available on FreeVoiceGen.
- **Generate Audio** action.
- Clear status for generation, download, silence removal, speed adjustment, and completion.
- Final audio player/preview.
- **Download Final Audio** action.
- Clear display of original and final filenames.
- A way to import an existing audio file when generation automation is unavailable.

Avoid unrelated features such as user accounts, analytics dashboards, chatbots, cloud storage, collaboration, or elaborate project management.

## 5. Technical preferences and constraints

- Operating system: Windows 11.
- Prefer a lightweight local-first application.
- Preferred backend: Python.
- Preferred audio engine: FFmpeg.
- Preferred browser automation: Playwright, only if the website's actual behavior supports it.
- Support common formats where feasible: MP3, WAV, and M4A.
- No paid APIs or subscriptions as a requirement.
- No GPU requirement; audio processing should run on CPU.
- Keep dependencies minimal and document them.
- Use safe temporary-file handling and clean up temporary files after successful processing, while retaining the original and final outputs.

Suggested folder structure:

```text
AudioWorkflow/
  app/                 # application source code
  input/               # manually imported audio, if needed
  original/             # unchanged downloaded source audio
  temporary/            # intermediate files; safe to clean
  output/               # final processed audio
  logs/                 # useful error and diagnostic logs
  requirements.txt
  run.bat
  README.md
```

## 6. Reliability and error handling

Handle at least these cases:

- FreeVoiceGen is unavailable or its page structure changes.
- Generation takes longer than expected or fails.
- Browser automation cannot download the file.
- A download is incomplete or has an unsupported format.
- FFmpeg is missing or cannot process the file.
- Audio contains little or no silence.
- Audio is already at or above the selected speed, where speed metadata/processing makes that relevant.
- Processing is interrupted or the application closes unexpectedly.
- Output filename already exists.

Show actionable errors. Never label a file as successfully processed unless processing and validation have completed.

## 7. Acceptance tests — definition of done

The application is complete only when these tests pass:

1. The user can enter text and generate speech through the real FreeVoiceGen workflow when the website permits automation.
2. The complete generated audio can be downloaded and saved unchanged as the original.
3. If generation automation is blocked, the user can import the manually downloaded audio and continue.
4. Silence at the start, middle, and end is reduced according to the configured settings.
5. Speech and word boundaries are not audibly clipped in representative test files.
6. The final speed is never below 1.10× and pitch remains reasonably natural.
7. The final file plays correctly and can be downloaded.
8. The original file remains unchanged.
9. The workflow displays accurate status and handles failures without pretending success.
10. Installation and launch instructions work on a clean Windows 11 setup with the documented prerequisites.

Test with both generated sample speech and audio containing different pause lengths. Listen to the output; numerical silence detection alone is not sufficient validation.

## 8. Instructions to the AI coding agent

Read this entire specification before making changes. Then:

1. Inspect the existing project directory and machine environment before creating or overwriting files.
2. Inspect the current FreeVoiceGen website and determine what can be automated legitimately and reliably.
3. State any material limitations briefly, then choose the simplest architecture that meets the requirements.
4. Implement the full workflow, including the manual audio-import fallback.
5. Run the application and execute the acceptance tests. Fix issues rather than merely describing them.
6. Provide the exact setup commands, prerequisites, launch instructions, and known limitations.
7. Do not expand the scope beyond the three core functions.

**Priority order:** working end-to-end workflow > reliability > audio quality > simple interface > code elegance. Avoid overengineering.
