---
name: audio-workflow
description: Text-to-speech audio generation and post-processing workflow. Use whenever the user wants to generate speech/voice audio from text, use FreeVoiceGen, remove silence from audio, or speed up speech (minimum 1.10x, pitch preserved). Covers TTS via https://freevoicegen.com/, download original, silence removal, and FFmpeg atempo speed adjustment. Triggers: "generate voice/audio", "text to speech", "TTS", "remove silence from audio", "speed up speech", "make audio from text".
---

# Audio Workflow (text-to-speech + cleanup)

Turn text into a finished speech audio file through one automated, local-first workflow. Full spec: `references/PROJECT_SPEC.md`.

## The 3 core functions (do not expand scope)
1. **TTS generation** — Use FreeVoiceGen (https://freevoicegen.com/) as primary service. Inspect the live site before automating; do not assume selectors/APIs exist. Use Playwright only if the site's real behavior supports it. **Never bypass CAPTCHA/auth/rate limits.** If automation is unavailable or the site changes, use the manual fallback: user downloads the audio from the site, then imports it.
2. **Silence removal** — Detect + remove unwanted silence at start, between speech, and end. Keep short natural pauses; never clip words/consonants/breaths/endings. Use FFmpeg or reliable local audio lib. Configurable threshold + min silence duration (sensible defaults). Save intermediate file; never overwrite the original.
3. **Speed adjustment** — After silence removal. Default 1.10x, **minimum 1.10x** (never below), allow higher. Preserve pitch via FFmpeg `atempo` (not sample-rate changes). Apply to whole processed recording.

## End-to-end flow
text → FreeVoiceGen → download original (unchanged) → remove silence → speed >=1.10x (pitch preserved) → save final → preview/download. User never moves files manually between stages (only the source-download fallback is manual).

## Folder structure (relative to work dir)
```
AudioWorkflow/
  app/          # source code
  input/        # manually imported audio (fallback)
  original/     # unchanged downloaded source
  temporary/    # intermediate files (safe to clean)
  output/       # final processed audio
  logs/         # errors/diagnostics
  requirements.txt, run.bat, README.md
```

## FFmpeg recipes (audio engine, CPU only)
```powershell
# Silence removal (strip silence >0.5s at -35dB, keep 0.25s padding)
ffmpeg -i original.mp3 -af "silenceremove=start_periods=1:start_duration=0.5:start_threshold=-35dB:stop_periods=-1:stop_duration=0.5:stop_threshold=-35dB" temporary/clean.mp3
# Speed 1.10x, pitch preserved (atempo range 0.5-2.0; chain for higher)
ffmpeg -i temporary/clean.mp3 -filter:a "atempo=1.10" output/final.mp3
# For >2x, chain: atempo=2.0,atempo=1.1 etc.
```

## Reliability rules
- Never label success unless processing + validation completed. Handle: site unavailable/changed, slow/failed generation, failed download, incomplete/unsupported file, FFmpeg missing, little/no silence, already fast enough, interruption, existing output filename. Show actionable errors.
- Support MP3, WAV, M4A where feasible. Python backend preferred. Minimal deps. No paid APIs/subscription, no GPU requirement.
- Safe temp-file handling; clean temp after success, retain original + final.

## Acceptance checks (definition of done)
1 text→speech via real FreeVoiceGen when automatable; 2 complete download saved unchanged as original; 3 manual import fallback works; 4 start/middle/end silence reduced; 5 no audible clipping of words; 6 final speed >=1.10x with natural pitch (listen, not just numbers); 7 final plays + downloadable; 8 original unchanged; 9 accurate status + honest failures; 10 clean-Windows install/launch works.

## Priority
working end-to-end workflow > reliability > audio quality > simple interface > code elegance. Avoid overengineering.
