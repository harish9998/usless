---
name: roblox-game-design
description: >
  Roblox game design document generator. Produces complete GDD with core loop,
  progression, monetization, retention, and social features for Roblox games.
  Trigger: "design roblox game", "roblox game concept",
  "create game design", "roblox GDD",
  "roblox game mechanics", "design document"
---

# Roblox Game Design Skill

## Input
Genre, target audience, key mechanic, or trend data

## Process
1. Analyze the target genre and audience
2. Design core gameplay loop (3-5 steps)
3. Plan progression system (levels, areas, prestige)
4. Design monetization (gamepasses, products, battle pass)
5. Plan retention features (daily rewards, events, social)
6. Estimate scope (complexity, assets, timeline)

## Output Format
```markdown
## Game Design Document: [Name]

### Elevator Pitch

### Core Loop
1. [Action] → 2. [Reward] → 3. [Upgrade] → 4. [Repeat]

### Progression
- Levels/Areas:
- Unlock gates:
- Prestige system:

### Monetization
- Gamepasses:
- Developer Products:
- Battle Pass:
- Premium items:

### Retention
- Daily rewards:
- Streaks:
- Events:
- Social features:
- Notifications:

### Technical Scope
- Complexity (1-10):
- Scripts needed:
- Assets needed:
- UI screens:
- Estimated build time:

### Target Audience
- Age range:
- Play session length:
- Platform:
```
