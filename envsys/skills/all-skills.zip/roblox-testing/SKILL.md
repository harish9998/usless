---
name: roblox-testing
description: >
  Roblox game testing and quality analysis. Checks FPS, memory usage, common
  exploits, economy balance, and retention leaks. Provides actionable fixes.
  Trigger: "test roblox game", "roblox exploit check",
  "roblox optimization", "roblox balance",
  "check roblox game", "roblox QA"
---

# Roblox Testing Skill

## Analysis Areas

### Performance
- FPS check (<30 FPS on mid-range = issue)
- Memory usage (>500MB = leak risk)
- Network traffic (excessive remote calls)
- Part count (too many = lag)
- StreamingEnabled usage

### Security
- Remote event filtering (no filtering = exploit)
- DataStore key exposure
- Server authority (all transactions server-side?)
- Anti-exploit checks (teleport, speed, noclip)

### Economy
- Currency inflation risk
- Progression pacing (too fast/slow)
- Premium vs free balance
- Grind walls (if too high = churn)

### Retention
- Tutorial clarity
- First 5-minute engagement
- Daily reward appeal
- Social feature adoption
- Event frequency

### Output Format
```markdown
## Game Audit

### Issues Found
| Area | Severity | Issue | Fix |
|------|----------|-------|-----|

### Performance Score: /10
### Security Score: /10
### Economy Score: /10
### Retention Score: /10

### Priority Fixes
1. [Critical] -
2. [High] -
3. [Medium] -
```
