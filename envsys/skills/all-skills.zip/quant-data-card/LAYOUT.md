# LAYOUT — quant-data-card (1920x1080 canvas)

Derived from ASSETS/reference_frames. [INTERPRETED high].

## Fixed HUD zones (every data frame)

- **Counter chip**: top-center, y ≈ 20-50px.
- **Param tag**: top-right, y ≈ 20-50px.
- **Citation bar**: bottom-left, y ≈ 1030-1060px.
- **Watermark**: bottom-right, y ≈ 1030-1060px.
- Nothing else may occupy the HUD bands.

## Content zones per segment type

| Segment | Composition |
|---|---|
| Hook | Hero numeral centered y≈35-50%, sub-line below w/ thin rule, threat labels row y≈75% |
| Data card | Card 45-60% width, left-of-center or center, tilt ≤3°, header row top |
| Comparison | Card left (55-60% w) + punch card right (30% w); bars inside card |
| Time series | Header top-left; bar chart full-width lower half; callout card bottom-right overlapping chart |
| Table | Header + assumption line top-left; 4-6 rows centered-left; punch card right edge |
| Verdict | Two full-width bars stacked (y≈35% / 55%); verdict chips stacked below (y≈75%+) |
| Outro | All-center: gold statement y≈35%, white sub y≈60%, disclaimer y≈85%, tagline y≈92% |

## Density discipline

- Max ONE card cluster + ONE punch card visible at once.
- Data rows visible at once: ≤4 (reference: CPI table shows 4 rows).
- Negative space ≥40% of frame — the dark canvas is part of the design.
