# EDITING RULES — quant-data-card

## Canvas model

1. ONE continuous canvas per episode. Plan segment STATES, not shots.
   [MEASURED: 1 hard cut / 103 s max]
2. Transitions between states: fade + slide/scale/rotate (cards may enter
   tilted ~3° and settle). No hard cuts except optional black open/close.
3. Segment length 10-15 s; 6-8 data segments + open + outro; total 95-110 s.

## HUD (non-negotiable)

4. Decay-counter chip top-center ticks continuously and is bound to the
   episode's central numeric claim. Never hidden except black open/close.
5. Param tag top-right; citation bottom-left; watermark bottom-right —
   present in every data frame.

## Data integrity

6. Every number on screen maps to a cited source (citation bar, [S1]..[Sn]).
7. Estimates/assumptions carry the `ILLUSTRATIVE` tag inline.
8. Color polarity is semantic: gold hero, cyan context, red negative,
   blue comparison bars, green favorable verdict. Never decorative.

## Hierarchy per segment

9. One segment = header (bold caps) + ONE card + ONE takeaway.
10. Takeaway punch card: two lines — white observation + gold implication.
    Lowercase, declarative, no exclamation marks, ≤8 words per line.
11. One hero numeral per segment; everything else ≤3 data rows visible.

## Outro

12. ≥8 s hold: gold two-line statement + white sub-statement + gray
    disclaimer ("Educational content · not investment advice") + gold
    channel tagline.
