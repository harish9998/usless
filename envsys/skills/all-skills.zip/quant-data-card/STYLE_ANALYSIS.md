# STYLE ANALYSIS — Introvert Quant "data-card" style

Source: `IQ_SHORT_100_today_vs_tomorrow_v2_cinematic.mp4` (channel's own code-built
episode, 102.93 s, 1920x1080@30). Evidence: 17 segment frames
(`ASSETS/reference_frames/seg_01..17`) + contact sheet of 12 QA stills + palette.
Tags: [MEASURED] = ffmpeg · [INTERPRETED] = visual + confidence.

## 1. Editing model [MEASURED]

- Scene detection: **0 cuts at threshold 0.25, 1 cut at 0.10** → the episode
  is ONE continuous animated canvas. Cards and states morph via fades/slides/
  rotations; no shot grammar, no camera.
- Segment rhythm [INTERPRETED from 6 s sampling]: black open (0-5 s) →
  decay-counter hook → CPI basket card (tilted, rotating in) → CPI table +
  rural/urban bars → decade bar chart → ₹100-becomes table → FD-vs-inflation
  verdict bars + bordered verdict chips → gold statement outro (≥8 s).

## 2. The HUD layer [MEASURED — visible in every non-black frame]

Persistent across all segments, ~small type:

- **Decay counter chip** (top-center): gold `₹99.xxxxxx` ticking continuously
  — the episode's central claim rendered as a live instrument. Signature move.
- **Param tag** (top-right): `Inr - CPI 5.54% - ILLUSTRATIVE`
- **Citation bar** (bottom-left): `MoSPI/NSO - Sept 2026 CPI 5.54% [S1]`,
  `PRIO 2323244 - 12 Oct 2026 [S1]`, `World Bank FPCP.TOTL (2010=100) [S2]`
- **Watermark** (bottom-right): `THE INTROVERT QUANT`

## 3. Card anatomy [INTERPRETED high]

- Dark rounded card on navy canvas, thin lighter border, slight tilt.
- Header row: card title in caps + tiny sub-caption with period/scope.
- Data rows: gray label left, colored value right (polarity colors).
- Bars: blue/gray bars with value labels above; the highlighted bar is gold.
- Verdict chips: rounded rectangles with colored borders — green border =
  favorable finding, red border = unfavorable; text = finding + magnitude.

## 4. Typography [INTERPRETED high]

- Geometric sans throughout; numerals are the visual heroes (48-120px class).
- Section headers: bold white ALL CAPS with thin gold rule or underline.
- Punch cards: two-line takeaway — line 1 white lowercase ("the basket
  moved."), line 2 gold ("not the note.") — dry, declarative, no exclamation.
- Outro: gold bold two-line statement, white bold sub-statement, small gray
  disclaimer, gold tagline. (seg_16)

## 5. Data discipline [INTERPRETED high — defining trait]

- Every number traceable: citation bar + numbered sources [S1], [S2].
- Estimates flagged `ILLUSTRATIVE` inline (top tag + under hero assumptions).
- Comparisons always framed as a verdict (lead/behind, beats/loses).
- Tone: quiet authority — "the rate never stays fixed. the direction does."

## 6. Audio [MEASURED]

−21.4 LUFS integrated, LRA 3.1 (−23.1…−20.0) → quieter, tighter than
broadcast; consistent bed under VO [INTERPRETED medium]; music/SFX content
not analyzed [NOT ANALYZED].

## 7. Genre match

"Data-card signal explainer" — Bloomberg-terminal aesthetic meets clean
short-form explainer; kin to fintech dashboard motion graphics. [INTERPRETED high]
