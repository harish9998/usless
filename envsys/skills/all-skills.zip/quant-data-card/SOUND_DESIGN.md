# SOUND DESIGN — quant-data-card

## MEASURED targets (ffmpeg ebur128, full 102.9 s)

- Integrated loudness: **−21.4 LUFS** → master VO mix to −21.4 ±1 LUFS.
- Loudness range: **3.1 LU** (−23.1…−20.0) → very consistent, no spikes.

## Production rules [INTERPRETED medium]

1. Voice-over is the only loud element; calm, close-mic, low compression.
2. Music bed: minimal ambient/electronic pad, constant low level, no
   risers/drops; ends cleanly with the outro statement.
3. SFX: restrained UI ticks are stylistically compatible with the ticking
   counter (subtle, ≤-30 dBFS) [INTERPRETED low — SFX content not analyzed].
4. No comedic hits, no whooshes per transition; morphs are silent or near-silent.

## Not analyzed

- Actual music/SFX inventory — loudness statistics only.
