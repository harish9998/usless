---
name: quant-data-card
version: "1.0.0"
description: >
  Introvert Quant data-card explainer production skill, reverse-engineered
  from the channel's own built short ("Why ₹100 today beats ₹100 tomorrow").
  Give this skill any TOPIC (e.g. "repo rate vs your EMI", "index funds vs
  active", "the hidden tax on savings") and it plans, scripts, and builds a
  ~100 s continuous-canvas data short: dark navy data cards, gold hero
  numerals, persistent HUD (live decay counter, source citations, watermark),
  verdict bars, statement outro. Triggers: "quant short about X", "data card
  explainer about X", "introvert quant style", "make a finance data short",
  "build a signal-in-the-noise episode about X".
argument-hint: "<topic> [--script-only|--plan-only]"
allowed-tools: Bash, Read, Write, Glob, Grep, Task
license: MIT
---

# /quant-data-card

Production recipe for a ~100 s data-explainer short in the Introvert Quant
house style. Evidence beside this file: `STYLE_ANALYSIS.md`, `EDITING_RULES.md`,
`TIMING_PRESETS.json`, `SCRIPT_TEMPLATE.md`, `LAYOUT.md`, `TYPOGRAPHY.md`,
`SOUND_DESIGN.md`, `COLOR_PALETTE.json`, `ASSETS/` (reference frames + palette).
Decoded from a locally produced reference — this style was BUILT IN CODE by
the channel (`short_build_v2.py` pattern: programmatic frame rendering), so
the native production path is code rendering (Python/HTML/canvas), not stock
editing. Honesty contract: [MEASURED] vs [INTERPRETED + confidence] tags.

## The one big difference vs shot-based styles

MEASURED: only **1 hard cut in 102.9 s** (scene>0.10). The style is ONE
continuous animated canvas — cards fade/slide/rotate between states, counters
tick live. Do NOT plan shots; plan **segment states** on one timeline.

## Pipeline — topic → short

### 1. Script (SCRIPT_TEMPLATE.md)

- ~230-280 words VO for ~100 s. One central numeric claim (the "decaying
  value" or equivalent) that the HUD counter tracks ALL episode long.
- 6-8 segment states, each = one idea + one visual card + one source.
- Every number must carry a source string for the citation bar.

### 2. Segment plan

Target rhythm [MEASURED ±6 s sampling]: ~7-9 segments of 10-15 s each;
open ≤5 s in; single statement outro ≥8 s. Each segment: header (bold white
caps) + one card + one takeaway (punch card, white line + gold line).

### 3. Visual production spec

- Canvas: dark navy `#0D1520` (subtle radial vignette allowed — this style
  DOES use glow, unlike cartoon styles).
- HUD (persistent, all segments): decay-counter chip top-center (gold text on
  dark chip), source/param tag top-right, citation bottom-left, watermark
  "THE INTROVERT QUANT" bottom-right.
- Cards: dark rounded rectangles `#16222E`-ish, thin lighter border, may tilt
  ~3°; inside: header row, data rows (label gray, value colored by
  polarity: gold hero / cyan info / red negative / blue bars).
- Numbers >> words. One hero numeral per segment.
- Follow COLOR_PALETTE.json + LAYOUT.md zones exactly.

### 4. Build (code rendering preferred)

- Native path: programmatic renderer (Python + PIL/matplotlib, or HTML/canvas
  + screenshots; the channel's own pattern) — enables live ticking counters,
  animated bars, card morphs.
- Render 1920x1080@30 (or 9:16 export as needed), master audio separately.

### 5. Audio (SOUND_DESIGN.md)

- VO mastered to **−21.4 LUFS integrated, LRA ≤3.5** [MEASURED]; quiet,
  restrained bed; no comedic SFX; UI ticks/beeps subtle if at all
  [INTERPRETED medium].

### 6. QC checklist

1. Exactly one continuous canvas; ≤1 hard cut in the whole piece.
2. HUD present in every frame except black open/close.
3. Every number has a citation; every speculative number tagged ILLUSTRATIVE.
4. One hero numeral per segment; polarity colors correct (gold hero, cyan
   info, red negative).
5. Outro = gold statement + white sub-statement + gray disclaimer + gold
   tagline, ≥8 s hold.
6. Integrated loudness −21.4 ±1 LUFS, LRA ≤3.5.

## Modes

- Default: full pipeline (script + segment plan + renderer spec).
- `--script-only` / `--plan-only` as in sibling skills.

## Known limitations

- Decoded from ONE 103 s episode + QA stills; only one reference exists.
- Segment boundaries sampled at 6 s → ±6 s uncertainty [INTERPRETED].
- Music/SFX content not analyzed beyond loudness statistics.
