# SCRIPT TEMPLATE — quant-data-card (~100 s, ~230-280 words VO)

Skeleton decoded from the reference episode. Fill [BEATS]; every number
needs a source for the citation bar; speculative numbers get ILLUSTRATIVE.

## S0 — OPEN (0:00-0:05)

- Black hold → HUD fades in with the decay counter already ticking.
- [BEAT] Central numeric claim introduced by VO only (e.g. "A hundred-rupee
  note is not a container. It is a claim — and the claim shrinks.")

## S1 — THE HOOK CARD (0:05-0:20)

- [BEAT] Hero numeral + one-line sub ("what it will be worth · without moving")
- [BEAT] Three-word threat labels row (reference: "A THIEF · A FEE · A RECEIPT")
- [BEAT] Punch card: white line + gold line ("nobody sends the receipt.")

## S2 — THE MECHANISM (0:20-0:35)

- [BEAT] Tilted data card: the index/table (header + 2-4 rows, polarity colors)
- [BEAT] One comparison bar pair (reference: rural vs urban)
- [BEAT] Punch card.

## S3 — THE LONG VIEW (0:35-0:50)

- [BEAT] Time-series bars (4 columns), final column gold-highlighted
- [BEAT] Multiplier callout card ("×2.33 since 2015...")

## S4 — THE CONSEQUENCE TABLE (0:50-1:05)

- [BEAT] Horizontal table: year rows → what the claim becomes
- [BEAT] Punch card: "the rate never stays fixed. the direction does."

## S5 — THE VERDICT (1:05-1:20)

- [BEAT] Two named comparison bars (gold vs red) with values
- [BEAT] Verdict chips: green-bordered favorable + red-bordered unfavorable
- [BEAT] Punch card: the paradox in one line.

## S6 — OUTRO (1:20-1:43)

- [BEAT] GOLD STATEMENT (2 lines, caps) = the episode's thesis
- [BEAT] White sub-statement = the defense/action
- [BEAT] Gray disclaimer + gold channel tagline, ≥8 s hold

## VO style

- Calm, declarative, second person plural avoided; short sentences.
- Numbers spoken exactly as displayed; units explicit.
- One idea per segment; the VO never introduces a second idea early.
