# TYPOGRAPHY — quant-data-card

Evidence: ASSETS/reference_frames. [INTERPRETED high] unless noted.

## 1. Numerals (the heroes)

- Hero numerals: 90-120px class, gold `#F0C519`, geometric sans, tabular
  (fixed-width digits so the ticking counter doesn't jitter — DECAY COUNTER
  REQUIRES tabular figures).
- Data values: 28-40px; polarity-colored; labels same size in gray.

## 2. Section headers

- Bold white ALL CAPS, ~34-40px, letter-spacing slight; often paired with a
  thin gold rule underneath or a gold sub-line
  ("2010 = 100 → 2025 = 233 · prices ×2.33").
- Sub-captions: 16-18px gray, sentence case, may carry `· ILLUSTRATIVE`.

## 3. Punch cards

- Two lines, lowercase, sentence-weight: line 1 white ("the basket moved."),
  line 2 gold ("not the note."). No punctuation exclamation. Dry and final.

## 4. Verdict chips

- Rounded-rect chips with 2px colored borders; text = finding + magnitude
  ("pre-tax lead: +0.8% per year" green / "after 30% tax: -1.0% BEHIND" red).

## 5. HUD type

- Counter chip: gold tabular numerals on dark chip, ~20px.
- Param tag / citations / watermark: 12-14px dim gray, regular weight.

## 6. Font guidance

- Any geometric/neo-grotesque sans family works (Inter/IBM Plex Sans class);
  numerals MUST be tabular. No serif, no handwritten, no display faces.
