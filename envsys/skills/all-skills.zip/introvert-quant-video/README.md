# The Introvert Quant — OpenCode Video Skill v2.2

This package adapts the supplied finance-video editing breakdown into an original production system for **The Introvert Quant**. It uses a dark editorial finance-essay look: bold thesis cards, animated data, market-flow diagrams, source-document close-ups, highlighted evidence, split-screen comparisons, character analogies, and deliberate sound design.

It retains the channel identity **Finding Signal in the Noise**, Quant + AI robot, and restrained green/gold/red accents. It does not copy another creator's scripts, exact scenes, characters, or assets.

## Install globally on Windows (recommended)

1. Extract the ZIP. Keep the folder named `introvert-quant-video` intact.
2. Open PowerShell inside that extracted folder.
3. Run:

```powershell
.\install-opencode-skill.ps1
```

The installer places the skill at:

```text
%USERPROFILE%\.config\opencode\skills\introvert-quant-video\
```

When replacing an existing installation, it first creates a timestamped backup beside the installed folder. It stages and checks the new package before replacing the old copy.

If PowerShell blocks the script due to the current process execution policy, run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\install-opencode-skill.ps1
```

To install it manually instead, copy the entire extracted `introvert-quant-video` folder into `%USERPROFILE%\.config\opencode\skills\`.

OpenCode discovers directory-based skills with a `SKILL.md` file and YAML frontmatter. The skill ID comes from the directory name, so keep the folder name `introvert-quant-video`.

## Persistent channel asset library (important)

The skill checks the user's existing Windows asset library before generating, downloading, or searching for visual material:

```text
%USERPROFILE%\Downloads\Youtube\Introvert quant\Asset\
```

It preserves and reuses the existing Quant/AI robot masters, pose and expression sheets, object library, animation reference, and main banner. New reusable material and episode-specific generated assets are saved under `Generated/` inside this library and indexed in `_catalog/asset-manifest.csv`. Original PNGs are never moved, renamed, or overwritten.

**The ZIP does not contain copies of your eight original PNG files.** They remain in your existing local `Asset` folder; the package uses the exact path and filenames shown in your File Explorer screenshot. This avoids duplicate copies and keeps your local library as the single source of truth.

After installing the skill, initialize or refresh the asset catalog once in PowerShell:

```powershell
pwsh -File "$HOME\.config\opencode\skills\introvert-quant-video\scripts\initialize-asset-library.ps1"
```

If PowerShell 7 (`pwsh`) is unavailable, use `powershell.exe`. The script is safe to re-run: it refreshes the manifest and does not move, rename, or modify original media files. If your Asset folder is in a different location, pass `-AssetRoot "FULL\PATH\TO\Asset"`.

## Invoke it

```text
@introvert-quant-video FULL EPISODE: Explain why a profitable company can still run out of cash.
Use the dark editorial finance-essay style. Research primary sources where needed, write the narration, create a scene-by-scene editing blueprint, and build the motion graphics with the tools already installed.
```

Other modes:

```text
@introvert-quant-video IDEA: Is the yen carry trade a strong topic for a 7-minute explainer?
@introvert-quant-video RESEARCH: Explain how UPI transactions are routed and settled using primary sources.
@introvert-quant-video SCRIPT: Write a 6-minute essay from these verified research notes.
@introvert-quant-video STORYBOARD: Turn this approved script and voiceover into a timed editing blueprint.
@introvert-quant-video SEQUENCE: Create a document-highlight scene for this official report excerpt.
@introvert-quant-video SHORT: Create a standalone 60-second explanation of inflation.
@introvert-quant-video ASSETS: Search the persistent asset library first; reuse existing visuals and catalogue anything new.
```

## Package contents

- `SKILL.md` — main OpenCode instructions and production workflow.
- `install-opencode-skill.ps1` — staged global installer with backup of an existing skill.
- `references/brand-bible.md` — channel positioning, recurring identity, and existing master artwork.
- `references/asset-library-system.md` — mandatory asset-first reuse, persistent storage, manifest, naming, and licensing rules.
- `scripts/initialize-asset-library.ps1` — safe first-run setup and manifest refresh; does not move or alter original media.
- `references/finance-research-standard.md` — sourcing and financial-claim controls.
- `references/editorial-style-system.md` — visual grammar, narrative architecture, motion and audio direction.
- `references/reference-breakdown-notes.md` — what the supplied Casual Finance analysis supports, what is estimated, and what must not be assumed.
- `templates/episode-brief.md` — episode planning.
- `templates/storyboard-template.md` — scene-level storyboard.
- `templates/sequence-prompt-template.md` — reusable detailed motion-graphics prompt.
- `templates/editing-blueprint.md` — full episode editing timeline and audio cue map.
- `templates/source-ledger.csv` — source register.
- `templates/asset-register.csv` — episode-to-library asset mapping.

## Important limitations

The skill is an instruction set, not a rendering engine. It checks the current project and installed tools before selecting an implementation path. It does not assume paid software, install dependencies automatically, fabricate footage, invent word-level timestamps, or claim a render succeeded without verifying the output.
