[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$SourceRoot = $PSScriptRoot
$SkillName = 'introvert-quant-video'
$Destination = Join-Path $HOME ".config\opencode\skills\$SkillName"
$Parent = Split-Path -Parent $Destination
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$Staging = Join-Path $Parent ".$SkillName-staging-$Stamp"
$Backup = Join-Path $Parent "$SkillName.backup-$Stamp"

$SkillFile = Join-Path $SourceRoot 'SKILL.md'
if (-not (Test-Path -LiteralPath $SkillFile -PathType Leaf)) {
    throw "SKILL.md was not found beside this installer: $SourceRoot"
}

New-Item -ItemType Directory -Path $Parent -Force | Out-Null
New-Item -ItemType Directory -Path $Staging -Force | Out-Null

try {
    # Stage the complete skill package before changing the installed copy.
    Get-ChildItem -LiteralPath $SourceRoot -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Staging -Recurse -Force
    }

    if (-not (Test-Path -LiteralPath (Join-Path $Staging 'SKILL.md') -PathType Leaf)) {
        throw 'Staged package is missing SKILL.md. The existing installation was not changed.'
    }

    if (Test-Path -LiteralPath $Destination -PathType Container) {
        Move-Item -LiteralPath $Destination -Destination $Backup
        try {
            Move-Item -LiteralPath $Staging -Destination $Destination
        }
        catch {
            if (-not (Test-Path -LiteralPath $Destination) -and (Test-Path -LiteralPath $Backup)) {
                Move-Item -LiteralPath $Backup -Destination $Destination
            }
            throw
        }
        Write-Host "Previous installation backed up to: $Backup" -ForegroundColor Yellow
    }
    else {
        Move-Item -LiteralPath $Staging -Destination $Destination
    }

    $InstalledSkill = Join-Path $Destination 'SKILL.md'
    if (-not (Test-Path -LiteralPath $InstalledSkill -PathType Leaf)) {
        throw "Installation verification failed: $InstalledSkill was not found."
    }

    $InstalledFiles = @(Get-ChildItem -LiteralPath $Destination -File -Recurse -Force).Count
    Write-Host "OpenCode skill installed: $Destination" -ForegroundColor Green
    Write-Host "Verified files: $InstalledFiles"
    Write-Host 'Next: initialize the persistent channel asset library using the command in README.md.' -ForegroundColor Cyan
}
finally {
    if (Test-Path -LiteralPath $Staging) {
        Remove-Item -LiteralPath $Staging -Recurse -Force
    }
}
