[CmdletBinding()]
param(
    [string]$AssetRoot = (Join-Path $HOME 'Downloads\Youtube\Introvert quant\Asset')
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $AssetRoot -PathType Container)) {
    Write-Error "Asset library was not found at: $AssetRoot`nCheck the path in File Explorer or pass -AssetRoot with the correct path. No folders or files were changed."
    exit 1
}

$AssetRoot = (Resolve-Path -LiteralPath $AssetRoot).Path
$CatalogRoot = Join-Path $AssetRoot '_catalog'
$ManifestPath = Join-Path $CatalogRoot 'asset-manifest.csv'
$LibraryIndexPath = Join-Path $CatalogRoot 'ASSET_LIBRARY.md'

$RequiredFolders = @(
    '_catalog',
    'Generated\Reusable\Characters',
    'Generated\Reusable\Objects',
    'Generated\Reusable\Backgrounds',
    'Generated\Reusable\Charts',
    'Generated\Reusable\Icons',
    'Generated\Reusable\Motion-Elements',
    'Generated\Reusable\Audio',
    'Generated\Episodes',
    'References'
)

foreach ($RelativeFolder in $RequiredFolders) {
    $FullPath = Join-Path $AssetRoot $RelativeFolder
    New-Item -ItemType Directory -Path $FullPath -Force | Out-Null
}

$KnownAssets = @{
    'PERMANENT OBJECT LIBRARY.png' = @('Object reference sheet', 'objects;props;reference', 'Provisional role based on filename; inspect original PNG before use.')
    'AI Robot master.png' = @('Character master', 'ai-robot;character;master', 'Canonical AI robot artwork; do not redesign or overwrite.')
    'Quant pose sheet 2.png' = @('Character pose sheet', 'quant;character;poses;reference', 'Provisional role based on filename; inspect original PNG before use.')
    'Quant pose sheet.png' = @('Character pose sheet', 'quant;character;poses;reference', 'Provisional role based on filename; inspect original PNG before use.')
    'Quant expression sheet.png' = @('Character expression sheet', 'quant;character;expressions;reference', 'Provisional role based on filename; inspect original PNG before use.')
    'Quant character master.png' = @('Character master', 'quant;character;master', 'Canonical Quant artwork; do not redesign or overwrite.')
    'Mix basic animation pictures touse.png' = @('Animation reference sheet', 'animation;reference;visuals', 'Inspect before use; treat as reference until contents are confirmed.')
    'main banner.png' = @('Channel brand reference', 'brand;banner;channel', 'Channel banner reference; use only where suitable.')
}

$ExistingRows = @{}
if (Test-Path -LiteralPath $ManifestPath -PathType Leaf) {
    foreach ($Row in (Import-Csv -LiteralPath $ManifestPath)) {
        if ($Row.RelativePath) {
            $ExistingRows[$Row.RelativePath] = $Row
        }
    }
}

$Files = Get-ChildItem -LiteralPath $AssetRoot -File -Recurse -Force | Where-Object {
    $_.FullName -notlike "$CatalogRoot\*" -and
    $_.Extension.ToLowerInvariant() -notin @('.tmp', '.part', '.crdownload') -and
    $_.Name -notlike '~$*'
}

$Rows = foreach ($File in $Files) {
    $RelativePath = ($File.FullName.Substring($AssetRoot.Length) -replace '^[\\/]+', '') -replace '/', '\'
    $Existing = $ExistingRows[$RelativePath]

    $AssetType = 'Unclassified'
    $Tags = ''
    $Notes = ''
    if ($KnownAssets.ContainsKey($File.Name)) {
        $AssetType = $KnownAssets[$File.Name][0]
        $Tags = $KnownAssets[$File.Name][1]
        $Notes = $KnownAssets[$File.Name][2]
    } elseif ($File.Extension -match '\.(svg|png|jpg|jpeg|webp|gif)$') {
        $AssetType = 'Image or graphic'
        $Notes = 'Inspect and classify before reuse.'
    } elseif ($File.Extension -match '\.(wav|mp3|m4a|aac|flac|ogg)$') {
        $AssetType = 'Audio'
        $Notes = 'Record source/licence and intended use.'
    } elseif ($File.Extension -match '\.(mp4|mov|mkv|webm|avi)$') {
        $AssetType = 'Video'
        $Notes = 'Record source/licence and intended use.'
    }

    if ($Existing) {
        if ($Existing.AssetType -and $Existing.AssetType -ne 'Unclassified') { $AssetType = $Existing.AssetType }
        if ($Existing.Tags) { $Tags = $Existing.Tags }
        if ($Existing.Notes) { $Notes = $Existing.Notes }
        $SourceOrOrigin = $Existing.SourceOrOrigin
        $LicenseOrUsage = $Existing.LicenseOrUsage
        $UsedIn = $Existing.UsedIn
        $AssetID = $Existing.AssetID
    } else {
        $SourceOrOrigin = 'User-owned library; verify origin if unclear'
        $LicenseOrUsage = 'User-owned; confirm rights for any third-party content'
        $UsedIn = ''
        $AssetID = 'IQ-' + ([guid]::NewGuid().ToString('N').Substring(0, 8).ToUpperInvariant())
    }

    [pscustomobject]@{
        AssetID = $AssetID
        RelativePath = $RelativePath
        FileName = $File.Name
        AssetType = $AssetType
        Tags = $Tags
        SourceOrOrigin = $SourceOrOrigin
        LicenseOrUsage = $LicenseOrUsage
        UsedIn = $UsedIn
        Notes = $Notes
        SizeBytes = [long]$File.Length
        LastModifiedUtc = $File.LastWriteTimeUtc.ToString('o')
    }
}

$Rows | Sort-Object RelativePath | Export-Csv -LiteralPath $ManifestPath -NoTypeInformation -Encoding utf8

if (-not (Test-Path -LiteralPath $LibraryIndexPath -PathType Leaf)) {
    $KnownFileList = @(
        'PERMANENT OBJECT LIBRARY.png — object/prop reference sheet (provisional; inspect before use)',
        'AI Robot master.png — canonical AI robot master (do not redesign or overwrite)',
        'Quant pose sheet 2.png — Quant pose reference (provisional; inspect before use)',
        'Quant pose sheet.png — Quant pose reference (provisional; inspect before use)',
        'Quant expression sheet.png — Quant expression reference (provisional; inspect before use)',
        'Quant character master.png — canonical Quant character master (do not redesign or overwrite)',
        'Mix basic animation pictures touse.png — animation reference sheet (inspect before use)',
        'main banner.png — channel banner/brand reference'
    )

    $IndexContent = @(
        '# The Introvert Quant — Asset Library',
        '',
        "**Root:** ``$AssetRoot``",
        '',
        'This is the persistent, source-of-truth library for channel-owned artwork and approved production assets. Preserve original masters; create versioned derivatives instead of overwriting them.',
        '',
        '## Existing assets identified from the supplied File Explorer screenshot',
        ''
    ) + ($KnownFileList | ForEach-Object { "- $_" }) + @(
        '',
        'These descriptions are provisional until the original PNG files are inspected. The machine-readable catalog is `asset-manifest.csv`.',
        '',
        '## Storage',
        '- `Generated/Reusable/` — channel-wide reusable assets.',
        '- `Generated/Episodes/<episode-slug>/` — generated assets specific to one episode.',
        '- `References/` — approved reference materials with source/usage notes.',
        '- `_catalog/` — asset index and machine-readable manifest.',
        '',
        '## Retrieval rules',
        '1. Read `asset-manifest.csv` before searching files.',
        '2. Inspect only relevant candidate files and new/changed files.',
        '3. Reuse the Quant and AI robot masters and existing pose/expression sheets first.',
        '4. Never overwrite or rename original masters.',
        '5. Update the manifest whenever assets are added, versioned, or reclassified.',
        '',
        '## Manifest columns',
        '`AssetID, RelativePath, FileName, AssetType, Tags, SourceOrOrigin, LicenseOrUsage, UsedIn, Notes, SizeBytes, LastModifiedUtc`',
        '',
        'Run `scripts/initialize-asset-library.ps1` from the installed skill folder to refresh file metadata. The script does not move, rename, or modify original media files.'
    )
    Set-Content -LiteralPath $LibraryIndexPath -Value $IndexContent -Encoding utf8
}

Write-Host "Asset library initialized: $AssetRoot" -ForegroundColor Green
Write-Host "Catalog: $ManifestPath"
Write-Host "Index:   $LibraryIndexPath"
Write-Host "Media files indexed: $($Rows.Count)"
Write-Host 'Original assets were not moved, renamed, or modified.' -ForegroundColor Cyan
