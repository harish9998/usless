# The Introvert Quant — Brand Bible

## Positioning

**Channel:** The Introvert Quant  
**Tagline:** Finding Signal in the Noise.

The channel explains finance, economics, AI, fintech, blockchain, and global markets by revealing the mechanisms beneath headlines. It should feel like a careful investigation led by a technically curious guide—not a trading guru, financial influencer, or hype channel.

## Audience promise

Help viewers build mental models they can reuse. The viewer should leave understanding why something happens, how the mechanism works, what the evidence supports, and where the explanation has limits.

## Editorial voice

- Analytical, calm, curious, and precise.
- Skeptical of easy narratives, but not contrarian for entertainment.
- Speak in plain English while retaining technical terms when they improve precision.
- Explain jargon on first use.
- Use analogies to simplify, then explain where each analogy breaks.
- Avoid exaggerated promises, fear-based hooks, fake urgency, unsupported predictions, and claims of secret knowledge.

## Visual identity

### Primary style
Dark editorial finance explainer: bold thesis headlines, source-document close-ups, institutional data, animated charts, financial flow diagrams, market timelines, comparison layouts, and selective 2D depth.

### Secondary style
Whiteboard-inspired cartoon illustration and hand-drawn marker reveals remain useful for concepts that benefit from a simple teaching diagram. They should complement—not dominate—the main editorial finance look.

### Recurring characters
- **Quant:** curious human guide who asks the viewer's question and connects abstract mechanisms to real decisions.
- **AI robot:** analytical assistant that visualizes data, calculations, and alternative scenarios; can act as a skeptical counterpoint.

Use them selectively. Their presence should clarify the story, not interrupt every scene.

### Palette
- Background: dark navy `#0A0F1D`, secondary slate `#161B26`.
- Main text: white `#FFFFFF`.
- Gold `#FFD100` / yellow `#FFE600`: key thesis, important evidence, and highlights.
- Green `#34C759`: positive direction, inflows, or confirmed gains.
- Red `#FF3B30`: losses, downside, risk, and warnings.
- Optional cool blue/cyan `#64D2FF`: institutional or technical information.

Color is never the only signal. Pair it with labels, icons, or shape differences.

## Visual motifs

Signal/noise, charts, currencies, market flows, ledgers, balance sheets, payment rails, networks, liquidity, data pipelines, magnifying glass, and clear cause-and-effect diagrams.

## Typography and composition

- Bold sans-serif for major statements and metric callouts.
- Highly legible sans-serif for chart labels and document excerpts.
- One focal point per frame.
- Strong contrast; mobile readability takes priority over decorative detail.
- Use short on-screen phrases, not full paragraphs.

## Production guardrails

- Make original scenes and assets; do not copy another creator's exact layouts, characters, scripts, or sequences.
- Use real, traceable documents and data. Never fabricate screenshots, PDF excerpts, app demos, charts, or quotations.
- Label illustrative numbers and hypothetical examples.
- Keep chart definitions, units, periods, and sources visible or traceable.
- Respect copyright, asset licenses, and disclosure requirements.
- Prefer simple 2D motion and efficient local tools over unnecessary 3D or expensive dependencies.

## Existing master artwork and persistent library

The channel's existing master artwork is stored in `%USERPROFILE%\Downloads\Youtube\Introvert quant\Asset\`. Reuse `Quant character master.png` and `AI Robot master.png` as canonical character designs, and inspect the supplied pose and expression sheets before requesting new character art. Preserve every original master. The asset manifest and storage rules are defined in `references/asset-library-system.md`.
