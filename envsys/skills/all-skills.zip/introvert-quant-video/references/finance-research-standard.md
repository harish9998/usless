# Finance and Economics Research Standard

Use this standard for scripts, charts, claims, and descriptions published by The Introvert Quant.

## Source hierarchy

1. **Primary:** laws and regulations; regulator and central-bank publications; exchange notices and rulebooks; company annual reports, quarterly filings, investor presentations, and official press releases; government statistical agencies; official datasets; original academic papers; technical documentation.
2. **High-quality secondary:** established financial publications, reputable research organizations, university explainers, and expert analysis with transparent methodology.
3. **Discovery only:** social posts, forums, influencer videos, aggregators, and AI-generated summaries. These can reveal questions or leads but should not be the sole support for material factual claims.

## What to record for every important source

- Source ID, title, publisher/author, URL.
- Publication date and access date.
- Relevant table, section, chart, page, or timestamp.
- Exact claim the source supports.
- Data period, units, geography, and population if applicable.
- Known caveat, definition, or limitation.

## Market and macro data controls

- Put the observation date and time zone on prices and market snapshots.
- Distinguish spot, futures, index level, yield, return, market capitalization, and trading volume.
- Distinguish nominal from real values and stock variables from flow variables.
- State whether returns are price returns or total returns, and whether currency conversion is applied.
- For inflation, specify the index, geography, comparison period, and whether the figure is month-over-month or year-over-year.
- For interest rates, specify the instrument, tenor, policy rate or market rate, and effective date.
- For company financials, specify fiscal period, reporting currency, accounting basis, and whether values are consolidated.
- Do not compare unlike measures without explicitly explaining the difference.

## Calculations

For every derived figure, preserve:
- Formula.
- Source inputs and units.
- Assumptions and date.
- Intermediate values when material.
- A sanity check or independent recomputation.

Round only for readability; do not imply precision that the source data does not support. Use a range when assumptions dominate the result.

## Claim labels

- **Fact:** directly supported by a cited source.
- **Interpretation:** reasoned explanation of facts; present as analysis, not an official conclusion.
- **Estimate:** a modelled or approximate value; show assumptions.
- **Scenario:** hypothetical example; explicitly label it as hypothetical.
- **Forecast:** a forward-looking view from an identified source or an explicitly described model; never present it as certainty.

## Handling uncertainty and disagreement

- Record contradictory evidence instead of hiding it.
- Check whether differences come from definitions, periods, currencies, revisions, or methodology.
- Use “approximately,” “reported,” or “according to [source]” where appropriate.
- Remove claims that cannot be defended.
- Avoid false balance: do not present a weak unsupported claim as equal to strong primary evidence.

## Legal, safety, and editorial boundaries

- Educational content is not individualized financial, legal, or tax advice.
- No guaranteed-return language, risk-free claims, or unsupported investment recommendations.
- Clearly disclose sponsorships, affiliate links, holdings, or conflicts when applicable; do not invent disclosures.
- Respect copyright, licensing, and terms of use for footage, charts, images, and audio. A publicly viewable asset is not automatically reusable.
- Attribute third-party charts and rebuild them only when the data license permits it. Prefer original charts from properly sourced data.
