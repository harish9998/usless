# Reference Breakdown Notes — Supplied Casual Finance Analysis

## What the supplied source contains

The user supplied a transcript-based editing analysis covering four long-form finance videos. It describes a fast, single-narrator financial essay format with a contrarian/curiosity-led opening, character analogies, institutional evidence, document highlights, split-screen comparisons, optional sponsor integrations, and a synthesis ending.

This file is a **secondary analysis of transcripts**, not raw video files or original editing project files. Treat it as useful creative direction, not a verified technical specification.

## Elements that are useful to adapt

1. **Narrative progression:** hook → context/analogy → evidence and mechanism → synthesis.
2. **Voiceover-led edit:** use narration to drive visual timing and scene transitions.
3. **Visual evidence:** show real institutional documents, reports, charts, source excerpts, and dates.
4. **Mechanism diagrams:** show how incentives, capital, risk, and obligations move between actors.
5. **Visual comparison:** use split screens for real comparisons with matching definitions and periods.
6. **Document treatment:** crop, tilt slightly, push in, and highlight the exact sentence being discussed.
7. **Sound design:** use selective impacts, paper/marker/UI effects, and music ducking to support the narrative.
8. **Retention:** change visual state when the argument changes; use pacing variation to prevent visual fatigue.

## Facts, estimates, and unknowns

The analysis reports transcript-visible items and its own technical estimates. Preserve that distinction:

| Item | Status in supplied analysis | Instruction |
|---|---|---|
| Four video titles and transcript references | Reported source inventory | Use only as contextual reference; do not treat transcript text as frame-level evidence |
| Single narrator and five-part narrative pattern | Analysis of transcript structure | Useful as a flexible structural reference |
| Mention of Gamma, Whisper Flow, Ground News, QR codes, and comparisons | Transcript-reported content | Reuse only when relevant and when the product/demo is real |
| 16:9, 1080p, 24/30/29.97 fps | Estimated or suggested | Verify from actual video/project metadata before use |
| 2.5–3.5 second visual cadence / 2.8-second average | Estimated heuristic | Use flexibly; do not force constant motion |
| Exact edit points, cut frame counts, color grading, layer stacks, LUTs | Not available from transcripts | Do not claim these were observed |
| VO peak, BGM level, compression, EQ and SFX settings | Suggested recipes in the analysis | Starting points only; mix and meter actual audio |
| Exact sponsor placement and visual treatment | Reported pattern from transcripts | Optional, and never invent a sponsor segment |

## Important production corrections

- The supplied sample timeline is an illustrative reconstruction. Do not assign its 0:00–1:30, 1:30–4:00, or 4:00–6:00 timestamps to every episode.
- A claimed average shot duration is not a requirement to change every shot on a timer. Use a new visual when it adds a new piece of meaning.
- Document screenshots must be authentic, correctly attributed, readable, and used in a way that respects copyright and licensing.
- A metric or quote appearing in the source analysis is not automatically a verified fact for a new episode. Recheck it in the original source and for the relevant date.
- An analogy is not proof. Label hypothetical examples and state where the analogy breaks.
- A sponsor/product comparison needs real screen captures and fair conditions. Do not generate fictitious performance claims.

## How to apply it to The Introvert Quant

Adopt the editorial finance-essay grammar—dark evidence-led graphics, large headlines, charts, document highlights, split comparisons, flow diagrams, selective SFX—while retaining the channel's own identity: **Finding Signal in the Noise**, Quant + AI robot, and the green/gold/red palette. The result should be recognizably the user's channel, not a clone of the reference channel.
