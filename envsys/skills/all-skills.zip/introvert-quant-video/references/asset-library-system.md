# The Introvert Quant — Persistent Asset Library System

## 1. Canonical library location

The user's existing Windows asset library is the single source of truth:

```text
%USERPROFILE%\Downloads\Youtube\Introvert quant\Asset\
```

In PowerShell, resolve it as:

```powershell
$AssetRoot = Join-Path $HOME 'Downloads\Youtube\Introvert quant\Asset'
```

The folder name and path come from the user's File Explorer screenshot. Do not silently substitute another folder. If this path does not exist on the machine running the workflow, search only the nearby `Downloads\Youtube\Introvert quant\` folder for an `Asset` directory. If it still cannot be found, report the blocker and ask for the correct path; do not create a duplicate library elsewhere.

## 2. Existing user-owned assets (identified from the screenshot)

These files already exist directly in the library root. Preserve their names and locations. The role descriptions below are provisional classifications based on filenames; inspect the actual PNGs before making detailed claims about their contents.

| Existing file | Provisional role | Reuse rule |
|---|---|---|
| `PERMANENT OBJECT LIBRARY.png` | Reusable object/prop reference sheet | Inspect and crop/reuse existing objects before creating replacements. |
| `AI Robot master.png` | AI robot master character artwork | Treat as the canonical robot design. Do not redesign or regenerate the robot. |
| `Quant pose sheet 2.png` | Quant character pose reference sheet | Reuse an existing pose or create a derivative from the master when technically appropriate. |
| `Quant pose sheet.png` | Quant character pose reference sheet | Check both pose sheets before making a new pose. |
| `Quant expression sheet.png` | Quant expression reference sheet | Reuse the established face/expression design. |
| `Quant character master.png` | Quant master character artwork | Treat as the canonical Quant design. Do not redesign or regenerate Quant. |
| `Mix basic animation pictures touse.png` | Animation/reference image sheet | Inspect before use; treat as a reference until its contents and intended use are clear. |
| `main banner.png` | Main channel banner / brand reference | Use as a brand reference; do not force it into scenes where a banner is not appropriate. |

The screenshot is not a substitute for the original PNG files. The agent must inspect the actual files from the canonical library on the user's machine.

## 3. Asset-first policy (mandatory)

Before generating, downloading, or searching for any visual asset:

1. Read `_catalog/ASSET_LIBRARY.md` and `_catalog/asset-manifest.csv` when they exist.
2. Check the canonical library for an existing asset with the required role, subject, character, pose, expression, object, layout, or animation.
3. Inspect the candidate asset at useful resolution. A filename match alone is not enough to verify suitability.
4. Reuse the existing file directly where possible. If a crop, resize, transparent cut-out, recolor, or animation-ready derivative is needed, create a derivative while preserving the original master.
5. Record the asset path and asset ID in the episode's storyboard/asset register.
6. Generate or obtain a new asset only when the library does not contain a suitable asset or the scene requires genuinely new factual material.

Do not regenerate Quant, the AI robot, their established visual identity, or an object already represented in the user's library merely because a new image might look more polished. Consistency and asset reuse take priority.

## 4. Storage rules — keep the library persistent and organized

Keep all original files in their current locations. Never bulk-rename, move, overwrite, or delete original assets. The initialization script only creates folders and catalog files; it does not modify the user's PNGs.

Use this structure for new material, creating only the folders needed:

```text
Asset/
├── [existing original PNG files — preserve in place]
├── _catalog/
│   ├── ASSET_LIBRARY.md
│   └── asset-manifest.csv
├── Generated/
│   ├── Reusable/
│   │   ├── Characters/
│   │   ├── Objects/
│   │   ├── Backgrounds/
│   │   ├── Charts/
│   │   ├── Icons/
│   │   ├── Motion-Elements/
│   │   └── Audio/
│   └── Episodes/
│       └── <episode-slug>/
│           ├── Graphics/
│           ├── Documents/
│           ├── Screen-Recordings/
│           └── Audio/
└── References/
```

### Where each asset goes

- **Existing masters and references:** remain where they are. Add catalog entries; do not duplicate them.
- **New channel-wide reusable assets:** save in `Generated/Reusable/<category>/` (for example, a reusable chart frame, transition, background, icon set, or approved character derivative).
- **Episode-specific generated assets:** save in `Generated/Episodes/<episode-slug>/<category>/`.
- **Third-party, sourced, or official evidence assets:** store in the episode's `Documents/` or `References/` area only when local retention and the relevant licence/terms permit it. Record the original URL, publisher/creator, access date, licence/usage notes, and source-ledger ID. Do not silently add unlicensed stock footage, music, or creator artwork to the reusable library.
- **Temporary tests, caches, failed renders, and intermediate files:** keep outside the permanent library or in a temporary working directory; do not pollute the reusable asset catalog.

All final assets actually used in an episode must be recorded in the episode register. Every newly generated final visual/audio asset must be saved under `Asset/Generated/` (reusable or episode-specific), not left only in a temporary working directory. Keep the project/output's required working copy only when the editing tool requires it; prefer references/relative paths where reliable.

## 5. File naming and versioning

Use descriptive, predictable names:

```text
<subject>-<purpose>-<variant>-v001.<ext>
```

Examples:

```text
quant-explaining-cashflow-pose-v001.png
robot-market-risk-reaction-v001.png
macro-chart-frame-dark-v001.svg
upi-payment-flow-arrows-v001.svg
```

Rules:
- Use lowercase kebab-case for new files.
- Never replace a master file. Increment the version (`v002`, `v003`) or create a new derivative.
- Prefer SVG for editable vector graphics, PNG for raster/transparent artwork, WAV for final sound effects/voice recordings where applicable, and MP4 only for actual video assets.
- Export transparent backgrounds when an asset is intended to overlay footage.
- Keep image dimensions appropriate to use; do not generate 4K assets for a small icon.
- Avoid duplicate exports, near-identical variants, unnecessary large files, and redundant formats.

## 6. Manifest and fast retrieval

`_catalog/asset-manifest.csv` is the machine-readable index. It should contain at least:

- `AssetID`
- `RelativePath`
- `FileName`
- `AssetType`
- `Tags`
- `SourceOrOrigin`
- `LicenseOrUsage`
- `UsedIn`
- `Notes`
- `SizeBytes`
- `LastModifiedUtc`

`_catalog/ASSET_LIBRARY.md` is the short human-readable index and must include the canonical root, folder map, known master assets, and instructions for updating the manifest.

Retrieval efficiency:
- Use the manifest first; do not recursively open every file for every episode.
- Compare file path, size, and last-modified time to detect new/changed files. Inspect only new or changed images and any candidates relevant to the current scene.
- Generate a contact sheet only when the manifest/filenames cannot distinguish candidates or the user asks for one.
- Cache visual understanding/metadata in the catalog after inspecting an asset. Do not repeatedly re-analyze unchanged masters.
- Do not scan large video/audio files just to identify brand artwork; filter by needed category and extension.
- Update the catalog whenever an asset is added, replaced by a new version, or materially reclassified.

## 7. External asset and image-generation rules

- Do not use web image search for generic finance icons, arrows, charts, backgrounds, title cards, or character artwork when the library already contains suitable material or an original SVG can be created locally.
- For real-world evidence (an official filing, a named person, company, physical location, event, or actual market chart), obtain a traceable, authoritative source. Never substitute a decorative generated image for factual evidence.
- Use image generation for a genuinely new visual that is not in the library, and only when the user/project authorizes creation. Never ask an image generator to recreate a real document, data chart, logo, or existing character master when an exact source or editable data-backed graphic is required.
- Do not imitate another creator's distinctive character, scene, or exact composition. Use the reference only for high-level editing principles.
- Record source and usage details for anything externally sourced. Do not add material to `Generated/Reusable/` unless the channel owns it or has clear reuse rights.

## 8. Episode close-out

At the end of each episode:
1. Confirm every used asset has a valid path and catalog/episode-register entry.
2. Confirm new reusable assets are in the correct permanent category and new episode-only assets are under the episode slug.
3. Update `UsedIn` with the episode slug for every asset used.
4. Record missing assets and requested future assets rather than creating duplicates.
5. Report which existing library assets were reused, which assets were newly generated, and where they were saved.
6. Do not claim the user's local library was updated unless the workflow actually wrote to the configured path and verified the resulting files.
