# The Introvert Quant — Editorial Style System

This document translates the supplied finance-video breakdown into a reusable visual and narrative grammar for The Introvert Quant. It describes a genre-level system, not a frame-by-frame recreation of another channel.

## 1. Core look

**Editorial direction:** dark, evidence-led, macro-finance explainer. The screen should feel like a visual investigation: a strong claim, then the mechanism and evidence that support or challenge it.

**Base canvas:** dark slate/navy (`#0A0F1D` to `#161B26`) with restrained grid lines, radial light, and optional subtle grain. Keep the center graphic and text readable. Use the channel's gold, green, and red accents consistently.

**Visual hierarchy:**
1. One thesis or section headline.
2. One dominant data point, document, chart, or mechanism.
3. Supporting labels and source attribution.

Do not place every available fact on one slide.

## 2. Narrative sequence architecture

| Sequence | Purpose | Visual language | Editing behavior |
|---|---|---|---|
| Cold open | Establish a concrete puzzle or contradiction | Kinetic headline, headline fragments, one strong metaphor, striking but sourced number | Short cuts and controlled impacts |
| Context | Explain why the issue matters | Map, timeline, actor cards, original character analogy | Slightly slower; let the model register |
| Mechanism | Show how money, risk, incentives, or obligations move | Flow diagram, balance-sheet blocks, 2–3 panel layout | Animate paths and transformations |
| Evidence | Validate or complicate the thesis | Actual filing/report excerpt, data chart, quote card, expert statement | Document zoom, highlight wipe, chart build |
| Comparison | Expose a difference or trade-off | 50/50 split, paired metric cards, before/after | Match time period, scale, and conditions |
| Synthesis | Reassemble the causal chain and limitations | Return to the opening metaphor, summary diagram, restrained title card | Fewer cuts; land the point |

A sponsor demonstration is an optional insertion, not a required story beat. It should exist only when a real relationship or product demonstration is present.

## 3. Reusable visual devices

### Contrarian thesis card
- Dark base, bold white headline, one gold-highlighted phrase.
- A cross-out or mask wipe may reject a simplistic explanation, but never falsify what a source said.
- Pair the statement with a clear source or explain it as a question/hypothesis.

### Institutional document card
- Real report, filing, policy document, or research paper.
- Crop to the exact page and sentence needed.
- Optional perspective tilt of about 4–8 degrees, soft shadow, and slow camera push.
- Gold/yellow highlight follows the exact line as it is read.
- Include a source marker and date; preserve enough context to avoid misleading cropping.

### Financial flow diagram
- Use labeled nodes for institutions, people, instruments, or markets.
- Use arrows to show actual flow direction (money, collateral, information, risk, or obligations).
- Label rates, amounts, currencies, and time periods beside the correct edge or node.
- Distinguish the principal, interest, fees, and risk. Do not suggest that a spread is guaranteed profit.

### Original character allegory
- Use Quant or the AI robot where useful; otherwise create a simple original character.
- Character behavior should explain the mechanism, not act as filler or comedy unrelated to the point.
- Make assumptions explicit on screen; follow the analogy with its real-world limitation.

### Statistical chart
- State the metric, definition, period, units, geography, and source.
- Use a clean dark plot area, restrained grid, and one or two accent colors.
- Animate bar height, line path, map fills, or number counters only from actual data values.
- Never truncate axes or scale bars deceptively for drama.

### Split-screen comparison
- Use equal panels, clear headers, and a neutral divider.
- Ensure same definitions, scales, periods, test prompts, or conditions wherever comparability is claimed.
- Mark any non-equivalence explicitly.

## 4. Motion behavior

Use purposeful motion with clear starts and stops. Possible starting recipes:
- Headline: 8–12 frame opacity/position reveal; use a short mask wipe for the key phrase.
- Metric card: subtle scale from 95% to 100%, with a short opacity fade.
- Flow arrows: line draw from 0% to 100%; animate in causal order.
- Document highlight: left-to-right reveal timed to the phrase being read.
- Chart: reveal axes first, then data, then annotation/callout.
- Camera: slow push or small parallax; avoid continuous drifting behind dense text.
- Exit: clean cut, short fade, or match transition; avoid stacking multiple transition effects.

The supplied breakdown suggests a visual state change approximately every 2.5–3.5 seconds. Treat this as a pacing heuristic, not a law. For a dense chart or important quote, comprehension takes priority over frequency.

## 5. Audio palette

- Voiceover: clean, centered, intelligible, and consistent.
- Music: restrained ambient/electronic tension bed; change texture at narrative pivots rather than looping one mood at full level.
- SFX: selective paper movement, marker stroke, UI click, soft whoosh, riser, and low-frequency impact.
- Avoid constant keyboard sounds, excessive risers, or bass hits on every statistic.
- Duck music under narration and check on both headphones and ordinary speakers.

Specific dB figures in the supplied analysis are starting suggestions only. Final levels depend on the recording, mix, platform, and listening test.

## 6. Channel-specific adaptation

| Reference technique | The Introvert Quant implementation |
|---|---|
| Contrarian opening | A rigorous puzzle or overlooked mechanism; no manufactured outrage |
| Named character analogy | Quant, the AI robot, or an original one-off character |
| Dark slate canvas | Adopt as the main canvas, with the channel's gold/green/red accents |
| PDF/document close-ups | Use real, attributed institutional documents and exact quotations |
| Split-screen comparison | Use for genuine like-for-like comparisons or clearly qualified contrasts |
| Fast visual cadence | Preserve semantic visual changes; slow down when the mechanism is difficult |
| Sponsor workflow demo | Optional and disclosure-compliant; never fabricated |
| Mainstream media critique | Only when evidence supports it; otherwise focus on the mechanism, not media bashing |

## 7. What not to copy or assume

- Do not reuse the reference channel's scripts, exact analogies, characters, compositions, or sourced examples as signature recurring content.
- Do not assume all videos follow the same fixed timestamps or that every video needs a sponsor segment.
- Do not treat transcript-derived editing claims as proof of frame rate, camera settings, audio processing, exact cut timing, LUTs, or layer stacks.
- Do not insert made-up source documents, fake UI, fake QR codes, fake app comparisons, or unverified metrics.
- Do not overuse 3D tilt, film grain, glow, sub-bass, or kinetic text. The visual should explain the finance, not compete with it.
