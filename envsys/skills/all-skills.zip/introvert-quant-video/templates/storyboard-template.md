# Storyboard — [Episode title]

**Script version:**  
**Voiceover version:**  
**Audio duration:**  
**Timing method:** word alignment / phrase alignment / manual estimate  
**Format:** 16:9 / 9:16 / other  

| Scene | In / Out | Narration (exact words) | Viewer takeaway | Visual / composition | Motion | On-screen text | Assets / source IDs | Transition / notes |
|---|---|---|---|---|---|---|---|---|
| 01 | 00:00–00:00 |  |  |  |  |  |  |  |
| 02 | 00:00–00:00 |  |  |  |  |  |  |  |
| 03 | 00:00–00:00 |  |  |  |  |  |  |  |

## Timing notes
- Actual audio runtime:
- Estimated runtime before recording:
- Sections needing breathing room:
- Any timing that must be confirmed by watching the render:

## Asset checklist
- [ ] All charts have labels, units, periods, and source notes.
- [ ] All illustrative values are labelled as hypothetical.
- [ ] All visual assets are original, licensed, or otherwise cleared.
- [ ] Text is readable on a mobile preview.
- [ ] Red/green signals also use labels or shapes.
