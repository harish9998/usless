# Episode Editing Blueprint

**Episode:**  
**Script version:**  
**Voiceover version:**  
**Measured audio duration:**  
**Timing method:** word-level / phrase-level / manual  
**Frame format:** 16:9 / 9:16 / other  

## Narrative map

| Section | Actual time range | Narrative job | Key evidence | Main visual system |
|---|---|---|---|---|
| Cold open |  | Establish puzzle/thesis |  | Kinetic headline / striking sourced visual |
| Context |  | Explain stakes and actors |  | Timeline / map / character analogy |
| Mechanism |  | Explain causal chain |  | Financial flow diagram / balance sheet |
| Evidence |  | Test the thesis |  | Documents / charts / data callouts |
| Comparison |  | Clarify trade-off or contrast |  | Split screen / paired cards |
| Synthesis |  | State conclusion and limits |  | Return to central model / summary card |

## Scene timeline

| Scene | In / Out | Narration excerpt | Viewer takeaway | Composition | Motion / transition | On-screen text | Source IDs / asset path | Audio cue | Status |
|---|---|---|---|---|---|---|---|---|---|
| 01 |  |  |  |  |  |  |  |  | Planned |
| 02 |  |  |  |  |  |  |  |  | Planned |
| 03 |  |  |  |  |  |  |  |  | Planned |

## Audio event list

| Timecode | Event | Track | Level / mix note | Sync target |
|---|---|---|---|---|
|  |  | VO / BGM / SFX |  |  |

## Export and review
- Intended resolution:
- Intended frame rate:
- Intended codec/container:
- Actual export settings:
- Full playback checked: yes / no
- Mobile readability checked: yes / no
- Audio checked on speakers/headphones: yes / no
- Outstanding issues:
