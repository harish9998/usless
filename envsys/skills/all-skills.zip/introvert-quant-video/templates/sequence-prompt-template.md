# Motion-Graphics Sequence Prompt

## 1. Sequence identity
- Episode:
- Sequence ID / name:
- Narrative section: hook / context / mechanism / evidence / comparison / synthesis / other
- Sequence purpose:
- Viewer takeaway:
- Estimated or actual duration:
- Timing source: measured audio / aligned transcript / manual estimate / not yet available

## 2. Narration and evidence
- Exact voiceover excerpt:
- Script version:
- Audio file and version:
- Start / end timecode:
- Source IDs supporting the claims:
- On-screen citation text:
- Facts vs interpretation vs illustrative scenario:

## 3. Canvas and visual direction
- Resolution / aspect ratio / frame rate:
- Background and palette:
- Main composition:
- Focal point:
- Secondary elements:
- Typography hierarchy:
- Document / chart / image assets:
- Required attribution or license:

## 4. Timeline and animation
| Relative time / actual timecode | Visual state | Animation/action | Narration sync point | SFX / music |
|---|---|---|---|---|
| 00:00 |  |  |  |  |
| 00:05 |  |  |  |  |
| 00:10 |  |  |  |  |
| 00:15 |  |  |  |  |

## 5. Motion specification
- Entry behavior:
- Main animation:
- Easing / duration:
- Camera movement / parallax:
- Exit / transition:
- What must remain static for legibility:

## 6. Audio specification
- VO state:
- BGM state / ducking:
- SFX events and exact sync points:
- Peak / loudness check to perform:

## 7. Production implementation
- Preferred method: SVG / HTML-CSS / Remotion / Resolve / After Effects / FFmpeg / other
- Dependencies confirmed available:
- Files to create:
- Render command (only when known):
- Fallback if unavailable:

## 8. Quality checks
- [ ] Narration and timing correspond to the correct script/audio version.
- [ ] Every number and quote is source-backed.
- [ ] Chart units, period, and scale are correct.
- [ ] Document excerpt is authentic and accurately highlighted.
- [ ] Text is legible at mobile preview size.
- [ ] Color is not the only carrier of meaning.
- [ ] SFX does not mask narration.
- [ ] Assets are original, licensed, or otherwise cleared.
- [ ] Output file was actually rendered and checked, if rendering was requested.
