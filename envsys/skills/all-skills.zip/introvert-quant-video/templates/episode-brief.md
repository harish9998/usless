# Episode Brief

## 1. Core idea
- Working title:
- Topic / question:
- Content pillar:
- Target viewer:
- Viewer misconception or knowledge gap:
- One-sentence promise:
- One central takeaway:

## 2. Editorial scope
- Why this matters:
- Key points (3–5):
  1.
  2.
  3.
- What this video will not cover:
- Important caveat / counterargument:
- Call to action (optional):

## 3. Production
- Format: YouTube long-form / Short / other
- Target runtime:
- Aspect ratio and resolution:
- Narration language and voice:
- Visual approach:
- Required charts / data / examples:
- Required assets and permissions:

## 4. Research plan
- Key factual claims to verify:
- Primary sources to consult:
- Data period and geography:
- “Current as of” date (if relevant):
- Known uncertainties:

## 5. Success criteria
- What should a viewer be able to explain afterward?
- What would make this episode inaccurate or misleading?
- What is the minimum acceptable production quality?
