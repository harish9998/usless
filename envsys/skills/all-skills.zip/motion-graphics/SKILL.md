---
name: motion-graphics
description: AI motion graphics and animated video generation pipeline (from Nafay 3D's "Make Motion Graphics With Claude AI" workflow). Storyboard-first animated explainers synced word-by-word to a voiceover, style cloning from screenshots into reusable design systems, and an iterative review loop. Use when the user wants motion graphics, an animated explainer video, to overlay synced graphics on existing footage/voiceover, or to "clone this style" from a reference video/channel — no traditional video editor required.
metadata:
  origin: video https://youtu.be/u_J77nEB15M (Nafay 3D, ~155k views) + nafay3d.com template library
---

# Motion Graphics (AI-Generated, Editor-Free)

Generate fully animated motion-graphics videos from a topic, script, or voiceover. All graphics, animation, sound sync, and transitions are produced programmatically — no After Effects, no Premiere.

Source: https://youtu.be/u_J77nEB15M — "How to Make Motion Graphics With Claude AI for FREE (Game Changer)" by Nafay 3D.

## When to Activate

- User gives a topic or script and wants an animated graphics video/Short
- User has a video or voiceover and wants motion graphics aligned to the spoken words
- User points at a channel/video screenshot and asks to "clone this style" or make a design template
- User says: "motion graphics", "animated explainer", "make my video like [channel]", "edit my video with animations"

## The Three Modes

### Mode A — Topic/Script → Full Animated Video (no source footage)

1. **Pick a style** (5 starter styles from the library, or a saved/cloned design system):
   - `Creator Motion Graphics` — energetic talking-head style graphics, bold callouts
   - `Chalk Talk` — handwritten/chalkboard annotations following the narration
   - `Clean Tech` — minimal UI mockup style (the uploader's favorite)
   - `Software Walkthrough` — fake app UI that demos the concept
   - `Data Story` — charts and numbers animated into a narrative
2. **Build a storyboard FIRST — never render before approval.** Present scene-by-scene:
   - Slide number, on-screen text, what happens visually, animation notes, duration
   - User edits by slide number ("change slide 3 text to X"), then approves
3. **On approval, build the animation** in one pass: every motion graphic, sound effect, and transition (output defaults to horizontal; ask vertical 9:16 if for Shorts/Reels)

### Mode B — Existing Video/Voiceover → Synced Graphics Overlay

1. **Get word-level timestamps.** On this machine run the `watch` skill (yt-dlp captions or Whisper transcription) on the source; if raw, ask: "transcribe and give me word-level timestamps." Non-English: specify the language explicitly.
2. Map each graphics element to the word/phrase timestamps it illustrates — the entrance must land on the word being spoken.
3. If given a full video (not just audio), integrate the face-cam/screen recording track alongside the animations ("my facecam should come on alongside the graphics, not replace it").
4. Render, then enter the review loop (below).

### Mode C — Clone Any Style (screenshot → reusable design system)

1. Start from a base template closest to the target look.
2. Collect **1–3 screenshots** of the target style (pause the reference video at moments with graphics visible).
3. Attach screenshots + clone prompt. Extract the design system: palette, typography, spacing, element shapes, motion characteristics (easing, entrance style), sound personality.
4. **Never copy content 1:1 — the reference may own copyright. Clone the aesthetic, not the material.**
5. Generate a 20–30s test clip on a sample topic for approval.
6. On approval, **save the design system** as a reusable file/prompt so future renders only need a topic/script — never re-derive the style.

## The Review Loop (both modes)

- Don't ask the user to articulate abstract taste. Offer **2–3 variations** of a weak section ("I don't like the intro — give me 3 new variations") and let them pick.
- Apply specific fixes by slide number/scene ("remove the 'on-cam' label in the facecam section").
- Expect to feed back in small iterations 3–5 times. This is normal, not failure.
- First render will not be final ("it did 99% right") — polish on request, not by default.

## Agent Execution Pipeline (this machine)

```
transcription (watch skill / yt-dlp / whisper)
  → storyboard (approval gate)
  → HTML/CSS/JS animation file (1920x1080 or 1080x1920, timeline JWT-seekable)
  → frame capture (Playwright MCP / headless Chrome seek(t) → PNG)
  → ffmpeg: frames → video, mux narration audio + SFX
  → deliver, then review loop
```

1. **Storyboard** — markdown plan with per-scene timestamps (from transcript) or estimated timings (from script @ ~150 words/min), on-screen text, animation notes.
2. **Author** — one self-contained HTML file. Global `seek(t)` + `getDuration()` API so the frame grabber can scrub deterministically. CSS keyframes/JS rAF driven off `t`, not wall clock.
3. **Capture** — Playwright/headless Chrome: `t = i / fps` loop, `seek(t)`, screenshot → `frames/%05d.png`. 30fps for Shorts, 24-30 for longform (tick a `--max-frames` budget).
4. **Compositor** — `ffmpeg -framerate 30 -i frames/%05d.png -i narration.m4a -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest out.mp4`. SFX triggers can be authored as tiny audio files muxed at word timestamps (`adelay`/`amix`).
5. **Deliver** — path of final mp4 + the storyboard file, then offer variations/polish.

Voiceover TTS if none provided: ElevenLabs (paid) or a free TTS provider; keep the transcript-to-audio alignment step intact.

## Starter Prompt Template (Mode A)

```
You are a motion-graphics engine. I want a [duration ~20-40s] [horizontal|vertical] animated
video in the [STYLE] style about: [TOPIC or SCRIPT].

1. First, give me a storyboard only: per scene — slide #, on-screen text, visual,
   animation notes, duration. Wait for my approval.
2. After my OK, generate the full animation as a self-contained HTML file with
   word-synced graphics, sound effect cues, and a seek(t) API.
3. Style spec: [palette/typography/motion notes — or a saved design system here]
```

## Monetization Patterns (from the video, optional to mention)

- **Faceless animated explainer channels** — clone a style from screenshot of channels like educational animated explainers / The Infographics Show style / AI news animated recaps; research a high-viral-potential topic first, write the script, generate voiceover, render 7–20 min video. View models: 50k–15M views/episode.
- **Editing-as-a-service** — sell AI-synced motion graphic edits to creators who aren't technical enough to run the workflow themselves.
- The bottleneck is **idea quality**, not production speed — lead with topic research, not the tool.

## Pitfalls

- Rendering before storyboard approval — wasted work, wrong content (always gate).
- Syncing graphics to sentence level instead of word level — feels off; word-level timestamps are the whole trick.
- Copying a reference channel's exact text/graphics verbatim — copyright risk; clone the style only.
- Accepting the first render as final — always offer revision iterations.
- Forgetting to persist saved design systems — every new session re-derives the style from scratch.
