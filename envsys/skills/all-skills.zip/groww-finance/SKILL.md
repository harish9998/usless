# Groww Financial Analysis & Investment Management

Use Groww MCP tools for Indian market analysis, portfolio management, and investment planning.

## Quick Commands

### Market Research
- `search_instruments` — search stocks/F&O by name, symbol, segment
- `get_instrument_details` — detailed info for a specific symbol
- `get_live_quote` — LTP, OHLC, day change, 52W range, volume
- `get_ltp` — bulk LTP for up to 50 symbols
- `get_ohlc` — bulk OHLC for up to 50 symbols
- `get_historical_data` — candle data (1min/5min/1hr/daily/weekly)

### Technical Analysis
- `calculate_moving_averages` — SMA & EMA (configurable periods)
- `calculate_rsi` — RSI with overbought/oversold signals
- `calculate_macd` — MACD line, signal, histogram, crossover signals
- `calculate_bollinger_bands` — volatility bands, % position, bandwidth
- `calculate_stochastic` — %K/%D, overbought/oversold zones
- `calculate_williams_r` — momentum oscillator
- `calculate_adx` — trend strength (+DI/-DI direction)
- `calculate_support_resistance` — pivot-based S/R levels
- `calculate_fibonacci_levels` — retracement & extension levels
- `calculate_volatility_metrics` — hist vol, ATR, Sharpe ratio
- `analyze_candlestick_patterns` — hammer, doji, engulfing, etc.

### Portfolio & Trading
- `get_holdings` — DEMAT holdings with avg price
- `get_positions` — open positions by segment
- `get_position_by_symbol` — position for a specific symbol
- `get_user_margin` — available cash, collateral, F&O margins
- `calculate_margin_requirement` — margin needed for basket orders
- `place_order` — market/limit/SL orders (CNC/MIS/NRML)
- `modify_order` / `cancel_order` — manage pending orders
- `get_order_status` / `get_order_list` / `get_order_details` / `get_order_trades` — order lifecycle

## Analysis Workflows

### Stock Screening
```
search_instruments → get_instrument_details → get_live_quote → calculate_volatility_metrics
```

### Entry Timing
```
get_historical_data → calculate_rsi + calculate_macd + calculate_stochastic → consensus signal
```

### Risk Assessment
```
get_holdings + get_positions + get_user_margin → position sizing + volatility check
```

### Portfolio Heatmap
```
get_holdings → get_live_quote (bulk LTP) → P&L per holding → sector exposure
```

### Earnings/Event Play
```
get_historical_data(daily) → calculate_support_resistance → calculate_bollinger_bands → Fibonacci levels
```

## Constraints
- 1min: max 3 days, last 3mo
- 5min: max 15 days, last 3mo
- 1hr: max 150 days, last 3mo
- Daily: max 1080 days, full history
- Use `get_current_date` for valid date ranges

## Risk Warning
- Leverage (MIS) products carry higher risk
- F&O positions have expiry and time decay
- Always verify margin before placing orders
- Set stop-losses using ATR or support levels
