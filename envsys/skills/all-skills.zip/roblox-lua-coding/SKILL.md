---
name: roblox-lua-coding
description: >
  Luau/Roblox script generator. Creates server scripts, client scripts,
  modules, DataStores, and optimized game systems. Uses Roblox best practices
  including OOP, remote events, and proper networking.
  Trigger: "write roblox script", "roblox lua", "roblox code",
  "generate roblox module", "roblox datastore",
  "roblox server script", "roblox UI script"
---

# Roblox Lua Coding Skill

## Patterns Used
- OOP with metatables
- RemoteEvent/RemoteFunction for networking
- DataStore with auto-save and error handling
- ModuleScript for code organization
- Coroutines for async operations
- TweenService for smooth UI

## Output Format
Each script includes:
- Purpose comment block
- Dependencies (required modules)
- Well-named functions
- Error handling
- Type annotations where applicable

## Script Types

### Server Scripts
```lua
-- DataStoreManager.lua
-- EconomyService.lua
-- InventoryService.lua
-- CombatService.lua
-- SaveLoadService.lua
```

### Client Scripts
```lua
-- UIController.lua
-- CameraController.lua
-- InputHandler.lua
```

### ModuleScripts
```lua
-- BaseClass.lua (OOP)
-- SignalManager.lua
-- TweenHelper.lua
-- MathUtils.lua
```

## Best Practices
- Use BindToClose for cleanup
- Rate-limit remote events
- Sanitize all player input
- Use pcall for DataStore operations
- Cache expensive computations
- Minimize network traffic
- Use object pooling for projectiles/effects
