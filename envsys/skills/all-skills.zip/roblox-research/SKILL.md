---
name: roblox-research
description: >
  Roblox market research and trend detection. Searches TikTok, YouTube Shorts,
  Reddit, and Roblox Discover for trending games, mechanics, and monetization
  patterns. Returns structured trend reports.
  Trigger: "research roblox", "roblox trends", "roblox market",
  "what games are trending", "roblox competitor analysis",
  "analyze roblox market", "roblox daily research"
---

# Roblox Research Skill

## Input
A research query (genre, game type, mechanic, or "daily research")

## Process
1. Search TikTok for Roblox game trends
2. Search YouTube Shorts for viral Roblox content
3. Search Reddit (r/roblox, r/robloxgamedev)
4. Search Roblox Discover for top games by genre
5. Collect top 10 games: visits, retention, growth rate
6. Identify patterns and underserved niches

## Output Format
```markdown
## Trend Report

### Top Games
| Game | Genre | Visits | Growth | Key Mechanic |
|------|-------|--------|--------|-------------|

### TikTok Trends
- Top hooks:
- Visual patterns:
- Sounds:

### Underserved Niches
- Gap 1:
- Gap 2:

### Recommendations
- Game idea 1:
- Game idea 2:
```
