---
name: opencode-plugin-dev
description: >
  Author, wire, and debug OpenCode (v2) plugins and local MCP servers.
  Covers the plugin module contract, tool registration, execute arity,
  permission/options reality, auto-discovery from plugins/, and the
  marker-poll load-test and real-task harness. Trigger: "opencode plugin",
  "write a plugin", "plugin won't load", "Plugin must export a default",
  "ctx.tool.transform", "register a tool in opencode", "custom MCP server",
  "npx slow mcp startup", "opencode config drift".
---

# OpenCode v2 Plugin & MCP Development

All contracts below are runtime-verified against `@opencode/cli` v2.0.32
(`ctx.app = { name: "cli", version: "2.0.32", channel: "latest" }`).
Do not substitute recollection for these; re-probe if the version changes.

## 1. Plugin module contract (v2)

A plugin must default-export a **plain object** with `id` and one of `setup` / `effect`:

```js
export default {
  id: "my-plugin",
  setup: async (ctx) => {
    // ctx.app, ctx.location, ctx.options, ctx.tool, ctx.generate, ctx.storage,
    // ctx.session, ctx.shell, ctx.rpc, ctx.agent, ctx.command, ctx.credential,
    // ctx.event, ctx.aisdk, ctx.permission
  },
};
```

Failure string when wrong (this is the exact text to grep for):

```
Plugin must export a default definition with an id and an effect or setup function
```

- `Plugin.define({...})` is **not required** for a local plugin; plain object loads.
- `setup(ctx)` is async-capable and runs once at session start.
- If the plugin lives outside `plugins/`, the file inside `plugins/` must be a
  **default re-export bridge**, not a namespace re-export:

```js
export { default } from "file:///C:/abs/path/to/src/index.js";
```

A `import { x } from ...` + named re-export bridge will fail to load.

## 2. Discovery and config

- `plugins/` is **auto-discovered**. No entry in `opencode.json` is needed.
- The config key is `plugins` (plural) if you do declare one. There is no
  `plugin` (singular) key; a `prime-agent.json` style sidecar is not read.
- `opencode plugin check` is **not** a load test — it does not execute the
  module. See section 5 for a real one.
- Two config files can coexist and drift: `opencode.json` and `opencode.jsonc`.
  Apply every change to **both**, or one silently wins.
- `opencode debug config` prints an **array of 4 config sources**:
  `0` = `opencode.json`, `1` = `opencode.jsonc`, `2` = `.config/opencode`,
  `3` = `.opencode`. Its stdout is **UTF-16LE with BOM** — `>` redirection
  will produce a file you cannot read with a naive parser.
- In `opencode debug config` (normalized) MCP servers appear under
  `mcp.servers`; in the raw files they are direct children of `mcp`.
  Do not "fix" this difference — it is just normalization.

## 3. Registering a tool

```js
await ctx.tool.transform((tools) => {
  tools.add({
    name: "my_tool",
    description: "...",
    options: { codemode: false },
    input: { type: "object", properties: { task: { type: "string" } }, required: ["task"] },
    output: { type: "object", properties: { text: { type: "string" } }, required: ["text"] },
    execute: async (input, execCtx) => ({ output: {...}, content: "..." }),
  });
});
```

- `tools.add(...)` returns **`undefined`**. Registration success cannot be read
  from the return value; it must be inferred from absence of error plus a
  successful call by name.
- `input` / `output` accept **raw JSON Schema**. `effect`'s `Schema` is not
  mandatory.
- Do **not** add `additionalProperties: false`; the arg validator (`validateArgs`)
  requires an explicit `required` array, so keep `required: ["task"]`-style keys.
- Tool return shape is `{ output, content }`. Keep the output schema minimal.
- There is no dedicated "tool registered" log line. Verify by calling it.

## 4. execute() arity — 2 args

```js
execute: async (input, execCtx) => { /* ... */ }
```

| Need | v1 | v2 |
|---|---|---|
| validated args | arg0 | arg0 |
| working directory | `context.directory` | `ctx.location.directory`, captured by closure at setup |
| interactive prompt | `context.ask` | none — no equivalent |
| abort | `context.abort` | `execCtx.signal` |

`execCtx` = `{ sessionID, agent, messageID, id, progress, signal }`.
It has **no** `directory` and **no** `ask`. If a port references them, it is a
v1 plugin.

## 5. Permission and options reality (do not overclaim)

- `options.permission` gating is **not** available to a plain-object plugin.
  Observed option vocabulary in shipped tools:
  `{ codemode: false }`, `{ codemode: false, permission: "edit" }`
  (only on `patch`/`edit`), `{ namespace: "opencode", codemode: true }`
  (opencode-owned), `{ ..., pinned: true }`.
- Therefore: **omit `options.permission` entirely** and say so. Gate write
  modes behaviourally instead — e.g. refuse write modes unless the caller
  explicitly passes `require_confirmation: false`, and document that in the
  tool description.
- Call that a *behavioural gate in the tool description*, never a security or
  permission gate. Overclaiming here is the most common defect in ported plugins.
- Config-level `permissions` / `policies` blocks exist only in `opencode.jsonc`
  in this environment, and their observed action vocabulary is limited to
  `["provider.use"]`. Do not invent action names.

## 6. Local MCP servers: npx is the problem

Measured on Windows, warm npx cache, MCP `initialize` handshake:

| Launch method | avg handshake |
|---|---|
| `npx -y <pkg>` | **8648 ms** (9622 ms per server under concurrent spawn) |
| `node <cached entry>` | **576 ms** |

Cause is npm CLI startup cost, multiplied by ~12 concurrent spawns at session
start; symptom is servers that "time out on cold start" while being perfectly
healthy. **Fix the launch method, do not delete the servers.**

1. `npm install` all needed packages into one stable prefix, e.g.
   `C:\Users\HARISHJASWAL\.config\opencode\mcps`.
2. Point each server's command at a direct `node <abs entry>`.
3. Preserve trailing args verbatim (`--db <path>`, `--auto-install-plugin`, and
   positional root dirs are easy to drop in a mechanical rewrite).
4. Never point at a volatile cache path such as `_npx\<hash>`; it changes.
5. Back up both config files before a bulk rewrite and assert afterwards:
   parse OK, byte count, line count, server count, no stray empty key, no
   double comma.

## 7. Testing harness (marker-poll, not exit code)

`opencode run --standalone` does **not** self-terminate; waiting on the process
will hang. Poll the log for a marker instead and kill by PID.

```powershell
$log = "C:\Windows\Temp\opencode\run.err.log"
$p = Start-Process -FilePath "C:\Users\<u>\AppData\Roaming\npm\node_modules\@opencode\cli\bin\opencode.exe" `
      -ArgumentList @("run","--standalone","--model","<free-model>","<prompt>") `
      -RedirectStandardError $log -RedirectStandardOutput "C:\Windows\Temp\opencode\run.out.log" `
      -PassThru -WindowStyle Hidden
# poll up to N s for the marker, then:
Stop-Process -Id $p.Id -Force
```

- `Start-Process -FilePath "opencode"` **fails** (resolves to a `.ps1` shim).
  Use the full `...\@opencode\cli\bin\opencode.exe` path.
- Add `--format json --auto --log-level warn`. Without `--format json` the
  non-interactive run leaves **stdout empty** and writes TUI text to stderr, so
  a marker-poll on stdout never fires. `--format json` emits JSON events you can
  parse line-by-line (types seen: `step_start`, `tool_use`, `step_finish`).
- Read the live redirect file with `Get-Content -Raw`. `[IO.File]::ReadAllText`
  on a file another process is still writing throws `IOException` and silently
  kills the poll loop.
- PowerShell variables are **case-insensitive**: a `[string]$Deadline` param and
  a local `$deadline` are the *same* variable. `AddSeconds()` then receives a
  DateTime and the loop never runs. Name params and locals distinctly.
- A model can stall after a long tool result even when the tool call itself
  succeeded. Verify by dumping the events: if you see the expected `tool_use`
  with `state.status: "completed"` and untruncated output, then a later
  `step_start` with no assistant text, that is a **model/harness stall, not a
  skill-content failure**. Re-run with a different free model before editing the
  skill.
- Load test: marker = your plugin's own init line; success = marker present AND
  no `failed to load|LoadError|invalid plugin|effect or setup|must export a default`.
- Real-task test: marker = a terminal line from your tool (`... run completed`,
  `... run failed`, `... not found`), plus proof the tool was actually called by
  name in the tool-call log.
- Pin a **free** model for any throwaway run. A credential failure in the tool's
  own subprocess (e.g. `No API key found for the selected model`) is a
  downstream credential issue, not a plugin-load bug — separate the two before
  "fixing" anything.

## 8. Debugging checklist

1. Exact failure string present? → export shape problem (section 1).
2. Loads, but tool absent? → `tools.add` ran inside a non-`transform` path, or
   `setup` threw earlier. Wrap risky setup steps in try/catch and log.
3. Tool present, throws on call? → arity/`execCtx` mismatch (section 4).
4. Works in one config file only? → drift between `opencode.json` and
   `opencode.jsonc` (section 2).
5. Cold-start timeouts across many servers at once? → npx contention (section 6),
   not per-server breakage.
6. Logging: use `console.error` with a `[plugin-id]` prefix wrapped in try/catch.
   Do not assume a logging client exists on `ctx`.
