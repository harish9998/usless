---
name: roblox-marketing
description: >
  Roblox game marketing content creator. Generates viral TikTok scripts,
  YouTube Shorts, thumbnails, SEO-optimized descriptions, and social media
  posts. Uses hook psychology and platform-specific formats.
  Trigger: "roblox marketing", "roblox thumbnail", "roblox tiktok",
  "roblox seo", "game description", "roblox shorts",
  "promote roblox game", "roblox viral"
---

# Roblox Marketing Skill

## Outputs

### TikTok Script
```markdown
Hook (0-3s):
Body (3-15s):
CTA (15-20s):
Sound suggestion:
Caption:
Hashtags:
```

### YouTube Shorts Script
```markdown
Hook (0-3s):
Content (3-25s):
CTA (25-30s):
Title:
Thumbnail text:
```

### Game Description (SEO)
```markdown
Paragraph 1: Hook + core concept
Paragraph 2: Key features (bulleted)
Paragraph 3: Social/community
Paragraph 4: Update frequency
Tags: [5-10 relevant tags]
```

### Thumbnail Brief
```markdown
Background:
Character pose:
Text overlay:
Color scheme:
Faces (yes/no):
```
