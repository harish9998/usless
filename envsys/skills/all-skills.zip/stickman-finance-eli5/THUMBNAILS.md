# THUMBNAILS — decoded branding layer

Evidence: ASSETS/thumb_reference.jpg (1280x720, video 1GowFTjbUnk).
All [INTERPRETED high].

## Anatomy (top → bottom)

1. **Background**: dark night-city skyline — desaturated teal-black buildings
   with subtle window dots, darker at edges (vignette feel).
2. **Title wordmark**: HUGE white bold brand/topic word ("NVIDIA") top-right,
   ≈18% of canvas height; brand's real logo top-left.
3. **Central character**: protagonist bust, center-bottom (30-40% canvas
   height), same stickman design as video but MORE detailed (wrinkle lines,
   grin with teeth) — thumbnail-grade polish.
4. **Story props**: 4-5 brand/icon tiles hung on RED wires from the top,
   arranged left+right of the character like puppets/dependencies.
5. **Story line**: red connection lines from the main logo to each hanging
   icon — the relationship IS the hook (dependency web).

## Rules for any topic

- One dominant character bust center-bottom; face readable at 200px.
- The topic's "web of power/money" visualized with 3-5 icon tiles + red lines.
- Dark background, neon red/pink accents only; white wordmark for the topic.
- One-glance sentence: "[SUBJECT] controls/affects [these things]".

## Template

`ASSETS/SVG/thumbnail_layout.svg` — layout guide with labeled zones.
Reference image: `ASSETS/thumb_reference.jpg`.
