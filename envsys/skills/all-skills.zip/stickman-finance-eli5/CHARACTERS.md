# CHARACTERS — design system

Derived from ASSETS/reference_frames. All rules [INTERPRETED high] unless noted.

## Anatomy (locked)

- Head = **50-70% of figure height**, near-perfect circle, skin `#F2D6B3`.
- Face: **two dot eyes** (`#000`, r≈7px @400px figure) + **one short line
  mouth**. No nose, no eyebrows by default.
- Expression changes ONLY via: mouth line curve/length, eyebrow lines when
  angry/worried, eye size for shock (shot_37 squint, shot_19 angry brows).
- Body: small relative to head — shirt is a simple rounded trapezoid;
  arms/legs are plain thick lines (≈10px @400px figure), minimal hands.
- Every element outlined `#111` ≈8px @400px figure (≈6px @1080p frame).

## Identity rules

- Identity = **hair shape/color + clothing color + optional glasses**.
  Nothing else distinguishes characters. (shot_04 vs shot_09 vs shot_16)
- **Recurring characters keep identical features in every scene** — pick a
  locked spec per character and never vary it (Jensen: black flat-top hair +
  glasses + light-blue shirt, shot_20/21/31-33/37).
- Named real people get a nameplate/name-tag (template K), not facial detail.

## Cast archetypes (fill per video)

| Archetype | Spec pattern | Example evidence |
|---|---|---|
| PROTAGONIST | distinctive hair + glasses often; hero shirt color | shot_20 (Jensen) |
| AUTHORITY / GATEKEEPER | gray/white hair, plaid or suit; often seated behind desk | shot_25, shot_37 (SEGA CEO) |
| EVERYMAN / COWORKER | white shirt, plain hair, background roles | shot_21 (white-shirt suits) |
| CHILD / YOUNG VERSION | protagonist features, smaller + backpack prop | shot_15 |
| CROWD | gray/white generic heads, no distinguishing marks | shot_04 audience |

## Crowd rule

Background people are desaturated (gray/white heads) so the protagonist's
color pops. Never detail crowd faces. (shot_09, shot_10, shot_04)

## Props that read as character

Backpack, mop/bucket, briefcase, tray of plates, folder — props assign jobs
and class silently. (shot_01, shot_15, shot_16, shot_19, shot_38)
