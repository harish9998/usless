# ASSETS — index

## SVG starter kit (`SVG/`) — editable production templates

Style-accurate vector assets (flat fills, thick #111 outlines, palette hexes
from COLOR_PALETTE.json). Import into any editor; restyle per project.

| File | Use | Template |
|---|---|---|
| `stickman_base.svg` | blank character body (swap hair/shirt) | any |
| `stickman_protagonist.svg` | hero spec: black hair + glasses + blue shirt | PROTAGONIST |
| `stickman_authority.svg` | gray hair + plaid sweater | AUTHORITY |
| `stickman_crowd.svg` | generic desaturated background person | CROWD |
| `chapter_card.svg` | black card + handwritten title placeholder | C |
| `sticky_note.svg` | yellow label note with fold | B, J |
| `nameplate.svg` | yellow desk nameplate (NAME / ROLE) | K |
| `desk_calendar.svg` | year stamp prop | J |
| `payroll_jar.svg` | money-stakes prop + label | B |
| `whiteboard_chart.svg` | green growth vs red flat line chart | D |
| `diner_bg.svg` | retro diner set: checkered floor, red booths | E |
| `brand_hero_chip.svg` | dark-map + hero prop placeholder | M |
| `thumbnail_layout.svg` | 1280x720 thumbnail zone guide | thumbnails |

## Reference frames (`reference_frames/`, 42 files)

Evidence frames from the source video — the VISUAL SPEC. In art briefs,
"match shot_NN" is a binding instruction. Naming: `shot_NN_t<seconds>.jpg`.
Key exemplars: shot_01 (vignette), shot_07 (chapter card), shot_16 (caption
overlay), shot_18 (sticky labels), shot_24-29 (dialogue coverage),
shot_31 (year stamp), shot_37 (nameplate), shot_39 (payroll), shot_41 (chart),
shot_42 (name tags).

## Single files

- `palette.png` — ffmpeg palettegen output (8 dominant colors; dark-skewed)
- `thumb_reference.jpg` — decoded thumbnail (see THUMBNAILS.md)

## Generated assets (`generated/`)

User-generated images (via ChatGPT/image models, prompts in
`../IMAGE_GEN_MASTER_PROMPTS.md`), verified by the agent against the style
contract before storage. Naming: `<category>__<name>.png` with categories
character / prop / bg / graphic / combo.

## Not included (generate per project)

Voices, music, SFX — see SOUND_DESIGN.md targets. Real brand logos — insert
per topic. Handwritten font — any casual marker family (see TYPOGRAPHY.md).
