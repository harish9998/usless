---
name: stickman-finance-eli5
version: "1.0.0"
description: >
  Stickman finance-explainer production skill, reverse-engineered from Crayon
  Capital ("NVIDIA Explained Like You're 5"). Give this skill any TOPIC (e.g.
  "Fed rate cuts", "How Amazon actually makes money", "The rise of ASML") and
  it plans, scripts, and edits a full 11-15 min explainer video in the decoded
  house style: flat 2D stickman cartoon, thick outlines, muted colors,
  handwritten captions, character vignettes, dialogue scenes, whiteboard
  charts, black chapter cards. Triggers: "make a finance explainer about X",
  "make a video about X in the stickman style", "stickman ELI5", "explain X
  like I'm 5 (video)", "use the decoded channel style".
argument-hint: "<topic> [--script-only|--plan-only]"
allowed-tools: Bash, Read, Write, Glob, Grep, Task
license: MIT
---

# /stickman-finance-eli5

Production recipe for a finance/economics explainer in the Crayon Capital
stickman style. Evidence lives beside this file: `STYLE_ANALYSIS.md` (what the
reference does, with frame citations), `EDITING_RULES.md` (hard cut/caption
rules), `TIMING_PRESETS.json` (measured numbers), `SCRIPT_TEMPLATE.md`
(narrative skeleton), `CHARACTERS.md` (character design system), `LAYOUT.md`
(composition/safe zones), `THUMBNAILS.md` (thumbnail recipe), and `ASSETS/`
(`SVG/` = editable starter asset kit; `reference_frames/` = 42 evidence
frames = the visual spec; see `ASSETS/README.md`), plus `TRANSITIONS.md`,
`SOUND_DESIGN.md`, `TYPOGRAPHY.md`, `COLOR_PALETTE.json`.

Style honesty contract: claims are tagged MEASURED (ffmpeg numbers) or
INTERPRETED (visual judgment + confidence). Follow the measured numbers; treat
interpreted conventions as strong defaults you may deviate from deliberately.

## Pipeline — topic → video

### 1. Script (use SCRIPT_TEMPLATE.md)

- Target 11-15 min ≈ 1,700-2,200 spoken words at ~150 wpm [aligned to measured 14.5 min reference].
- Follow the 5-act skeleton: HOOK (character vignette cold open → object gag
  → stakes) → SETUP/ORIGIN → EXPLAINER CORE → PAYOFF/TWIST → OUTRO.
- Every fact gets a visual job: a prop with a handwritten label, a character
  beat, a chart, or a metaphor scene. No fact may float unsupported.
- Dialogue is written AS speech lines; narration is written AS voice-over
  paragraphs. Mark each line: VO / DIALOGUE / ON-SCREEN TEXT.

### 2. Scene plan

- Convert each script beat into one or more scene templates (A-M below).
- Aim for the measured cadence of the reference: median shot **4.5 s**, ~2.1
  cuts/10 s, opening = one **5 s hold**, 3 cuts in the 5-15 s window
  [MEASURED]. Dialogue scenes cut to coverage every 3-8 s.
- Output a shot list: timestamp, template, on-screen action, caption text,
  asset needs.

### 3. Scene templates (decoded from reference)

| ID | Template | Reference evidence |
|----|----------|--------------------|
| A | Character vignette cold open — single character mid-action, no cut for ~5 s | ASSETS/shot_01, shot_02 |
| B | Object + handwritten note gag — close-up prop with taped/written label posing a question or stakes | shot_02 ("3D GRAPHICS PERFORMANCE FUTURE"), shot_39 ("PAYROLL", "ONLY ENOUGH FOR 1 MONTH") |
| C | Black chapter card — white handwritten text on pure black, 1.5-3 s; mid-video cards may be a single letter building a word | shot_03 ("34"), shot_07 ("Two Years Building the Wrong Chip"), shot_40 ("E") |
| D | Whiteboard presenter — character beside whiteboard with 2-3 line chart (green vs red), brand logos, handwritten labels | shot_04, shot_41 |
| E | Dialogue scene with coverage — diner/office set; alternate wide, over-shoulder, close-ups; caption = the spoken line in white handwritten | shot_24-29, shot_32-36, shot_37 |
| F | Split-panel time montage — 1→3→4 vertical panels slide in, each a separate mini-scene | shot_11 → shot_12 → shot_13 |
| G | Metaphor scene — abstract concept as symbolic tableaux (chess + capitol dome + storm clouds) | shot_06 |
| H | Establishing shot — building exterior with brand colors, sky + clouds | shot_14, shot_24 |
| I | Character close-up reaction — head fills 40-70% of frame, single emotion | shot_20, shot_23 |
| J | Era stamp — physical date prop (desk calendar "1993") or location sign ("KENTUCKY, USA →") | shot_10, shot_31 |
| K | Identity prop — yellow nameplate/name tag naming a person or role ("SHOICHIRO IRIMAJIRI CEO", "TSMC RESEARCHER") | shot_37, shot_42 |
| L | Suspense beat — empty doorway/held static shot before an entrance or reveal | shot_34 → shot_35 |
| M | Brand prop hero — product/entity as 3D-ish flat prop over dark map/background | shot_05 (NVIDIA chip on world map) |

### 4. Visual production spec

- Draw/generate every asset to `COLOR_PALETTE.json` + `ASSETS/` frames:
  flat fills, NO gradients, thick black outlines (~4-6 px at 1080p), muted
  saturation, simple dot-eyes + line-mouth faces.
- Start from the editable SVG kit `ASSETS/SVG/` (characters, chapter card,
  sticky note, nameplate, calendar, payroll jar, whiteboard chart, diner set,
  brand hero, thumbnail layout) — restyle instead of redrawing from scratch.
- Character specs per `CHARACTERS.md`; shot composition per `LAYOUT.md`
  (caption safe zone top-center, coverage rotation for dialogue).
- Character design: large round head (skin #F2D6B3), small body, minimal
  props; identities via hair color/shape, glasses, clothing color — not via
  detail. Named characters recur with identical features.
- Typography per `TYPOGRAPHY.md`. Captions are the spoken line, white
  handwritten, top-center, ≤10 words visible at once.
- Reference `ASSETS/` frames in any art brief: "match shot_08" is the spec.

### 5. Edit (apply EDITING_RULES.md)

- Cut to TIMING_PRESETS cadence; hard cuts only; black chapter cards as
  section breaks; split-panel builds for time passage.
- Captions pop in as each line starts; prop labels stay ≥1.5 s.

### 6. Audio (apply SOUND_DESIGN.md)

- Voice-over mastered to **-18 LUFS integrated, LRA ≤4** [MEASURED on
  reference]; music bed low and consistent, no loudness spikes; light
  comedic SFX on gags and reveals [INTERPRETED medium].

### 7. QC checklist (run before delivery)

1. Median shot length within 3.5-6.0 s [measured target 4.5 s].
2. Opening shot is a ≥4 s hold, first cut lands 5-8 s.
3. Every chapter transition uses template C.
4. No gradients anywhere; outlines on every element.
5. Every caption ≤10 words, handwritten style, top-center.
6. Every fact has a visual job (prop label / character beat / chart / metaphor).
7. Integrated loudness -18 ±1 LUFS, LRA ≤4.
8. All numbers/places/people labeled with template J/K props.

### 8. Modes

- Default: full pipeline (script + shot list + edit rules + asset briefs).
- `--script-only`: deliver SCRIPT_TEMPLATE-filled script with visual jobs marked.
- `--plan-only`: deliver shot list + asset briefs without script prose.

## Known limitations

- Style decoded from ONE reference video (first 10 min of 1GowFTjbUnk, 42
  frames). Outro/CTA conventions and end-card behavior were not sampled
  [NOT ANALYZED].
- Audio interpretation (music genre, SFX) is inferred from loudness metrics
  and frame context, not from listening [INTERPRETED medium].
- Palette hexes are visual approximations from frames, not instrument reads
  [INTERPRETED high].
