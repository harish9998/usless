# IMAGE-GEN MASTER PROMPTS — asset generation via ChatGPT / any image model

Workflow: copy the **STYLE CORE** + one asset prompt below (replace
[BRACKETS]) → paste into ChatGPT/image gen → save the image → hand it to the
agent → agent verifies style compliance and stores it in
`ASSETS/generated/` + indexes it + pushes to the repo.

---

## 1. STYLE CORE — prepend to EVERY prompt, never modify

```
Flat 2D cartoon vector illustration, finance-explainer animation style.
Thick bold black outlines on every single element. Completely flat solid
color fills — NO gradients, NO shading, NO highlights, NO glow, NO texture.
Muted desaturated palette only: cream skin #F2D6B3, charcoal #1A1A1A,
olive green #8A9A6B, warm brown #A5713F, muted navy #1E2A38, soft blue
#A8C4DC, off-white #F5F5F0. Characters: oversized round head (head = 60% of
full figure height), tiny solid black dot eyes, one short straight line
mouth, NO nose, stick-thin limbs with simple rounded hands. Clean minimal
flat vector look. 16:9.
```

**Mode suffixes (append):**

- CHARACTERS → `Full body, standing, centered. Plain solid #EDEDED background so the character can be cut out.`
- PROPS → `Single object centered, plain solid #EDEDED background so it can be cut out.`
- BACKGROUNDS → `Empty scene, no characters, no text anywhere.`
- UNIFIED → `All elements share identical outline thickness and equal saturation so the image reads as ONE illustration, not a collage.`

---

## 2. CHARACTERS (one per image)

- **P1 PROTAGONIST** — `[STYLE CORE] One cartoon man: oversized round head, short black flat-top hair, black rectangular glasses, light blue button-up shirt #A8C4DC, stick arms and legs. Neutral friendly face: dot eyes, straight line mouth. [CHARACTER MODE]`
- **P2 AUTHORITY / BOSS** — `...gray side-parted hair, green plaid sweater #6E7B5A with darker #4E5A3E stripes, older posture, arms behind back...`
- **P3 CROWD / EVERYMAN** — `...plain bald gray-white head, white shirt, zero distinguishing features...`
- **P4 YOUNG VERSION** — `...smaller child version of P1: same black hair + light blue shirt, olive green backpack...`
- **P5 EXPRESSION SHEET** — `...same character shown 4 times side by side: happy (curved line mouth), worried (squiggly mouth + eyebrow lines), angry (angled eyebrow lines), shocked (tiny circle mouth). Same face every time.`

Identity rule: never change hair/eye/clothing spec between generations —
copy the exact bracket text every time.

## 3. PROPS

- **sticky note** — `yellow sticky note #F7E88C, slightly rotated, small folded corner, black handwritten caps text "[TEXT]"` 
- **nameplate** — `wooden desk nameplate, yellow plate #E8C558, text "[NAME]" and smaller "[ROLE]"`
- **desk calendar** — `cream desk flip calendar, wire spiral top, big handwritten year "[YEAR]"`
- **payroll jar** — `glass jar with gray lid, green banknotes and coins inside, white label taped on front with handwritten "[TEXT]"`
- **thick book** — `thick hardcover book standing, spine label with handwritten "[TOPIC WORD]"`
- **CRT computer** — `beige 1990s CRT monitor + keyboard on wooden desk`
- **diner table set** — `red soda cup with straw, burger on white plate, checkered paper`
- **brand chip** — `green computer chip #76B900 with small white swoosh mark, pins on edges`
- **whiteboard chart** — `whiteboard with green rising jagged line vs red flat line, small handwritten labels`

Text on props: ≤3 words, ALL CAPS handwritten — longer text gets garbled;
add it in the editor instead.

## 4. BACKGROUNDS (empty scenes, no characters, no text)

- **B1 DINER** — `retro diner interior: bottom 30% black-white checkered floor, red booth seats on left and right, beige wall, two windows with light blue sky, wooden table center`
- **B2 OFFICE 90s** — `office room, gray walls, wooden desks with CRT computers, whiteboard on wall`
- **B3 AIRPORT** — `airport terminal interior, glass wall showing a white airplane and blue sky, row of gray chairs`
- **B4 SCHOOL GATE** — `tall black iron gate between two brick pillars, brick building behind, blue sky`
- **B5 HOUSE** — `simple white suburban house with gray roof, teal sky #9FC5E8, olive lawn`
- **B6 NIGHT ROOM** — `dark navy bedroom #1E2A38, wooden desk with warm yellow lamp, window showing crescent moon`
- **B7 WORLD MAP** — `dark world map, very dark green continents #243A18 on near-black #14200F background`
- **B8 METAPHOR** — `giant chess pieces on a chessboard floor, gray government dome building behind, dark storm clouds above`
- **B9 CAPITOL / INSTITUTION** — `gray stone government building with dome, columns, flat blue sky`

## 5. GRAPHIC ELEMENTS

- **chapter card** — `pure black 16:9 frame, centered white casual handwritten marker text "[TEXT]", nothing else`
- **split-panel frame** — `16:9 frame divided into [3/4] vertical panels separated by thick black gutters, each panel a different flat muted color scene, no characters`
- **thumbnail base** — `dark night city skyline, teal-black buildings with tiny window dots, empty center, no characters, no text`

## 6. COMBINE ANY ASSETS — master combination prompt

```
[STYLE CORE]
Scene composition: [CHARACTER P# spec] + [PROP spec] + [BACKGROUND B# spec].
[CHARACTER] is [position: left/center/right, small/large], [action: holding / pointing at / sitting behind] the [PROP].
[UNIFIED]
On-image text — exactly this and nothing else: "[TEXT ≤3 WORDS]" in casual handwritten marker font, placed on [element].
```

Rules: max 1 character + 1 prop + 1 background per image; max 2 accent
colors; composition follows LAYOUT.md (subject center-low, heads ~35-55%
height); the UNIFIED suffix is what stops the "sticker collage" look.

## 7. Quality bar (every image must pass)

1. Thick black outline on EVERY element ✓
2. Zero gradients / shading / glow ✓
3. Palette within COLOR_PALETTE.json (± one brand color) ✓
4. Faces: dot eyes + line mouth, no nose ✓
5. On-image text ≤3 words, legible, handwritten style ✓

## 8. Storage workflow (agent side, on receiving an image)

1. **Verify** against §7 (read the image; cite which rule passed/failed).
2. **Pass** → save as `ASSETS/generated/<category>__<name>.png`
   (categories: character / prop / bg / graphic / combo), add a row to
   `ASSETS/README.md`, commit + push to the repo.
3. **Fail** → return the exact failed rule + a corrected prompt.
