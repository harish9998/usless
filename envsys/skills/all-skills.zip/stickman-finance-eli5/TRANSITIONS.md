# TRANSITIONS — what's allowed

Evidence: 42 shot-boundary frames, ASSETS/. **[INTERPRETED high]**: no
crossfades, whips, zoom-blurs, or dips were observed at any boundary — the
reference cuts hard.

## Allowed

1. **Hard cut** — default for everything.
2. **Black chapter card** (template C) — section breaks: hard cut to black,
   handwritten text, hold 1.5–3 s, hard cut out.
3. **Split-panel build** (template F) — for time passage: panels slide in
   sequentially until 3–4 vertical panels fill the frame, then hard cut to
   the next scene.
4. **Suspense hold → entrance** (template L) — static empty-door shot, then
   hard cut to the character entering.

## Forbidden (off-style)

- Crossfade/dissolve, whip pan, zoom transition, flash frame, dip to white.
- Gradient wipes of any kind.

## Duration notes

- Chapter card hold: 1.5–3 s [INTERPRETED medium — inferred from cut spacing].
- Panel slide-in: ~0.3–0.5 s per panel [INTERPRETED low — not frame-verifiable].
