# STYLE ANALYSIS — Crayon Capital "NVIDIA Explained Like You're 5"

Source: https://www.youtube.com/watch?v=1GowFTjbUnk — 1920x1080, 30 fps, 14.5 min.
Evidence: 42 frames in `ASSETS/` (shot_01–shot_42), measured on first 600 s.
Tags: **[MEASURED]** = ffmpeg numbers · **[INTERPRETED]** = visual judgment + confidence.

## 1. Format

- Flat 2D cartoon explainer. No live action, no 3D renders, no motion-graphics
  minimalism. **[INTERPRETED high]**
- Thick black outlines on every element; flat muted fills; zero gradients.
  **[INTERPRETED high — visible in every frame]**
- Characters: oversized round heads (~50-70% of figure height), dot eyes,
  single-line mouths, tiny stick limbs. Identities carried by hair shape/color,
  glasses, clothing. **[INTERPRETED high — shot_04, shot_09, shot_16, shot_20, shot_32]**

## 2. Pacing [MEASURED]

| Metric | Value |
|---|---|
| Shots in first 600 s | 125 |
| Median shot | 4.53 s |
| Mean | 4.8 s |
| p05 / p95 | 1.7 s / 10.13 s |
| Cuts per 10 s | 2.07 |
| First cut | 5.12 s (opening = one long hold) |
| Cuts in 0–5 s / 5–15 s / 15–30 s | 0 / 3 / 4 |

Reading: calm-but-continuous long-form pacing — roughly one cut every 4.5 s,
never frantic, never static. The hook is a deliberate 5 s character vignette
hold, then the cut rate never lets a shot outlive ~10 s. **[INTERPRETED high]**

## 3. Narrative architecture [INTERPRETED high from frame sequence]

1. **Cold open character vignette** (shot_01, 5.1 s hold): a single character
   mid-action in a workplace (waiter at a diner sink) — no title, no text.
2. **Object gag posing the theme** (shot_02): diner table close-up, a napkin
   with handwritten "3D GRAPHICS PERFORMANCE FUTURE" — the thesis delivered as
   a prop note, plus brand anchor (Denny's cup).
3. **Chapter card** (shot_03): pure black, small handwritten "34" — numbered
   chapter marker.
4. **Presenter + stakes** (shot_04): character at whiteboard, red declining
   line labeled NVIDIA, worried audience — the problem statement.
5. **Brand hero prop** (shot_05): NVIDIA chip floating over a dark world map.
6. **Metaphor scene** (shot_06): chess pieces against the Capitol dome under
   storm clouds — geopolitics as board game.
7. **Act structure**: biographical origin (shots 8–19: family photo, airport,
   Taiwan→Kentucky signs, split-panel time montage, school scenes, janitor
   beat) → career rise (AMD office, CRTs) → dialogue-driven turning points
   (Denny's meetings, SEGA rejection) → survival stakes (PAYROLL jar) →
   tech/history beats (whiteboard charts).

## 4. Scene conventions

- **Dialogue as handwritten overlay**: spoken lines appear as white
  handwritten text top-center ("CPUs can't carry this forever." shot_25; "So
  the plan is:" shot_28; "Microsoft just published the DirectX spec." shot_35;
  "The chip is a dead end." shot_37). No speech bubbles. **[INTERPRETED high]**
- **Labels ON props**: yellow sticky notes (STUDY HARD / SURVIVE LIFE,
  shot_18), book spine (SEMICONDUCTOR, shot_22), desk calendar (1993,
  shot_31), payroll jar note (ONLY ENOUGH FOR 1 MONTH, shot_39), location
  signs (KENTUCKY, USA → shot_10; TAIWAN AIRLINES shot_10), nameplates
  (SHOICHIRO IRIMAJIRI CEO shot_37), chest name tags (TSMC/NVIDIA RESEARCHER,
  shot_42), family photo label (JENSEN HUANG, shot_08). **[INTERPRETED high]**
- **Camera coverage in dialogue scenes**: the same diner set is cut as wide
  (shot_25), over-shoulder (shot_26), close-up pair (shot_27, shot_29), 3-shot
  (shot_28), plus brand establishing exterior (shot_24). **[INTERPRETED high]**
- **Split-panel time montages**: one house → house+studying → 4-panel
  day/night rhythm (shot_11→13). **[INTERPRETED high]**
- **Suspense beats**: empty door frame held as its own shot before an entrance
  (shot_34→35). **[INTERPRETED medium]**
- **Charts**: whiteboard style, green growth line vs red flat line, brand
  logos as anchors, handwritten labels (shot_04, shot_41). **[INTERPRETED high]**
- **Recurring props**: blue-floral white vase appears in two different scenes
  (shot_08, shot_38) — a running visual motif. **[INTERPRETED medium]**

## 5. Hook anatomy (0–14 s) [INTERPRETED high]

1. 0.0–5.1 s — vignette hold: sympathetic everyman laborer, no text (pattern:
   start inside a small human story, not the topic).
2. 5.1–8.7 s — diner table: the theme written on a napkin.
3. 8.7–13.9 s — black chapter card "34".
4. 13.9–17.4 s — whiteboard stakes: NVIDIA line going down, anxious room.
   Retention logic: human curiosity → concrete thesis → numbered structure
   promise → visualized conflict.

## 6. Audio [MEASURED]

- Integrated loudness −18.2 LUFS, LRA 3.8 LU (window −20.7…−17.0).
  Interpretation: consistent, voice-forward mix; music bed sits under the VO
  without dynamic spikes. **[INTERPRETED medium]** Music/SFX genre was not
  directly analyzed. **[NOT ANALYZED]**

## 7. Genre match

"Stickman finance/history ELI5 explainer" — kin to the Sam O'Nella / business
biography cartoon family, corporate-clean variant. **[INTERPRETED high]**

## 8. Not analyzed

- Final 269 s (outro, end card, subscribe behavior) — outside the sampled window.
- Actual music/SFX content — frames only.
- Caption pop-in animation timing (single frames can't show it).
