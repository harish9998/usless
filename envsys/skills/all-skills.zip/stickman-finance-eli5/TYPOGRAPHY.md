# TYPOGRAPHY — the decoded type system

Evidence: ASSETS/ frames. All observations [INTERPRETED high] unless noted.

## 1. Chapter cards (template C)

- Pure black background; **white handwritten marker font**; sentence case for
  phrases ("Two Years Building the Wrong Chip", shot_07); numerals can stand
  alone ("34", shot_03) and mid-video cards may be a single letter building a
  word ("E", shot_40).
- Centered, generous margins, no decoration, no drop shadow.

## 2. Dialogue / caption overlay

- Same handwritten family, **white**, top-center, no box, no bubble, no or
  minimal outline; one spoken line at a time, ≤10 words visible.

## 3. Prop labels (the signature move)

- Yellow sticky-note / nameplate / sign rectangles carrying **black
  handwritten text**: "STUDY HARD", "SURVIVE LIFE" (shot_18), "PAYROLL",
  "ONLY ENOUGH FOR 1 MONTH" (shot_39), "JENSEN HUANG" (shot_08),
  "SHOICHIRO IRIMAJIRI CEO" (shot_37), "TSMC RESEARCHER" / "NVIDIA
  RESEARCHER" (shot_42), "KENTUCKY, USA →" (shot_10), "1993" (shot_31).
- Chart labels handwritten, white or black depending on board color; brand
  names may use their real logo lettering (NVIDIA, SEGA, Denny's) rather than
  the handwritten font.

## 4. Font guidance

- Any casual handwritten marker font family works (e.g. Comic-style or
  felt-tip style); consistent across ALL text elements. Real brand logos are
  the only exception.
- No serif, no geometric sans, no condensed poster faces anywhere.

## 5. Motion

- Captions/labels appear with the line or prop; pop-in timing was not
  frame-verifiable [NOT ANALYZED]. Default: instant-on or ≤80 ms fade, no bounce.
