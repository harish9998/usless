# LAYOUT — composition & safe zones (1920x1080 canvas)

Derived from ASSETS/reference_frames. [INTERPRETED high] throughout.

## Global zones

- **Caption safe zone**: top-center band, y ≈ 60–170px, x centered — ALL
  dialogue overlay + scene captions live here (shot_16, shot_25, shot_28,
  shot_35, shot_37). Never place props behind this band.
- **Subject zone**: characters/props occupy center 60–80% width, anchored
  slightly below center; heads typically near y ≈ 35–55%.
- **Foreground label zone**: prop labels/sticky notes sit at the prop, never
  floating in empty sky.
- Chapter cards: text dead-center (shot_03, shot_07, shot_40).

## Per-template composition

| Template | Composition rule |
|---|---|
| A vignette | Character right-of-center or center; environment fills frame; no text |
| B object gag | Prop close-up fills 60–80% height; note/label ON the prop, readable |
| C chapter card | Full black; text centered; generous margins |
| D whiteboard | Board occupies 50–70% frame; presenter overlaps board edge, back 3/4 view |
| E dialogue | Wide = full set; coverage = 2 heads filling frame, 1/3 profile; checkered floor visible in wides |
| F split-panel | Vertical thirds/quads, hard black gutters between panels |
| G metaphor | Hero symbol center-low (chess), landmark behind (Capitol), mood sky above |
| H establishing | Building centered, sky band top 25%, ground band bottom 15% |
| I close-up | Head fills 40–70% of frame height; single emotion |
| J era stamp | Prop (calendar/sign) foreground-right or left, scene behind |
| K identity | Nameplate at desk edge / name tag on chest; face above it |
| L suspense | Door/empty frame centered; negative space does the work |
| M brand hero | Prop floats over dark map/space; centered, 40–55% width |

## Camera coverage pattern (dialogue scenes)

Standard rotation per exchange, 3–8 s each: WIDE (set) → OTS-A → CU-B →
CU-A → 3-SHOT → WIDE. Evidence: shot_24→29 sequence.

## Contrast discipline

- One dominant color mass per shot; accents ≤2 per frame.
- Night scenes: desaturated blue-gray + single warm light source
  (shot_12 desk lamp, shot_13 window sunset).
