# SCRIPT TEMPLATE — stickman finance ELI5 (11–15 min, ~1,700–2,200 words)

Narrative skeleton decoded from the reference's frame sequence
(ASSETS/shot_01–42). Fill each [BEAT], mark every line VO / DIALOGUE / TEXT,
and give every fact a visual job (template ID from SKILL.md).

## ACT 0 — HOOK (0:00–0:45)

- [BEAT] **Cold open vignette** (template A, ~5 s hold, no text): a small
  everyman in a workplace, mid-action, silently living the topic's human side.
- [BEAT] **Object gag thesis** (template B): close-up prop carrying a
  handwritten note that states the video's core tension in ≤8 words.
- [BEAT] **Chapter card** (template C): number or short chapter title.
- [BEAT] **Stakes board** (template D): whiteboard/presenter states why this
  matters NOW, with one red/green line or number.
- [BEAT] **Brand hero** (template M): the company/thing as a hero prop.

## ACT 1 — SETUP / ORIGIN (0:45–3:00)

- [BEAT] **Identity prop** (template K): protagonist/entity introduced with a
  nameplate or name tag.
- [BEAT] **Era stamp** (template J): year calendar or location sign.
- [BEAT] **Time montage** (template F): 3–4 vertical panels = time passing
  (work/study/hardship). VO narrates in past tense.
- [BEAT] **Early struggle vignettes**: 2–3 quick scenes (humility/hustle),
  each ending on a labeled prop gag.

## ACT 2 — EXPLAINER CORE (3:00–8:00)

- [BEAT] **Dialogue scene** (template E): the key decision/negotiation as a
  diner/office conversation with full camera coverage. 4–8 exchanges.
- [BEAT] **Whiteboard explain** (template D): the technical core in 2–3
  charts; green vs red lines; one chart per idea.
- [BEAT] **Metaphor scene** (template G): the abstract concept (market power,
  geopolitics, debt) as one symbolic tableau.
- [BEAT] **Rejection/turn** (template E + L): suspense beat on the empty
  door → the bad news line as caption ("The chip is a dead end." energy).

## ACT 3 — PAYOFF / TWIST (8:00–12:00)

- [BEAT] **Survival stakes** (template B): money/pull-through prop gag
  (PAYROLL jar energy) — make the audience feel the near-death.
- [BEAT] **The break**: the lucky/inevitable turn, delivered in dialogue.
- [BEAT] **Escalation montage** (template F): success compounding, panels
  multiplying.
- [BEAT] **Dominance established** (template M + D): hero prop returns, chart
  line goes vertical.

## ACT 4 — OUTRO (12:00–END)

- [BEAT] **Legacy tableau**: protagonist/entity in the present day, quiet scene.
- [BEAT] **One-line lesson**: the thesis restated as the final handwritten note.
- [BEAT] Topic handoff: "But that's [entity] — the next chapter is [open loop
  or related topic]." *(End-card/subscribe behavior was NOT analyzed — design
  freely here.)*

## Dialogue style rules

- Lines are short (≤12 words), plain-spoken, one idea each.
- Humor from character reactions and prop labels, not from jokes in the VO.
- Every DIALOGUE line also appears as on-screen handwritten text (per rules).

## Fact discipline

Each fact must map to exactly one visual job: prop label / character beat /
chart / metaphor scene. A fact with no visual job is cut or re-scoped.
