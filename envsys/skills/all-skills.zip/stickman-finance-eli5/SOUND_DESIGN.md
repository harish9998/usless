# SOUND DESIGN — mix targets + interpretation

## MEASURED targets (ffmpeg ebur128, first 600 s of reference)

- Integrated loudness: **−18.2 LUFS** → master VO+music mix to −18 ±1 LUFS.
- Loudness range: **3.8 LU** (window −20.7…−17.0) → keep the mix *consistent*;
  no dramatic dynamic swings between scenes.

## Production rules [INTERPRETED medium]

1. **Voice-over is the loudest element** — narration sits on top; music ducked
   well under it (the tight LRA suggests a compressed, broadcast-style VO chain).
2. **Music bed**: light, continuous, mid-energy (lo-fi/cartoon cue family);
   under dialogue scenes and VOs alike; no risers or drops.
3. **SFX**: sparse and comedic — a soft emphasis on prop-gag reveals and
   chapter-card hits; no per-cut whooshes (that's the MrBeast family, not this one).
4. **Silence is allowed** — the 5 s cold-open vignette plausibly runs with
   minimal bed; use restraint at the hook [INTERPRETED low].

## Not analyzed

- Actual music genre/instrumentation, SFX inventory, ducking timing — audio
  content was not listened to; only loudness statistics were measured.
