# EDITING RULES — hard rules for every edit

Measured targets come from `TIMING_PRESETS.json` [MEASURED]. Rules marked (H)
are visual conventions [INTERPRETED high].

## Shot cadence

1. Median shot **4.5 s**; acceptable band 3.5–6.0 s; never hold a normal shot
   past **10 s** (p95 ceiling) except the opening vignette.
2. **Opening**: one character vignette held ≥5 s, first cut at 5–8 s. No text
   during the hold.
3. Dialogue scenes: cut to coverage (wide → over-shoulder → close-up → 3-shot)
   every **3–8 s** within the same location.
4. At least one cut every 10 s from minute 1 to the end. No static holds.
5. Suspense beat (empty doorway) may hold 4–6 s, once per act max.

## Chapter cards

6. Section breaks ONLY via black chapter cards (template C): pure black,
   white handwritten text, 1.5–3 s. Mid-video cards may be single letters/numerals.
7. Never transition two scenes with a crossfade/zoom/whip — **hard cuts
   only** (H; no non-hard transitions observed in 42 boundary frames).

## Captions & labels

8. Dialogue renders as white handwritten text, top-center, ≤10 words visible,
   timed to the spoken line. No speech bubbles, no boxes. (H)
9. Facts attach to props with handwritten labels on yellow sticky notes /
   nameplates / signs (template J/K). Labels on screen ≥1.5 s. (H)
10. Chart labels handwritten, ≤4 words per label. (H)

## Visuals

11. Flat fills, thick black outlines on every element, no gradients. (H)
12. Palette locked to `COLOR_PALETTE.json`; accents sparing (brand colors,
    chart lines, note paper).
13. Charts: whiteboard style, max 2–3 lines, green = growth, red = flat/decline,
    brand logos as visual anchors. (H)
14. Characters keep identical features across every appearance (identity via
    hair + clothing color, never via added detail). (H)
15. Metaphor scenes (template G) once per major concept, max — don't stack.

## Compliance check

An edit is on-style only if: median 3.5–6.0 s ✓, hard cuts only ✓, black
chapter cards ✓, captions handwritten top-center ✓, no gradients ✓, labels
on props ✓.
