# Format notes + idea bank

## What the winners do (Offline Hearts, Nov 2026; Kevis Unfiltered breakdown, YouTube cHdJ5nNnH8Q)
| Short | Views | Structure |
|---|---|---|
| When Granny Gives Lil Bro Money! | 11M | title 3 s → lil bro crying with cash "NO PLEASE!" "MY MONEY!" → mom takes it "GIVE ME!" "NO DINNER!" "BAD BOY!" → twist "I'LL KEEP IT SAFE!" → like-heart |
| When Mom See A Cockroach! | 3.7M | mom screams → `DAD:` `GRANNY:` `LIL SIS:` each react worse → `LIL BRO:` calmly traps it under a cup (cool) → like-heart |
| When Lil Bro Gets a F! | 1.7M | proud lil bro → report card insert "F" → whole family charges at him |
| When Lil Bro Breaks Dish! | 1.0M | `MOM:` `DAD:` `BIG BRO:` `NOOB:` each react → twist |
- 15–24 s, square 1:1 on that channel (we do 9:16 so it fills the phone), white caps title top-centre, red for the punch line,
  speaker tags, no voiceover, trending music, sunny Roblox mansion (Brookhaven-like), DOF close-ups, ends on a heart + cursor.
- Channel switched from "Did the baby…" titles (7M over 11 shorts) to "When…" titles (24M) — same animation.
- Kevis' math (an estimate): Roblox shorts ≈ $0.30–0.45 per 1,000 views; one a day, none need to go viral.

## Two tests for every idea
(a) Has almost every kid lived this?  (b) Can ONE frame show the joke before anyone moves?

## Idea bank (not made by Offline Hearts as of Nov 2026)
| # | Title | The one frame | Family-reacts beats → twist |
|---|---|---|---|
| 1 | WHEN THERE'S ONE SLICE OF PIZZA LEFT | one slice, family heads peeking over the counter | dad sneaks, granny's cane, sis licks it, bro eats it → mom had another pizza ✅ made |
| 2 | WHEN THE WIFI GOES OUT | router blinking red, everyone frozen mid-scroll | dad, mom, sis panic → granny was unplugging it for her blender |
| 3 | WHEN YOU HEAR MOM'S CAR IN THE DRIVEWAY | messy room + headlights in the window | kids clean at 10x speed → it was the neighbour |
| 4 | WHEN MOM SAYS "WE HAVE FOOD AT HOME" | drive-thru sign vs sad fridge | each kid reacts → dad secretly eats a burger in the car |
| 5 | WHEN MOM CALLS YOUR FULL NAME | everyone freezes, mom in the doorway | each sibling points at the other → it was the dog |
| 6 | WHEN LIL SIS TOUCHES YOUR CONTROLLER | game paused, sis's hand on it | bro's dramatic slow-mo "NOOO" → she beats his high score |
| 7 | WHEN THE LAST COOKIE BREAKS IN HALF | cookie split, two kids staring | measuring with a ruler → granny eats both |
| 8 | WHEN DAD SAYS "I CAN FIX IT" | dad with a wrench under the sink | water everywhere, family in floaties → plumber arrives, it was a sticker |
| 9 | WHEN THE ICE CREAM TRUCK DRIVES PAST | truck in the window, kids at the door | sprint, trip, dad joins → truck sells only broccoli |
| 10 | WHEN YOUR PHONE DIES AT 1% | boss fight, battery 1% | charger hunt across the family → granny's phone is a brick |
| 11 | WHEN GRANNY SAYS "YOU'VE GROWN SO MUCH" | granny cheek-pinch | each kid gets squeezed → dad hides |
| 12 | WHEN MOM CHECKS IF YOUR ROOM IS CLEAN | spotless room, closet bulging | closet opens → avalanche |
| 13 | WHEN IT SNOWS AND SCHOOL IS CANCELLED | kids at the window, snow | celebration → mom: "online class" |
| 14 | WHEN YOU LOSE A TOOTH | tooth on a pillow | tooth fairy pays each kid differently → granny's dentures under her pillow |
| 15 | WHEN DAD GRILLS FOR THE FIRST TIME | smoke cloud, dad in apron | burnt everything → pizza delivery |
| 16 | WHEN LIL BRO FINDS THE CANDY STASH | open cupboard, mountain of candy | sugar rush → it was mom's |
| 17 | WHEN THE DENTIST SAYS "THIS WON'T HURT" | giant drill | each kid's face → dentist is granny |
| 18 | WHEN DAD SAYS "FIVE MORE MINUTES" | park clock | minutes stretch to night → dad still on the swing |
| 19 | WHEN YOU GET A NEW PUPPY | puppy in a box | everyone fights to hold it → puppy picks granny |
| 20 | WHEN MOM SEES THE REMOTE IN THE FRIDGE | remote on the milk shelf | everyone blames each other → mom put it there |
