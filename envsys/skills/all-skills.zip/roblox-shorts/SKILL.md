---
name: roblox-shorts
description: Make Roblox-animation family shorts ("WHEN THERE'S ONE SLICE OF PIZZA LEFT", "When Granny Gives Lil Bro Money") as 30 s 9:16 videos, built 100% in code on this computer (three.js Roblox-style avatars in a sunny mansion, painted face decals, captions, synthesized music + cartoon foley, $0 per video). The Block Family cast, house and look are locked by 7 reference sheets made in Higgsfield. Use whenever the user asks for a Roblox video, Roblox short, Roblox animation, "AI Roblox shorts", a family-reacts / "When ..." short, or a video like the Offline Hearts / Kevis Unfiltered ones, even from just a topic.
---

# Roblox Shorts — the Block Family

A 30-second vertical short in the format of the winning Roblox-animation channels (Offline Hearts: "When Granny Gives Lil Bro
Money" 11M, "When Mom See A Cockroach" 3.7M, "When Lil Bro Gets a F" 1.7M), made with our OWN family of Roblox-style avatars.
Everything renders locally: HTML + three.js → headless Chrome → ffmpeg. No video model, no paid API per video.
Demos: `example/pizza.js` (kitchen, daytime) and `example/car.js` (bedroom at night — the better-looking one, copy its look).
Reference sheets: `style/` · engine: `template/`. Target look = the Offline Hearts 3 AM short (youtube.com/shorts/JbCxC0k_SEU).

## Why it works (learned from the winners — keep these rules)
1. **The title is burned in at the top from frame 1** — "WHEN …" in big white caps. Before anyone moves you already know the
   joke. (Kevis' first render failed exactly here: small caption at the bottom, late.)
2. **A moment almost every kid has lived** (granny, mom, dad, lil bro, lil sis) **that ONE frame can show**. "When granny gives
   lil bro money" (cash in hand) = 11M; "When mom gives you veggies" (a plate of broccoli isn't a joke you can see) = 27K.
3. **Family reacts** structure: a speaker tag before each beat (`DAD:` `GRANNY:` `LIL SIS:`), one reaction each, escalating,
   **twist on the last beat**, then a **like-heart + cursor click** end card (loops back to frame 1).
4. Max 6 words on screen per line, a cut every 1.5–3 s, close-ups for every reaction (the faces carry the joke).
5. No voiceover needed — the winners use text + music. Mouths flap when a line pops.
6. Titles: the caption itself + `#roblox #robloxanimation`. One a day beats one viral hit (YouTube's "repetitive content"
   rule is about identical videos — same look is fine, the idea/words/joke must change every time).

## Workflow
0. **Setup once**: `scripts/setup.sh` (Node 22+, Chrome, ffmpeg, a Python venv with numpy/scipy/soundfile at ~/.roblox-shorts).
1. **Idea** — research is done once a month: `yt-dlp --flat-playlist --print "%(view_count)s|%(title)s" https://www.youtube.com/@Offline_Hearts/shorts | sort -t'|' -k1 -nr | head -30`
   (and 1–2 similar channels). Ask: what do the top ones share → 20 new "WHEN …" ideas they haven't made (bank in
   `reference/format.md`). Keep only ideas that pass BOTH tests: (a) almost every kid has lived it, (b) one frame shows it.
2. **Script** — 20–30 s, 3–5 family members, ONE room, lines ≤ 6 words, twist at the end. Write it as a beat table:
   `time · speaker · line · action · face · sound`. Read it once — if the joke doesn't land in text, it won't on screen.
3. **Build** — `scripts/new_short.sh <name>` copies the template (both demo films included). Write the new film as
   `src/films/<id>.js` (start from `car.js`), register it in `src/shots.js` (FILMS map), and write `data/sound_<id>.json`.
   Re-use the cast/props/sets; add props in `src/props/props.js`, rooms in `src/sets/` (see Limits).
   Preview: `cd <proj> && python3 -m http.server 8191` → http://127.0.0.1:8191/?film=<id>&shot=B1 (space = play, [ ] = shots,
   `?lab=bedroom` = cast line-up in a set). Capture tools take the film via `QS="&film=<id>"`.
4. **Look at it** — `cd tools && QS="&film=<id>" node capture.mjs scenes ../review/s.jpg all 2 0.22` (2 frames per shot) and
   `QS="&film=<id>" node capture.mjs sheet ../review/x.jpg "1.0,6.2,9.5" 4 0.3`. Compare against the 3 AM short: deep saturated
   colour, glossy heads, close-ups with wide lenses, dutch angles, something in the foreground. Check every shot: faces visible (nothing between camera
   and face: box lids, counters, hair), props in frame, title + speaker readable, nothing cropped by the title band.
5. **Render** — `scripts/render.sh <proj> <film> [out.mp4]` (synth mix → loudnorm −14.5 LUFS / −2 dBTP → 900 frames, ~30 s).
6. **Check the MP4** — `ffmpeg -i out.mp4 -vf "fps=2,scale=216:-1,tile=10x6" sheet.jpg`, read every caption, confirm
   I ≈ −14 LUFS, peak < −1 dBFS. Copy to the Desktop.
7. **Publish sheet** — 3 titles that start with the caption, `#roblox #robloxanimation`, first frame = thumbnail.

## The engine (template/)
- `src/films/<id>.js` — a film. `add(id, start, note, (W, lt, t) => ({ cam, look, cap, blur, like, flash, key, mb }))`;
  `S.set = 'bedroom' | 'kitchen'` (or per shot `set`). `look` = { focus, aper, exposure, sat, contrast, warm, sharp } — the night
  look is `exposure 0.92, sat 1.32, contrast 0.35`. `key` = camera-side key light strength (faces must read). `mb` = sub-frames
  of motion blur (fast-forward, whips).
  `put(W, id, pose, t)` poses an avatar with blink + breathing. Helpers: `peekY(W,id,eyeY)` (eyes peeking over the counter),
  `talk(t, at)` (mouth flap), `hold(obj, hand, pos, rot)`, `cam(pos, look, fov)`, `LOOK(focusDist, aperture)`.
  `S.pre(W, t)` runs before every shot (prop continuity, e.g. the box granny dragged stays dragged).
- **Avatar pose** (`src/chars/avatar.js`): `{ x, z, y, ry, lean, tilt, twist, hop, squash, head:[rx,ry,rz], armL/armR:[rx (+ = forward/up), rz (+ = out), twist],
  stretchL/stretchR (cartoon arm stretch), legL/legR, face:{ expr, look:[x,y], blink, talk }, tint:[css, amount], visible }`.
  Avatars face +Z; their left is +X. `hand('R')` = attach point. `height`, `dims` give sizes in studs.
- **Faces** (`src/chars/face.js`, Roblox-animator eyes like the 3 AM short: oval whites, coloured iris + pupil + shine, dark
  upper-lid line; expressions as in `style/04-faces.png`): neutral talk happy grin smug sideeye shocked scared crying angry
  disgusted lick sick love cool closed yawn whistle chew pout sneaky. Per character `iris`, `brow`; girls get lashes + blush,
  mom red lips, dad the beard. Heads are round Roblox cylinders (`headN` 2.35); skin is glossy plastic, clothes are `fabric()`.
- **Cast** (`src/chars/cast.js`): `lilbro` (yellow, orange backwards cap, mint star tee, has `shades`), `lilsis` (pigtails,
  pink heart hoodie), `mom` (bun, coral daisy cardigan), `dad` (yellow, beard, square glasses, green polo, socks + sandals),
  `granny` (white curls, gold glasses, purple floral cardigan, `cane`). BIG BRO is on the model sheet but not built yet.
- **Sets**: `kitchen.js` (day: island at the origin, counter top y = 3.2, window wall z = −14, oven `W.setOven(open, glow)`) and
  `bedroom.js` (night, `W.bedroom`: window wall z = −11 with a car whose headlights sweep in `setHeadlights(u, on)`, closet doors
  `setCloset(open)`, bedroom door `setDoor(open, hall)` + `doorHandle`, ceiling light `setRoomLight(on)`, bunk bed, gaming desk +
  red chair, and `junk` — 46 items with `mess` / `closet` / `heap` poses, `poseJunk(fn)` for any in-between).
- **Props** (`src/props/props.js`): `W.box` (open pizza box, lid folded flat), `W.slice` (`userData.shine` = lick shine),
  `W.pizza` (whole pizza), `W.sparkles` (`userData.update(t, on, spread)`).
- **Captions** (`src/overlay.js`, Montserrat 800 white + soft shadow like the winners): `cap: { title, speaker, line, red, at,
  word: { text, at, x, y, rot, dur }, timer: secs, timerAt, ff: 'x10' }` — title at the top every frame, speaker + line pop under
  it (below however many title lines), `word` = comic burst, `timer` = red digital countdown, `ff` = fast-forward badge.
  `like: lt` draws the end card, `blur: 22` blurs the frame under it.
- **Sound** (`data/sound_<film>.json` → `tools/mix.py <proj> <film>`): sections `sneaky` (pizzicato + bassoon + marimba,
  minor), `frantic` (fast pizzicato galop), `tense` (low drone, `root`), `cool` (e-piano, sub, soft kick/snare), `happy` (major
  marimba, `root`), `choir` (heavenly "aah", `notes`), plus `ducks`. Cue names: dun dundundun twinkle slide_up slide_down whistle
  slap boing creak scrape whoosh slurp blip_down scratch boom chomp gulp ding horn confetti trombone clatter pop engine car_door
  heartbeat crash switch steps tape. Every sound gets a 25 ms tail fade (no clicks — the user hates ticks). No hats, no glitch noise.

## Reference sheets (style/) — the look is locked by these
`01-style-sheet` (cast, palette, light, captions, rules) · `02/03-model-sheet` (kids / grown-ups, 4 views + parts) ·
`04-faces` · `05-the-house` (6 rooms) · `06-props` · `07-format-rules` (the 30-second storyboard + rules).
Made in Higgsfield with GPT Image 2.5 (high, 2k, ~2.75 credits each), using real Offline Hearts frames as image references
(the first try without them looked like generic toys, not Roblox — the user rejected it). Need a new room/prop/character
sheet? Generate ONE image with `01-style-sheet` + the closest sheet as references, then build it in code. Never generate video.

## Limits / next builds
- Built: **kitchen** (day) and **lil bro's bedroom** (night). For another room, copy the closest set, follow
  `style/05-the-house.png`, keep furniture heights in studs (adult ≈ 5 studs tall), and light it like the bedroom: low ambient,
  one coloured main light (moon/sun), warm practicals, a camera-side key.
- Our characters are our own designs in the Roblox avatar style. Keep the Roblox logo, Robux "R$" icon and real
  avatar-shop items out of frame; whether to tag #roblox is the user's call.
- `NOTES.md` = lessons + user feedback; read it before every new short and add to it after.
