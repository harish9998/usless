// "WHEN YOU HEAR MOM'S CAR IN THE DRIVEWAY" — 30 s, 9:16, lil bro's room at night (look of the 3 AM short JbCxC0k_SEU).
// hook: trashed room, headlights sweep across two frozen kids → MOM'S HOME!! → 30-second countdown → x10 speed-clean,
// everything flies into the closet → door handle turns → mom flips the light on: "WHY IS IT SO CLEAN?" → kids lean on the
// closet grinning → she walks to it → TWIST: avalanche buries her → "YOU'RE GROUNDED." → like-heart.
import * as THREE from 'three';
import { E, seg, clamp, lerp, hash } from '../core/util.js';
import { blinkAt, walk, plastic, rbox } from '../chars/avatar.js';

const TITLE = "WHEN YOU HEAR MOM'S CAR IN THE DRIVEWAY";
const SEED = { lilbro: 1, lilsis: 2, granny: 3, mom: 4, dad: 5 };
function put(W, id, p, t) {
  const a = W.cast[id];
  a.pose({ ...p, face: { blink: blinkAt(t, SEED[id]), ...(p.face || {}) }, hop: (p.hop ?? 0) + Math.sin(t * 2.2 + SEED[id]) * 0.02 });
  if (a.shades) { a.shades.visible = !!p.shades; a.shades.position.y = a.dims.hh / 2 + 0.07; a.shades.rotation.x = 0; }
  return a;
}
const talk = (t, at, dur = 0.7) => (t >= at && t < at + dur ? Math.abs(Math.sin((t - at) * 17)) : 0);
const cam = (pos, look, fov = 50, extra = {}) => ({ pos, look, fov, ...extra });
const LOOK = (focus, aper = 0.05, extra = {}) => ({ focus, aper, exposure: 0.92, sat: 1.32, contrast: 0.35, warm: 0.0, ...extra });
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

// ---- timeline anchors ----
const T_TIMER = 5.0, T_CLEAN0 = 6.3, T_CLEAN1 = 14.45, T_SLAM = 14.55, T_CLOSET_OPEN = 23.55;
const timerAt = (t) => (t < T_CLEAN0 ? 30 : Math.max(0, 30 * (1 - (t - T_CLEAN0) / (T_SLAM + 0.15 - T_CLEAN0))));

// ---- junk choreography ----
const flightStart = (it) => T_CLEAN0 + 0.25 + it.order * (T_CLEAN1 - T_CLEAN0 - 0.8);
function arc(a, b, u, lift) { return [lerp(a[0], b[0], u), lerp(a[1], b[1], u) + Math.sin(u * Math.PI) * lift, lerp(a[2], b[2], u)]; }
function junkAt(it, i, t) {
  // cleaning: mess → closet
  if (t < T_CLOSET_OPEN) {
    const ts = flightStart(it), u = clamp((t - ts) / 0.42);
    if (u <= 0) return it.mess;
    if (u >= 1) return it.closet;
    return { p: arc(it.mess.p, it.closet.p, E.io(u), 2.5 + hash(i) * 2), r: it.mess.r.map((v, k) => v + u * (6 + k * 3)) };
  }
  // avalanche: closet → heap (with one bounce)
  const ts = T_CLOSET_OPEN + 0.08 + it.order * 0.55, u = clamp((t - ts) / 0.5);
  if (u <= 0) return it.closet;
  const land = it.heap.p;
  if (u < 1) return { p: arc(it.closet.p, land, u, 1.6 + hash(i + 3) * 1.4), r: it.closet.r.map((v, k) => v + u * (5 + k * 2)) };
  const b = clamp((t - ts - 0.5) / 0.3); // small bounce
  return { p: [land[0], land[1] + Math.sin(b * Math.PI) * 0.25 * (1 - b), land[2]], r: it.heap.r };
}

/** a dash path for the speed-clean (deterministic zig-zag through the room) */
function dash(t, seed, area) {
  const k = Math.floor(t * 2.2), f = t * 2.2 - k;
  const P = (n) => [lerp(area[0], area[1], hash(seed * 31 + n)), lerp(area[2], area[3], hash(seed * 17 + n + 5))];
  const a = P(k), b = P(k + 1), u = E.io(f);
  return { x: lerp(a[0], b[0], u), z: lerp(a[1], b[1], u), ry: Math.atan2(b[0] - a[0], b[1] - a[1]) * 180 / Math.PI };
}
function windmill(t, s = 1) { return { armL: [90 + Math.sin(t * 34) * 70, 20, 0], armR: [90 + Math.sin(t * 34 + 2) * 70 * s, 20, 0], legL: Math.sin(t * 30) * 40, legR: -Math.sin(t * 30) * 40, hop: Math.abs(Math.sin(t * 30)) * 0.25 }; }

let controller = null;
function getController(W) {
  if (controller) return controller;
  const g = new THREE.Group(); const m = plastic(0x2f63e0), d = plastic(0x15161a);
  const body = new THREE.Mesh(rbox(1.0, 0.22, 0.55, 0.1), m); g.add(body);
  for (const s of [-1, 1]) { const grip = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 10), d); grip.position.set(s * 0.42, -0.04, 0.2); g.add(grip); }
  g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  controller = g; return g;
}

export function buildCar(W) {
  const S = []; S.set = 'bedroom';
  const add = (id, start, note, setup) => S.push({ id, start, note, set: 'bedroom', setup });
  const B = W.bedroom;
  const BRO = [0.4, 0.6], SIS = [2.9, 1.6];
  const sweep = (t) => clamp((t + 2.0) / 4.6); // headlight progress: the glare is already in the window at frame 1

  // ---------------- HOOK ----------------
  add('A1', 0.0, 'hook: headlights sweep across the frozen kids', (W, lt, t) => {
    B.setHeadlights(sweep(t), 0.7);
    const bro = put(W, 'lilbro', { x: BRO[0], z: BRO[1], ry: 20, armR: [55, 8, 0], armL: [55, -8, 0], face: { expr: 'shocked', look: [0.3, 0.1] }, head: [0, -25, 0] }, t);
    const c = getController(W); c.visible = true; bro.hand('R').add(c); c.position.set(-0.45, 0, 0.25); c.rotation.set(Math.PI / 2, 0, 0);
    put(W, 'lilsis', { x: SIS[0], z: SIS[1], ry: -10, hop: 0.0, armL: [150, 25, 0], armR: [150, 25, 0], face: { expr: 'scared', look: [-0.2, 0.2] }, head: [0, 20, 0] }, t);
    const z = lerp(9.0, 8.1, E.io(clamp(lt / 2.4)));
    return { cam: cam([1.9, 6.4, z], [1.7, 3.7, -4.0], 60), look: LOOK(dist([1.9, 6.4, z], [1.6, 3.4, 1.0]), 0.03, { exposure: 0.86 }), key: 1.15, cap: { title: TITLE } };
  });
  add('A2', 2.4, 'LIL BRO: MOM\'S HOME!!', (W, lt, t) => {
    B.setHeadlights(sweep(t), 0.3);
    const drop = seg(lt, 0.35, 0.75, E.in);
    const bro = put(W, 'lilbro', { x: BRO[0], z: BRO[1], ry: 180, armR: [lerp(55, 20, drop), 8, 0], armL: [lerp(55, 20, drop), -8, 0], face: { expr: 'shocked', talk: talk(t, 2.5, 0.8) }, head: [-6, 0, 0] }, t);
    const c = getController(W); c.visible = true;
    if (drop < 1) { bro.hand('R').add(c); c.position.set(-0.45, 0, 0.25); c.rotation.set(Math.PI / 2, 0, 0); }
    else { B.scene.add(c); c.position.set(BRO[0] - 0.3, 0.15, BRO[1] - 0.8); c.rotation.set(0, 0.6, 0); }
    const h = bro.height;
    return { cam: cam([BRO[0] - 0.4, h - 0.1, BRO[1] - 3.2 + lt * 0.3], [BRO[0], h - 0.7, BRO[1]], 62, { roll: -6 }), look: LOOK(3.0, 0.1), key: 0.7, cap: { title: TITLE, speaker: 'LIL BRO:', line: "MOM'S HOME!!", red: true, at: 2.48 } };
  });
  add('A3', 3.7, 'LIL SIS: WE\'RE SO DEAD', (W, lt, t) => {
    B.setHeadlights(sweep(t), 0.3);
    const sis = put(W, 'lilsis', { x: SIS[0], z: SIS[1], ry: 190, armL: [150, 25, 0], armR: [150, 25, 0], face: { expr: 'crying', talk: talk(t, 3.78, 0.8) }, head: [0, 0, Math.sin(lt * 20) * 3] }, t);
    put(W, 'lilbro', { x: BRO[0], z: BRO[1], ry: 180, face: { expr: 'shocked' } }, t);
    const h = sis.height;
    return { cam: cam([SIS[0] + 0.6, h - 0.3, SIS[1] - 2.9], [SIS[0], h - 0.6, SIS[1]], 62, { roll: 5 }), look: LOOK(2.9, 0.1), key: 0.7, cap: { title: TITLE, speaker: 'LIL SIS:', line: "WE'RE SO DEAD.", at: 3.78 } };
  });
  add('A4', 4.8, 'the car stops — 30 seconds', (W, lt, t) => {
    B.setHeadlights(sweep(t), 1 - 0.85 * seg(lt, 0.7, 1.1));
    put(W, 'lilbro', { x: BRO[0], z: BRO[1], ry: 180, face: { expr: 'shocked' } }, t);
    put(W, 'lilsis', { x: SIS[0], z: SIS[1], ry: 190, armL: [150, 25, 0], armR: [150, 25, 0], face: { expr: 'scared' } }, t);
    const c = getController(W); c.visible = true; B.scene.add(c); c.position.set(BRO[0] - 0.3, 0.15, BRO[1] - 0.8); c.rotation.set(0, 0.6, 0);
    return { cam: cam([1.6, 4.4, 6.8 - lt * 0.6], [2.6, 5.2, -11], 52), look: LOOK(17, 0.03), key: 0.25, cap: { title: TITLE, timer: 30, timerAt: T_TIMER } };
  });

  // ---------------- SPEED CLEAN (x10) ----------------
  const cleanState = (W, t) => {
    B.setCloset(seg(t, T_CLEAN0, T_CLEAN0 + 0.25, E.out) * (1 - seg(t, T_CLEAN1, T_SLAM, E.in)));
    B.poseJunk((it, i) => junkAt(it, i, t));
    const c = getController(W); B.scene.add(c); c.visible = false;
    const b = dash(t, 3, [-8, 8, -7, 6]), s = dash(t + 0.37, 7, [-6, 9, -8, 5]);
    put(W, 'lilbro', { x: b.x, z: b.z, ry: b.ry, ...windmill(t), face: { expr: 'angry' } }, t);
    put(W, 'lilsis', { x: s.x, z: s.z, ry: s.ry, ...windmill(t + 0.3, -1), face: { expr: 'scared' } }, t);
  };
  const capFF = (t) => ({ title: TITLE, timer: timerAt(t), timerAt: T_TIMER, ff: 'x10' });
  add('B1', 6.2, 'x10: everything flies into the closet', (W, lt, t) => {
    cleanState(W, t);
    return { cam: cam([-6.5, 9.5, 9.5], [4, 2.5, -4], 64), look: LOOK(16, 0.02), key: 1.0, mb: 4, shutter: 1.2, cap: capFF(t) };
  });
  add('B2', 8.0, 'x10: sis stuffs the closet', (W, lt, t) => {
    cleanState(W, t);
    put(W, 'lilsis', { x: 10.6, z: -5.0 + Math.sin(t * 9) * 0.8, ry: 90, armL: [100 + Math.sin(t * 40) * 50, 10, 0], armR: [100 + Math.sin(t * 40 + 2) * 50, 10, 0], face: { expr: 'angry' } }, t);
    return { cam: cam([12.4, 4.4, -1.6], [10.6, 3.6, -5.2], 64, { roll: -8 }), look: LOOK(3.9, 0.05), key: 1.2, mb: 4, shutter: 1.2, cap: capFF(t) };
  });
  add('B3', 9.6, 'x10: lil bro zooms across the floor', (W, lt, t) => {
    cleanState(W, t);
    const x = Math.sin(lt * 4.2) * 3.2;
    put(W, 'lilbro', { x, z: 2.0, ry: Math.cos(lt * 4.2) > 0 ? 90 : -90, lean: 25, ...windmill(t), face: { expr: 'angry' } }, t);
    return { cam: cam([0, 1.6, 8.6], [0, 2.6, 2.0], 66), look: LOOK(6.6, 0.04), key: 1.1, mb: 5, shutter: 1.4, cap: capFF(t) };
  });
  add('B4', 11.2, 'x10: top-down, the floor clears', (W, lt, t) => {
    cleanState(W, t);
    return { cam: cam([0.5, 22, 1.0], [0.5, 0, -0.5], 72), look: LOOK(21, 0.0), key: 1.0, mb: 4, shutter: 1.2, cap: capFF(t) };
  });
  add('B5', 13.0, 'SLAM — lean on the closet, 00:00', (W, lt, t) => {
    cleanState(W, t);
    const run = seg(t, 13.0, T_CLEAN1, E.out), lean = t > T_SLAM;
    put(W, 'lilbro', { x: lerp(4, 11.75, run), z: -6.4, ry: lean ? -90 : 90, lean: lean ? -6 : 18, armL: lean ? [10, 40, 0] : [120, 10, 0], armR: lean ? [10, 40, 0] : [120, 10, 0], face: { expr: lean ? 'scared' : 'angry' } }, t);
    put(W, 'lilsis', { x: lerp(3, 11.75, run), z: -3.6, ry: lean ? -90 : 90, lean: lean ? -6 : 18, armL: lean ? [10, 40, 0] : [120, 10, 0], armR: lean ? [10, 40, 0] : [120, 10, 0], face: { expr: lean ? 'scared' : 'angry' } }, t);
    const kick = t > T_SLAM ? Math.exp(-(t - T_SLAM) * 7) : 0;
    return { cam: cam([4.0, 5.2, -4.9], [12, 3.8, -4.9], 58, { shake: 0.1 + kick * 3 }), look: LOOK(8, 0.03), key: 1.2, cap: { title: TITLE, timer: timerAt(t), timerAt: T_TIMER, ff: t < T_SLAM ? 'x10' : null, word: { text: 'SLAM!', at: T_SLAM, x: 0.5, y: 0.6, rot: -6, dur: 0.5 } } };
  });

  // ---------------- MOM ----------------
  const cleanRoom = (W) => { B.poseJunk((it) => it.closet); B.setCloset(0); const c = getController(W); B.scene.add(c); c.visible = false; };
  const leaners = (W, t, faceB, faceS, grin = 0) => {
    put(W, 'lilbro', { x: 11.75, z: -6.4, ry: -90, lean: -6, armL: [10, 40, 0], armR: [10, 40, 0], face: faceB }, t);
    put(W, 'lilsis', { x: 11.75, z: -3.6, ry: -90, lean: -6, armL: [10, 40, 0], armR: [10, 40, 0], face: faceS }, t);
  };
  add('C1', 15.0, 'the door handle turns', (W, lt, t) => {
    cleanRoom(W); B.setDoor(0.03 * seg(lt, 0.9, 1.4), 0.25);
    leaners(W, t, { expr: 'scared' }, { expr: 'scared' });
    const tw = seg(lt, 0.3, 0.9, E.io);
    B.doorHandle.rotation.x = tw * 0.8;
    return { cam: cam([10.2, 4.6, 4.2], [13, 4.4, 4.0], 46), look: LOOK(3.0, 0.1), key: 0.5, cap: { title: TITLE } };
  });
  add('C2', 16.4, 'MOM: light on — why is it so clean?', (W, lt, t) => {
    cleanRoom(W);
    const open = seg(lt, 0.0, 0.5, E.out), light = lt > 1.05 ? 1 : 0;
    B.setDoor(open * 0.95, 1); B.setRoomLight(light);
    const walkIn = seg(lt, 0.3, 1.0, E.io);
    const m = put(W, 'mom', { x: lerp(14.6, 11.6, walkIn), z: 5.0, ry: -90 + 20 * seg(lt, 1.2, 1.8), armR: lt > 0.8 && lt < 1.2 ? [70, 70, 0] : [8, 6, 0], armL: [8, 6, 0], face: { expr: lt < 1.4 ? 'neutral' : 'sideeye', look: [0.8, 0], talk: talk(t, 18.0, 0.9) } }, t);
    leaners(W, t, { expr: 'grin', look: [0.6, 0] }, { expr: 'grin', look: [0.6, 0] });
    return { cam: cam([5.6, 4.9, 1.6], [11.6, 4.2, 4.8], 54), look: LOOK(7.0, 0.035), key: light ? 0.6 : 0.5, flash: lt > 1.05 && lt < 1.15 ? 0.35 : 0, cap: { title: TITLE, speaker: 'MOM:', line: lt > 1.5 ? 'WHY IS IT SO CLEAN?' : '', at: 17.95 } };
  });
  add('C3', 19.4, 'kids: WE LOVE CLEANING!', (W, lt, t) => {
    cleanRoom(W); B.setDoor(0.95, 1); B.setRoomLight(1);
    leaners(W, t, { expr: 'grin', talk: talk(t, 19.5, 0.8) }, { expr: 'grin' });
    return { cam: cam([2.6, 5.0, -4.4], [11.75, 3.7, -5.0], 50), look: LOOK(6.6, 0.04), key: 0.6, cap: { title: TITLE, speaker: 'LIL BRO:', line: 'WE LOVE CLEANING!', at: 19.48 } };
  });
  add('C4', 21.0, 'over mom\'s shoulder: she walks to the closet — no no no', (W, lt, t) => {
    cleanRoom(W); B.setDoor(0.95, 1); B.setRoomLight(1);
    const u = clamp(lt / 2.4), w = walk(lt * 5, 22 * (1 - seg(lt, 1.9, 2.4)));
    const mx = lerp(10.6, 9.0, E.io(u)), mz = lerp(3.4, -4.9, E.io(u));
    put(W, 'mom', { x: mx, z: mz, ry: lerp(-170, 90, seg(lt, 1.7, 2.4, E.io)), ...w, face: { expr: 'sideeye' } }, t);
    const step = seg(lt, 1.5, 2.1, E.io);
    put(W, 'lilbro', { x: lerp(11.75, 9.8, step), z: lerp(-6.4, -8.9, step), ry: lerp(-90, -10, step), lean: -6 * (1 - step), armL: [lerp(10, 60, step), 40, 0], armR: [lerp(10, 60, step), 40, 0], face: { expr: 'scared', look: [0, 0.2] } }, t);
    put(W, 'lilsis', { x: lerp(11.75, 10.2, step), z: lerp(-3.6, -1.2, step), ry: lerp(-90, -170, step), lean: -6 * (1 - step), armL: [lerp(10, 150, step), 30, 0], armR: [lerp(10, 150, step), 30, 0], face: { expr: 'scared', talk: talk(t, 21.1, 1.4), look: [0, 0.2] } }, t);
    const cp = [mx - 2.4, 6.2, mz + 4.2];
    return { cam: cam(cp, [11.4, 3.9, -5.0], 54), look: LOOK(dist(cp, [11.6, 4, -5]), 0.035), key: 0.6, cap: { title: TITLE, speaker: 'LIL SIS:', line: 'NO NO NO...', red: true, at: 21.08 } };
  });

  // ---------------- TWIST ----------------
  add('D1', 23.4, 'TWIST: the avalanche', (W, lt, t) => {
    B.setDoor(0.95, 1); B.setRoomLight(1);
    B.setCloset(seg(t, T_CLOSET_OPEN - 0.08, T_CLOSET_OPEN + 0.12, E.out));
    B.poseJunk((it, i) => junkAt(it, i, t));
    const c = getController(W); B.scene.add(c); c.visible = false;
    const bury = seg(lt, 0.45, 1.0);
    put(W, 'mom', { x: 9.0, z: -4.9, ry: 90, lean: -18 * seg(lt, 0.15, 0.4), armL: [lerp(60, 160, seg(lt, 0.15, 0.4)), 30, 0], armR: [lerp(60, 160, seg(lt, 0.15, 0.4)), 30, 0], face: { expr: lt < 0.15 ? 'neutral' : 'shocked' }, y: -bury * 3.2 }, t);
    put(W, 'lilbro', { x: 9.4 - lt * 1.5, z: -8.8, ry: -30, armL: [160, 20, 0], armR: [160, 20, 0], face: { expr: 'shocked' } }, t);
    put(W, 'lilsis', { x: 9.6 - lt * 1.5, z: -1.0, ry: -150, armL: [160, 20, 0], armR: [160, 20, 0], face: { expr: 'shocked' } }, t);
    const kick = t > T_CLOSET_OPEN ? Math.exp(-(t - T_CLOSET_OPEN) * 3) : 0;
    return { cam: cam([2.2, 6.4, 3.5], [10, 3.0, -5.0], 60, { shake: 0.15 + kick * 3.5 }), look: LOOK(11, 0.025), key: 0.6, cap: { title: TITLE, word: { text: 'CRASH!', at: T_CLOSET_OPEN + 0.12, x: 0.55, y: 0.56, rot: -8, dur: 0.9 } } };
  });
  add('D2', 26.4, 'MOM: YOU\'RE GROUNDED.', (W, lt, t) => {
    B.setDoor(0.95, 1); B.setRoomLight(1); B.setCloset(1);
    B.poseJunk((it) => it.heap);
    const c = getController(W); B.scene.add(c); c.visible = false;
    const pop = seg(lt, 0.15, 0.45, E.back);
    const m = put(W, 'mom', { x: 9.0, z: -4.9, ry: -70, y: lerp(-3.2, -0.85, pop), armR: [150, 10, 0], armL: [20, 10, 0], face: { expr: 'angry', talk: talk(t, 26.95, 0.9) }, head: [0, 0, -8] }, t);
    // a sock on her head
    const sock = W.bedroom.junk.find((it) => it.kind === 'sock');
    if (sock) { m.headPivot.add(sock.mesh); sock.mesh.position.set(0.1, m.dims.hh + 0.12, 0); sock.mesh.rotation.set(0, 0.4, 0.15); }
    const h = m.height - 0.85;
    return { cam: cam([6.0, h + 1.6, -3.4], [9.0, h - 0.5, -4.9], 50), look: LOOK(3.9, 0.06), key: 0.7, cap: { title: TITLE, speaker: 'MOM:', line: "YOU'RE GROUNDED.", red: true, at: 26.9 } };
  });
  add('E1', 28.2, 'like-heart ending', (W, lt, t) => {
    const r = S.find((s) => s.id === 'D2').setup(W, 1.75, 28.15);
    return { ...r, blur: 22, like: lt, cap: { title: TITLE } };
  });
  S.pre = (W, t) => { const sock = W.bedroom.junk.find((it) => it.kind === 'sock'); if (sock && sock.mesh.parent !== W.bedroom.scene) W.bedroom.scene.add(sock.mesh); };
  S.cues = [];
  S[S.length - 1].end = 30.0;
  return S;
}
