// "WHEN THERE'S ONE SLICE OF PIZZA LEFT" — 30 s, 9:16. The family-reacts format of the winning Roblox shorts:
// hook (frame 1 tells the joke) → DAD → GRANNY → LIL SIS licks it → everyone: ew → LIL BRO eats it anyway → TWIST: mom has
// another pizza → lil bro regrets → like-heart. Each shot: setup(W, lt, t) → { cam, look, cap, blur, like, flash }.
import * as THREE from 'three';
import { E, seg, kf, clamp, lerp } from '../core/util.js';
import { blinkAt, walk } from '../chars/avatar.js';

const TITLE = "WHEN THERE'S ONE SLICE OF PIZZA LEFT";
const SEED = { lilbro: 1, lilsis: 2, granny: 3, mom: 4, dad: 5 };
const BACK_Z = -3.35;

/** pose an avatar with idle life (blink + breathing) */
function put(W, id, p, t) {
  const a = W.cast[id];
  const f = { blink: blinkAt(t, SEED[id]), ...(p.face || {}) };
  a.pose({ ...p, face: f, hop: (p.hop ?? 0) + Math.sin(t * 2.2 + SEED[id]) * 0.02 });
  if (a.shades) { a.shades.visible = !!p.shades; a.shades.position.y = a.dims.hh / 2 + 0.07; a.shades.rotation.x = 0; }
  return a;
}
/** y offset so the avatar's eyes sit at height `eye` (peeking over the counter) */
function peekY(W, id, eye = 3.7) { const d = W.cast[id].dims; return eye - (d.lh + d.th + d.hh * 0.555); }
/** mouth flap for a line that pops at `at` (no voice: the mouth moves while the text lands) */
const talk = (t, at, dur = 0.7) => (t >= at && t < at + dur ? Math.abs(Math.sin((t - at) * 17)) : 0);
function hold(obj, parent, pos, rot) { parent.add(obj); obj.position.set(...pos); obj.rotation.set(...rot); }
const cam = (pos, look, fov = 50, extra = {}) => ({ pos, look, fov, ...extra });
const LOOK = (focus, aper = 0.05, extra = {}) => ({ focus, aper, ...extra });
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

/** the family peeking over the island (hook + background of the dad beat) */
function peekers(W, t, ids, faces = {}, rise = 1) {
  const X = { dad: -2.1, granny: -0.7, lilsis: 0.7, mom: 2.15 };
  for (const id of ids) put(W, id, { x: X[id], z: BACK_Z, y: peekY(W, id) - (1 - rise) * 0.7, face: { expr: 'love', look: [0, -0.7], ...(faces[id] || {}) } }, t);
}

export function buildPizza(W) {
  const S = [];
  const add = (id, start, note, setup) => S.push({ id, start, note, setup });

  // ---------------- HOOK ----------------
  add('A1', 0.0, 'hook: family stares at the last slice', (W, lt, t) => {
    peekers(W, t, ['dad', 'granny', 'lilsis', 'mom'], { mom: { expr: 'sideeye', look: [-0.9, -0.3] }, dad: { expr: 'love', look: [0.3, -0.7] } }, 0.75 + 0.25 * seg(lt, 0, 0.6, E.out));
    W.sparkles.visible = true; W.sparkles.position.copy(W.slice.position); W.sparkles.userData.update(t, 1, 0.9);
    const z = lerp(6.6, 5.6, E.io(clamp(lt / 2.3)));
    return { cam: cam([0, 7.3 - (6.6 - z) * 0.5, z], [0, 3.55, -1.4], 58), look: LOOK(dist([0, 7, z], [0, 3.6, -1.5]), 0.03), cap: { title: TITLE } };
  });
  add('A2', 2.3, 'insert: the glorious last slice', (W, lt, t) => {
    peekers(W, t, ['dad', 'granny', 'lilsis', 'mom']);
    W.sparkles.visible = true; W.sparkles.position.copy(W.slice.position); W.sparkles.userData.update(t, 1, 0.9);
    const a = -0.5 + lt * 0.35;
    const p = [0.15 + Math.sin(a) * 2.6, 4.35, 0.45 + Math.cos(a) * 2.6];
    return { cam: cam(p, [0.15, 3.3, 0.45], 38), look: LOOK(dist(p, [0.15, 3.3, 0.45]), 0.12), cap: { title: TITLE } };
  });

  // ---------------- DAD ----------------
  const DAD_X = -2.55;
  const dadArm = (lt) => { // yawn up → drop onto the counter → stretch toward the slice
    const up = seg(lt, 0.15, 0.7, E.out) - seg(lt, 1.1, 1.5, E.io);
    const reach = seg(lt, 1.3, 1.7, E.io);
    return { up, reach };
  };
  add('B1', 3.3, 'DAD: fake yawn, sneaky arm', (W, lt, t) => {
    const { up, reach } = dadArm(lt);
    const yawn = lt > 0.2 && lt < 1.2;
    put(W, 'dad', { x: DAD_X, z: BACK_Z, armR: [lerp(0, 165, up), lerp(4, 10, up), 0], armL: [lerp(lerp(0, 165, up), 84, reach), lerp(4, -14, reach), 0], stretchL: 1 + 0.4 * seg(lt, 1.6, 2.2, E.io), face: { expr: yawn ? 'yawn' : 'whistle' }, head: [lerp(0, -8, up), lerp(0, -18, reach), 0] }, t);
    peekers(W, t, ['granny', 'lilsis'], { granny: { expr: 'sideeye', look: [-0.9, 0] }, lilsis: { expr: 'sideeye', look: [-0.9, 0.1] } });
    put(W, 'mom', { x: 2.6, z: BACK_Z, armL: [72, -38, 0], armR: [76, -40, 0], face: { expr: 'sideeye', look: [-0.9, -0.1] } }, t);
    return { cam: cam([-1.4, 5.5, 5.6], [-1.9, 4.3, -3.2], 52), look: LOOK(8.8, 0.04), cap: { title: TITLE, speaker: 'DAD:', line: "I'M NOT EVEN HUNGRY...", at: 3.45 } };
  });
  add('B2', 5.5, 'insert: the arm creeps, mom SLAPS', (W, lt, t) => {
    const slap = 0.72;
    const creep = seg(lt, 0, slap, E.lin), back = seg(lt, slap, slap + 0.25, E.out);
    put(W, 'dad', { x: DAD_X, z: BACK_Z, armL: [lerp(86, 140, back), lerp(-16, 10, back), 0], armR: [0, 4, 0], stretchL: lerp(1.4 + 0.65 * creep, 1, back), face: { expr: lt < slap ? 'whistle' : 'crying' }, head: [-5, -18, 0] }, t);
    const swing = seg(lt, 0.35, slap, E.in);
    put(W, 'mom', { x: 2.6, z: BACK_Z, armR: [lerp(150, 86, swing), lerp(10, 24, swing), 0], armL: [72, -38, 0], stretchR: 1 + 1.05 * swing * (1 - back), face: { expr: 'angry' } }, t);
    peekers(W, t, ['granny', 'lilsis'], { granny: { expr: 'shocked' }, lilsis: { expr: 'shocked' } });
    const kick = lt > slap ? Math.exp(-(lt - slap) * 9) : 0;
    return { cam: cam([0.6, 6.4 + kick * 0.1, 4.6], [0.3, 3.4, -0.6], 50, { shake: 0.1 + kick * 2.5 }), look: LOOK(6.0, 0.05), cap: { title: TITLE, word: { text: 'SLAP!', at: 5.5 + slap, x: 0.42, y: 0.62, rot: -10, dur: 0.6 } } };
  });
  add('B3', 6.6, 'MOM: nice try', (W, lt, t) => {
    put(W, 'mom', { x: 2.6, z: BACK_Z, armL: [72, -38, 0], armR: [76, -40, 0], face: { expr: 'smug', talk: talk(t, 6.7) }, head: [0, -12, 4] }, t);
    put(W, 'dad', { x: DAD_X, z: BACK_Z, armR: [60, -30, 0], armL: [55, 30, 0], face: { expr: 'crying' } }, t);
    peekers(W, t, ['granny', 'lilsis'], { granny: { expr: 'shocked' }, lilsis: { expr: 'shocked' } });
    return { cam: cam([1.9, 5.25, 1.6], [2.5, 4.7, -3.3], 34), look: LOOK(5.0, 0.1), cap: { title: TITLE, speaker: 'MOM:', line: 'NICE TRY.', at: 6.68 } };
  });

  // ---------------- GRANNY ----------------
  const GX = -5.75;
  const boxX = (t) => -2.55 * seg(t, 8.65, 10.15, (u) => E.io(u) + Math.sin(u * 40) * 0.01);
  add('C1', 7.8, 'GRANNY: cane hooks the box', (W, lt, t) => {
    const reach = seg(lt, 0.1, 0.6, E.out), pull = seg(lt, 0.85, 2.35, E.io);
    W.cast.granny.cane.rotation.x = 0.8 * reach - 0.12 * pull;
    put(W, 'granny', { x: GX, z: 0.45, ry: 90, head: [0, -45, 0], lean: 4, armR: [lerp(10, 130, reach) - pull * 12, 0, 0], armL: [20, 6, 0], face: { expr: pull > 0 ? 'smug' : 'sneaky', talk: talk(t, 7.9) } }, t);
    W.box.position.x = boxX(t);
    peekers(W, t, ['lilsis'], { lilsis: { expr: 'shocked', look: [-0.9, -0.2] } });
    put(W, 'dad', { x: DAD_X - 0.3, z: BACK_Z - 0.6, armR: [55, -25, 0], armL: [55, 25, 0], face: { expr: 'pout', look: [-0.9, -0.3] } }, t);
    return { cam: cam([-1.2, 5.0, 8.2], [-3.9, 3.7, 0.3], 56), look: LOOK(8.4, 0.035), cap: { title: TITLE, speaker: 'GRANNY:', line: 'GRANNY NEEDS HER VITAMINS.', at: 7.88 } };
  });
  add('C2', 10.3, 'YOINK — lil sis jumps for it', (W, lt, t) => {
    W.cast.granny.cane.rotation.x = 0.68; put(W, 'granny', { x: GX, z: 0.45, ry: 90, head: [0, -45, 0], lean: 4, armR: [118, 0, 0], armL: [20, 6, 0], face: { expr: lt < 0.3 ? 'smug' : 'shocked' } }, t);
    W.box.position.x = boxX(t);
    const jump = Math.sin(clamp((lt - 0.05) / 0.55) * Math.PI);
    const grab = lt > 0.28;
    const sis = put(W, 'lilsis', { x: -2.4, z: -2.85, y: peekY(W, 'lilsis', 3.4) + jump * 1.5, armR: [lerp(160, 120, seg(lt, 0.28, 0.5)), 0, 0], armL: [160, 8, 0], face: { expr: grab ? 'grin' : 'sneaky' } }, t);
    if (grab) hold(W.slice, sis.hand('R'), [0, -0.1, 0.25], [Math.PI / 2, 0, Math.PI]);
    else W.slice.position.set(W.box.position.x + 0.15, W.COUNTER + 0.06, 0.45);
    return { cam: cam([-3.6, 5.0, 5.6], [-2.8, 4.0, -1.2], 52, { shake: 0.4 }), look: LOOK(7.0, 0.04), cap: { title: TITLE, word: { text: 'YOINK!', at: 10.55, x: 0.62, y: 0.6, rot: 8, dur: 0.6 } } };
  });

  // ---------------- LIL SIS ----------------
  const SIS = [0.1, 0, 4.0];
  const sisHold = (W, sis) => hold(W.slice, sis.hand('R'), [0.0, -0.02, 0.0], [0.1, 0, Math.PI]);
  add('D1', 11.1, 'LIL SIS: licks it — mine now', (W, lt, t) => {
    const lick = seg(lt, 0.55, 1.25, E.io), licking = lt > 0.55 && lt < 1.3;
    const sway = licking ? Math.sin((lt - 0.55) * 12) * 6 : 0;
    const sis = put(W, 'lilsis', { x: SIS[0], z: SIS[2], ry: 8, armR: [112 + sway * 0.6, -46, 0], armL: [20, 8, 0], head: [6, 10, sway], face: { expr: licking ? 'lick' : lt > 1.3 ? 'smug' : 'grin', talk: talk(t, 12.45) } }, t);
    sisHold(W, sis);
    W.slice.userData.shine.material.opacity = 0.75 * lick;
    return { cam: cam([0.45, 3.2, 8.6], [0.0, 2.75, 4.0], 36), look: LOOK(4.6, 0.1), cap: { title: TITLE, speaker: 'LIL SIS:', line: lt > 1.3 ? 'LICKED IT. MINE NOW.' : '', at: lt > 1.3 ? 12.4 : 11.15 } };
  });
  const ew = (id, start, who, line, expr, look) => add(id, start, `${who}: ${line}`, (W, lt, t) => {
    const recoil = seg(lt, 0, 0.18, E.out);
    put(W, who, { x: 0, z: BACK_Z, y: who === 'lilsis' ? peekY(W, who, 3.9) : 0, lean: -12 * recoil, armL: [70 * recoil, 30, 0], armR: [70 * recoil, 30, 0], head: [-10 * recoil, 0, 6 * Math.sin(lt * 30) * (1 - recoil)], face: { expr, talk: talk(t, start + 0.05, 0.5) } }, t);
    const h = W.cast[who].height;
    return { cam: cam([0.0, h - 0.4, BACK_Z + 4.4 - lt * 0.6], [0, h - 0.55, BACK_Z], 34), look: LOOK(4.2, 0.12), cap: { title: TITLE, speaker: `${look}:`, line, at: start + 0.04 } };
  });
  ew('D2', 13.4, 'dad', 'EWWW!', 'disgusted', 'DAD');
  ew('D3', 14.05, 'granny', 'GROSS!', 'sick', 'GRANNY');
  ew('D4', 14.7, 'mom', 'SHE DID IT AGAIN...', 'disgusted', 'MOM');

  // ---------------- LIL BRO ----------------
  add('E1', 15.35, 'LIL BRO: walks in cool (slow-mo)', (W, lt, t) => {
    const u = clamp(lt / 2.45);
    const x = lerp(7.4, 2.3, E.out(u));
    const w = walk(lt * 4.2, 26 * (1 - seg(lt, 2.0, 2.45)));
    put(W, 'lilbro', { x, z: 4.15, ry: -90 + 50 * seg(lt, 1.6, 2.4, E.io), ...w, shades: true, face: { expr: 'cool' }, head: [0, -20 * (1 - seg(lt, 1.6, 2.4)), 0] }, t);
    const sis = put(W, 'lilsis', { x: SIS[0], z: SIS[2], ry: 25, armR: [108, -42, 0], armL: [20, 8, 0], face: { expr: 'smug', look: [0.9, 0] } }, t);
    sisHold(W, sis); W.slice.userData.shine.material.opacity = 0.75;
    return { cam: cam([0.6, 2.2, 14.2], [3.4, 3.1, 4.2], 46), look: LOOK(10.2, 0.04), cap: { title: TITLE, speaker: 'LIL BRO:', line: '', at: 15.4 } };
  });
  add('E2', 17.8, 'takes it — eats it in ONE bite', (W, lt, t) => {
    const take = lt > 0.42, eat = seg(lt, 0.62, 0.86, E.in), gone = lt > 0.86;
    const bro = put(W, 'lilbro', { x: 2.05, z: 4.05, ry: -38, shades: true, armR: [lerp(lerp(20, 95, seg(lt, 0.15, 0.42)), 150, eat), lerp(0, -20, seg(lt, 0.15, 0.42)), 0], armL: [10, 5, 0], face: { expr: gone ? 'chew' : 'cool', talk: gone ? Math.abs(Math.sin(lt * 14)) : 0 } }, t);
    const sis = put(W, 'lilsis', { x: SIS[0], z: SIS[2], ry: 35, armR: [take ? 60 : 108, take ? -10 : -42, 0], armL: [20, 8, 0], face: { expr: take ? 'shocked' : 'smug', look: [0.9, 0.1] } }, t);
    if (!take) sisHold(W, sis);
    else if (!gone) hold(W.slice, bro.hand('R'), [0, -0.05, 0.15], [0.3, 0, Math.PI]);
    else W.slice.visible = false;
    W.slice.userData.shine.material.opacity = 0.75;
    return { cam: cam([1.1, 3.75, 10.2], [1.05, 3.0, 4.0], 42), look: LOOK(6.2, 0.06), cap: { title: TITLE, word: { text: 'CHOMP!', at: 17.8 + 0.8, x: 0.66, y: 0.55, rot: 9, dur: 0.55 } } };
  });
  add('E3', 19.2, 'LIL BRO: worth it', (W, lt, t) => {
    put(W, 'lilbro', { x: 2.05, z: 4.05, ry: -10, shades: true, armR: [12, 4, 0], armL: [12, 4, 0], face: { expr: 'cool', talk: talk(t, 19.3, 0.5) }, head: [0, 0, -6] }, t);
    W.slice.visible = false;
    const h = W.cast.lilbro.height;
    return { cam: cam([2.35, h - 0.1, 8.6 - lt * 0.4], [2.05, h - 0.85, 4.05], 38), look: LOOK(3.2, 0.12), cap: { title: TITLE, speaker: 'LIL BRO:', line: 'WORTH IT.', at: 19.28 } };
  });
  add('E4', 20.5, 'LIL SIS: NOOO', (W, lt, t) => {
    put(W, 'lilsis', { x: SIS[0], z: SIS[2], ry: 5, armR: [150, 20, 0], armL: [150, 20, 0], face: { expr: 'crying', talk: Math.abs(Math.sin(lt * 9)) }, head: [-8, 0, Math.sin(lt * 18) * 4] }, t);
    W.slice.visible = false;
    const h = W.cast.lilsis.height;
    return { cam: cam([0.3, h - 0.1, 7.1], [0.1, h - 0.55, 4.0], 34), look: LOOK(3.2, 0.12), cap: { title: TITLE, speaker: 'LIL SIS:', line: 'NOOOOO!', red: true, at: 20.58 } };
  });

  // ---------------- TWIST ----------------
  const MOMO = [12.6, -2.4];
  add('F1', 21.9, 'TWIST: mom opens the oven', (W, lt, t) => {
    const open = seg(lt, 0.35, 0.95, E.out);
    W.setOven(open, open);
    W.pizza.visible = open > 0.6; W.pizza.position.set(13.15, 4.45, -5.5);
    W.sparkles.visible = open > 0.6; W.sparkles.position.set(13.15, 4.5, -5.5); W.sparkles.userData.update(t, open, 1.4);
    put(W, 'mom', { x: MOMO[0], z: MOMO[1], ry: lerp(150, -60, seg(lt, 0.9, 1.3, E.io)), armL: [lerp(20, 80, seg(lt, 0.1, 0.4)) - 30 * open, -10, 0], armR: [lerp(10, 120, seg(lt, 1.1, 1.4)), 20, 0], face: { expr: lt > 1.0 ? 'happy' : 'neutral', talk: talk(t, 22.95, 0.9) } }, t);
    W.slice.visible = false;
    return { cam: cam([7.2, 5.4, 2.6], [12.5, 4.4, -4.0], 46), look: LOOK(8.0, 0.04), cap: { title: TITLE, speaker: 'MOM:', line: lt > 1.0 ? 'WHO WANTS THE OTHER PIZZA?' : '', at: 22.92 } };
  });
  add('F2', 24.2, 'everyone cheers', (W, lt, t) => {
    W.setOven(1, 1); W.pizza.visible = true; W.pizza.position.set(13.15, 4.45, -5.5); W.slice.visible = false;
    const hopA = Math.abs(Math.sin(lt * 7.5)) * 0.9, hopB = Math.abs(Math.sin(lt * 7.5 + 1.2)) * 0.9, hopC = Math.abs(Math.sin(lt * 7.5 + 2.1)) * 1.1;
    put(W, 'dad', { x: 6.2, z: -1.6, ry: 70, hop: hopA, armL: [165, 15, 0], armR: [165, 15, 0], face: { expr: 'grin' } }, t);
    put(W, 'granny', { x: 7.4, z: 0.9, ry: 75, hop: hopB * 0.5, armL: [150, 10, 0], armR: [60, 0, 0], face: { expr: 'love' } }, t);
    put(W, 'lilsis', { x: 8.2, z: -0.4, ry: 80, hop: hopC, armL: [170, 15, 0], armR: [170, 15, 0], face: { expr: 'love' } }, t);
    put(W, 'mom', { x: MOMO[0], z: MOMO[1], ry: -60, armL: [40, 10, 0], armR: [40, 10, 0], face: { expr: 'happy' } }, t);
    return { cam: cam([12.4, 4.9, -2.0], [6.8, 3.7, -0.3], 50), look: LOOK(6.0, 0.05), cap: { title: TITLE, speaker: 'EVERYONE:', line: 'YAAAAY!', at: 24.25 } };
  });
  add('F3', 25.5, 'LIL BRO: ...regret', (W, lt, t) => {
    const fall = clamp((lt - 0.35) / 0.5), sick = seg(lt, 0.75, 1.25);
    const bro = put(W, 'lilbro', { x: 2.05, z: 4.05, ry: 0, shades: lt < 0.85, armR: [10, 4, 0], armL: [10, 4, 0], face: { expr: sick > 0.3 ? 'sick' : 'shocked' }, head: [6 * fall, 0, 0], tint: ['#8fd14f', 0.5 * sick] }, t);
    bro.shades.position.y = bro.dims.hh / 2 + 0.07 - 0.08 * fall - 4.5 * fall * fall; bro.shades.position.z = bro.dims.hd / 2 + 0.05 + 0.4 * fall; bro.shades.rotation.x = 1.2 * fall;
    W.slice.visible = false;
    const h = bro.height;
    return { cam: cam([2.05, h - 0.15, 8.2 - lt * 0.35], [2.05, h - 0.85, 4.05], 36), look: LOOK(4.0, 0.1), cap: { title: TITLE, speaker: 'LIL BRO:', line: lt > 1.0 ? 'I ATE THE LICKED ONE...' : '', red: true, at: 26.52 } };
  });
  add('G1', 28.0, 'like-heart ending', (W, lt, t) => {
    const r = S.find((s) => s.id === 'F3').setup(W, 2.5, 28.0);
    return { ...r, blur: 22, like: lt, cap: { title: TITLE } };
  });
  S.pre = (W, t) => { W.box.position.x = boxX(t); if (!W.slice.parent || W.slice.parent.type === 'Scene') W.slice.position.x = W.box.position.x + 0.15; };
  S.cues = [];
  S[S.length - 1].end = 30.0;
  return S;
}

