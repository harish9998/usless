# Publish sheet — WHEN THERE'S ONE SLICE OF PIZZA LEFT (30 s, 9:16)

Titles (pick one):
1. When There's One Slice Of Pizza Left! #roblox #robloxanimation
2. When There's ONE Slice Of Pizza Left... #roblox #robloxanimation
3. When Lil Sis Licks The Last Slice! #roblox #robloxanimation

Description: The last slice. The whole family. Who wins? 🍕 #roblox #robloxanimation
Thumbnail: frame 1 (title + four heads peeking at the slice).
Beats: hook 0:00 · DAD 0:03 · MOM slap 0:06 · GRANNY 0:08 · YOINK 0:10 · LIL SIS licks 0:11 · EWWW 0:13 · LIL BRO 0:15 · WORTH IT 0:19 · TWIST 0:22 · regret 0:25 · like 0:28
