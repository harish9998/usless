#!/bin/bash
# Start a new short from the template (a working copy of the pizza demo — edit src/shots.js + data/sound.json).
#   new_short.sh <name> [parent_dir]      → <parent_dir>/<name>  (default parent: ~/roblox-shorts)
set -e
HERE="$(cd "$(dirname "$0")/.." && pwd)"
NAME=${1:?usage: new_short.sh <name> [parent_dir]}; PARENT=${2:-$HOME/roblox-shorts}
DEST="$PARENT/$NAME"; [ -e "$DEST" ] && { echo "exists: $DEST"; exit 1; }
mkdir -p "$PARENT" && cp -R "$HERE/template" "$DEST" && mkdir -p "$DEST/renders" "$DEST/review"
echo "$DEST"
