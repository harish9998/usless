#!/bin/bash
# Proves the install works: copies the template, renders the "mom's car" demo (30 s, 1080x1920 with sound), checks it.
#   selftest.sh   →  ~/roblox-shorts/_selftest/renders/car.mp4  (about 1–2 minutes on an M-series Mac)
set -e
HERE="$(cd "$(dirname "$0")/.." && pwd)"
bash "$HERE/scripts/setup.sh"
T="$HOME/roblox-shorts/_selftest"; [ -d "$T" ] && rm -rf "${T:?}"
bash "$HERE/scripts/new_short.sh" _selftest "$HOME/roblox-shorts" >/dev/null
bash "$HERE/scripts/render.sh" "$T" car "$T/renders/car.mp4"
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$T/renders/car.mp4")
A=$(ffprobe -v error -select_streams a -show_entries stream=codec_name -of csv=p=0 "$T/renders/car.mp4")
ffmpeg -loglevel error -y -i "$T/renders/car.mp4" -vf "fps=1,scale=216:-1,tile=10x3" -frames:v 1 "$T/review/selftest_sheet.jpg"
awk -v d="$D" 'BEGIN{exit !(d>29 && d<31)}' && [ -n "$A" ] && echo "SELFTEST PASSED: $T/renders/car.mp4 (${D}s, audio $A) · sheet $T/review/selftest_sheet.jpg" || { echo "SELFTEST FAILED (duration $D, audio '$A')"; exit 1; }
