#!/bin/bash
# Synth the soundtrack (data/sound_<film>.json, or data/sound.json for the pizza film), master it (-14.5 LUFS, -2 dBTP),
# then render the 1080x1920 30 fps MP4.     render.sh <project_dir> <film> [out.mp4]      (~30 s on an M-series Mac)
set -e
P="$(cd "${1:?usage: render.sh <project_dir> <film> [out.mp4]}" && pwd)"; FILM="${2:?film id, e.g. car}"; OUT="${3:-$P/renders/$FILM.mp4}"
PY=""; for c in "$HOME/.roblox-shorts/venv/bin/python" python3; do "$c" -I -c "import numpy, scipy, soundfile" 2>/dev/null && PY=$c && break; done
[ -z "$PY" ] && { echo "run scripts/setup.sh first"; exit 1; }
if [ -f "$P/data/sound_$FILM.json" ]; then "$PY" -I "$P/tools/mix.py" "$P" "$FILM"; RAW="$P/data/mix_$FILM.wav"; else "$PY" -I "$P/tools/mix.py" "$P"; RAW="$P/data/mix.wav"; fi
ffmpeg -loglevel error -y -i "$RAW" -af "loudnorm=I=-14.5:TP=-2:LRA=11,alimiter=limit=0.75:level=false:attack=1:release=60,aresample=48000" "$P/data/mix_${FILM}_master.wav"
cd "$P/tools" && QS="&film=$FILM" AUDIO="$P/data/mix_${FILM}_master.wav" node capture.mjs video "$OUT" 0 -1 4 --audio
ffmpeg -hide_banner -i "$OUT" -af ebur128=peak=true -f null - 2>&1 | grep -E "^\s+(I|Peak):" || true
