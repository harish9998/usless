#!/bin/bash
# One-time check/setup: Node 22+, Google Chrome, ffmpeg, and a Python with numpy + scipy + soundfile (for the synth mix).
set -e
ok=1
node -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)' 2>/dev/null && echo "node $(node -v) ok" || { echo "need Node 22+ (brew install node)"; ok=0; }
[ -x "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ] && echo "chrome ok" || { echo "need Google Chrome in /Applications (or set CHROME=/path)"; ok=0; }
command -v ffmpeg >/dev/null && echo "ffmpeg ok" || { echo "need ffmpeg (brew install ffmpeg)"; ok=0; }
PY=""
for c in "$HOME/.roblox-shorts/venv/bin/python" python3; do "$c" -I -c "import numpy, scipy, soundfile" 2>/dev/null && PY=$c && break; done
if [ -z "$PY" ]; then
  echo "creating ~/.roblox-shorts/venv (numpy scipy soundfile)…"
  python3 -m venv "$HOME/.roblox-shorts/venv" && "$HOME/.roblox-shorts/venv/bin/pip" -q install numpy scipy soundfile
  PY="$HOME/.roblox-shorts/venv/bin/python"
fi
echo "python: $PY"
[ $ok = 1 ] && echo "READY" || { echo "fix the items above"; exit 1; }
