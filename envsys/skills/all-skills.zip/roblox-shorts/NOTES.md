# NOTES — lessons + user feedback (read before every short, add after)

- 2026-11-03 (first build). The user rejected the first reference sheets as "nothing like Roblox": a generic rounded-toy look.
  Fix that worked: upload 5–7 real frames from the winning channel as GPT Image 2.5 image references and say "Roblox Studio
  render of Roblox avatars" in the prompt. Keep our own characters/outfits, keep logos out.
- The user wants this as a reusable skill and picks topics from winning posts ("go by a winning post").
- Build lessons: custom head geometry must be wound outward (inside-out heads hide the face decal). Hair caps must stop
  above the brows (hairline ≈ 0.17–0.2 × head height below the top). An open pizza-box lid stands like a wall — fold it flat.
  Short avatars' shoulders sit below the 3.2-stud counter: raise the arm (rx ≥ 118) or the arm goes into the counter.
  Bloom on a white kitchen = haze: keep bloom threshold ≥ 1.6, floor envMapIntensity ≈ 0.35, ACES tone curve.
- Sound: the user dislikes samey grooves, ticks, hats and glitch noise. Every synthesized sound gets a 25 ms tail fade.
- capture.mjs leaves Chrome temp profiles in $TMPDIR if the process exits too fast — exit waits 1.5 s now; the disk is tight.
- 2026-11-03 second short. The user said the pizza short "doesn't look as good" as Offline Hearts' 3 AM short (JbCxC0k_SEU).
  What closed the gap: round cylinder heads, drawn eyes with coloured irises + eyelids, glossy plastic skin + fabric clothes,
  night lighting (low ambient, blue moon, warm lamp, RGB/LED practicals, camera-side key), grade exposure 0.92 / sat 1.32 /
  contrast 0.35 / sharpen, wide-lens close-ups + dutch angles + foreground objects, Montserrat 800 white captions with shadow.
  Bright lights + bloom = haze: keep bloom threshold 2.6 and light intensities modest (ceiling 70, headlights 520).
  Deterministic textures only (no Math.random) — 4 render workers must draw identical frames.
