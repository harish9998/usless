#!/usr/bin/env python3
"""Soundtrack for the Block Family short, 100% synthesized (no samples, no voices, $0).
Soft musical score per section + cartoon foley on cues. Writes data/mix.wav (48 kHz stereo, ~-15 LUFS).
   python3 -I tools/mix.py [project_dir]
Sections and cue times come from data/sound.json (written next to the shots; edit times there)."""
import json, sys, os
import numpy as np
from scipy import signal

SR = 48000
ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..')
FILM = sys.argv[2] if len(sys.argv) > 2 else ''
CFG = json.load(open(os.path.join(ROOT, f'data/sound_{FILM}.json' if FILM else 'data/sound.json')))
DUR = CFG['duration']
N = int(DUR * SR)
music = np.zeros((N, 2)); fx = np.zeros((N, 2))
rng = np.random.default_rng(7)

def tt(d): return np.arange(int(d * SR)) / SR
def env(n, a=0.005, r=0.1, hold=None):
    t = np.arange(n) / SR; e = np.minimum(1, t / max(a, 1e-4))
    if hold is not None: e *= np.where(t < hold, 1, np.exp(-(t - hold) / max(r, 1e-4)))
    return e
def place(buf, x, at, gain=1.0, pan=0.0):
    i = int(at * SR)
    if i >= len(buf): return
    x = np.array(x[: len(buf) - i], dtype=float)
    fo, fi = min(len(x), int(0.025 * SR)), min(len(x), int(0.0015 * SR))  # never cut a sound off: 25 ms tail fade, 1.5 ms head
    if fo > 0: x[-fo:] *= np.linspace(1, 0, fo) ** 2
    if fi > 0: x[:fi] *= np.linspace(0, 1, fi)
    l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    buf[i:i + len(x), 0] += x * gain * l * 1.41; buf[i:i + len(x), 1] += x * gain * r * 1.41
def mtof(m): return 440 * 2 ** ((m - 69) / 12)
def lp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, 'low', fs=SR, output='sos'), x)
def hp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, 'high', fs=SR, output='sos'), x)
def bp(x, lo, hi, o=2): return signal.sosfilt(signal.butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def noise(d): return rng.standard_normal(int(d * SR))
def sweep_bp(x, f0, f1, q=4.0, blocks=64):
    out = np.zeros_like(x); n = len(x); bs = max(1, n // blocks); zi = None
    for k in range(0, n, bs):
        u = k / max(1, n - 1); fc = f0 * (f1 / f0) ** u
        sos = signal.butter(2, [fc / (1 + 1 / q), min(fc * (1 + 1 / q), SR / 2 - 100)], 'band', fs=SR, output='sos')
        if zi is None: zi = signal.sosfilt_zi(sos) * 0
        out[k:k + bs], zi = signal.sosfilt(sos, x[k:k + bs], zi=zi)
    return out

# ---------------- instruments ----------------
def pizz(f, d=0.45, bright=1.0):
    t = tt(d); y = sum((1 / k) * np.sin(2 * np.pi * f * k * t) * np.exp(-t * (6 + k * 2.2 / bright)) for k in range(1, 9))
    return y * env(len(t), 0.002) * 0.5
def marimba(f, d=0.6):
    t = tt(d); y = np.sin(2 * np.pi * f * t) * np.exp(-t * 5) + 0.35 * np.sin(2 * np.pi * f * 3.93 * t) * np.exp(-t * 18) + 0.12 * np.sin(2 * np.pi * f * 9.2 * t) * np.exp(-t * 40)
    return y * env(len(t), 0.002) * 0.5
def bassoon(f, d=0.22):
    t = tt(d + 0.08); vib = 1 + 0.004 * np.sin(2 * np.pi * 5 * t)
    ph = 2 * np.pi * f * np.cumsum(vib) / SR
    y = sum((0.8 / k) * np.sin(k * ph) for k in range(1, 12, 1)) ; y = lp(y, 1400)
    e = np.minimum(1, t / 0.015) * np.where(t < d, 1, np.exp(-(t - d) / 0.03))
    return y * e * 0.32
def epiano(f, d=1.6):
    t = tt(d); mod = np.sin(2 * np.pi * f * t) * 1.2 * np.exp(-t * 6)
    y = np.sin(2 * np.pi * f * t + mod) * np.exp(-t * 1.6) + 0.2 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 3)
    return y * env(len(t), 0.004) * 0.22
def subbass(f, d):
    t = tt(d); y = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)
    return y * env(len(t), 0.01, 0.08, d - 0.08) * 0.42
def kick(g=1.0):
    t = tt(0.4); f = 45 + 80 * np.exp(-t * 28); y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7)
    return y * g * 0.8
def snare(g=1.0):
    t = tt(0.25); y = bp(noise(0.25), 900, 6000) * np.exp(-t * 22) * 0.45 + np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25) * 0.4
    return y * g
def choir(notes, d, vowel=(700, 1150)):
    t = tt(d); y = np.zeros(len(t))
    for m in notes:
        f = mtof(m)
        for det in (-0.12, 0.0, 0.11):
            ff = f * 2 ** (det / 12); vib = 1 + 0.006 * np.sin(2 * np.pi * (4.8 + det) * t + det * 9)
            ph = 2 * np.pi * ff * np.cumsum(vib) / SR
            for k in range(1, 16):
                fk = ff * k; a = (1 / k) * (np.exp(-((fk - vowel[0]) / 260) ** 2) * 1.6 + np.exp(-((fk - vowel[1]) / 340) ** 2) + 0.15)
                y += a * np.sin(k * ph)
    e = np.minimum(1, t / (d * 0.35)) * np.minimum(1, (d - t) / (d * 0.35))
    return y * e / (len(notes) * 3) * 0.55
def trombone(seq, start_gap=0.0):
    out = []
    for m, d, wob in seq:
        t = tt(d); f = mtof(m) * (1 + (0.025 * np.sin(2 * np.pi * 6 * t) * np.minimum(1, t / 0.3) if wob else 0))
        f = f * (1 - 0.03 * np.exp(-t * 20))
        ph = 2 * np.pi * np.cumsum(f) / SR
        y = sum((1 / k ** 0.8) * np.sin(k * ph) for k in range(1, 14)); y = lp(y, 1800)
        e = np.minimum(1, t / 0.03) * np.minimum(1, (d - t) / 0.08)
        out.append(y * e * 0.22); out.append(np.zeros(int(0.03 * SR)))
    return np.concatenate(out)

# ---------------- foley ----------------
def slap():
    t = tt(0.35); y = hp(noise(0.35), 1500) * np.exp(-t * 60) * 0.9 + np.sin(2 * np.pi * 95 * t) * np.exp(-t * 18) * 0.7 + bp(noise(0.35), 300, 1200) * np.exp(-t * 30) * 0.5
    return y
def whoosh(d=0.45, f0=300, f1=3000):
    t = tt(d); y = sweep_bp(noise(d), f0, f1, 3) * np.sin(np.pi * t / d) ** 1.5
    return y * 1.6
def boing(f=240, d=0.6):
    t = tt(d); f = f * (1 + 0.45 * np.sin(2 * np.pi * 13 * t) * np.exp(-t * 4)); y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 4.5)
    return y * 0.55
def slide_whistle(f0, f1, d):
    t = tt(d); f = f0 * (f1 / f0) ** (t / d) * (1 + 0.01 * np.sin(2 * np.pi * 6 * t)); y = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.05 * bp(noise(d), 1500, 5000)
    return y * env(len(t), 0.03, 0.06, d - 0.06) * 0.35
def whistle_tune(notes):
    out = []
    for m, d in notes:
        t = tt(d); f = mtof(m) * (1 + 0.012 * np.sin(2 * np.pi * 6.5 * t)); y = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.04 * bp(noise(d), 2000, 6000)
        out.append(y * env(len(t), 0.03, 0.05, d - 0.05) * 0.3)
    return np.concatenate(out)
def slurp(d=0.6):
    t = tt(d); y = sweep_bp(noise(d), 500, 2400, 5) * (0.6 + 0.4 * np.sin(2 * np.pi * 22 * t)) * np.sin(np.pi * t / d)
    return y * 2.2
def chomp():
    out = np.zeros(int(0.5 * SR))
    for k, at in enumerate([0.0, 0.16, 0.3]):
        t = tt(0.12); y = lp(noise(0.12), 2500) * np.exp(-t * 35) * (1 - k * 0.2) + np.sin(2 * np.pi * 140 * t) * np.exp(-t * 40) * 0.6
        i = int(at * SR); out[i:i + len(y)] += y
    return out * 0.9
def gulp():
    t = tt(0.35); f = 380 * np.exp(-t * 6) + 110; y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-((t - 0.1) / 0.08) ** 2)
    return y * 0.7
def ding(f=1320, d=1.6):
    t = tt(d); y = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * dc) for r, a, dc in [(1, 1, 2.2), (2.76, 0.35, 5), (5.4, 0.15, 9), (8.9, 0.06, 14)])
    return y * 0.35
def twinkle(base=84, n=6, gap=0.07):
    out = np.zeros(int((n * gap + 0.8) * SR))
    for k in range(n):
        y = ding(mtof(base + [0, 4, 7, 12, 16, 19][k % 6]), 0.7) * 0.5; i = int(k * gap * SR); out[i:i + len(y)] += y
    return out
def scrape(d):
    t = tt(d); y = bp(noise(d), 180, 1400) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 9 * t + 3 * np.sin(2 * np.pi * 1.3 * t))))
    return y * env(len(t), 0.05, 0.1, d - 0.1) * 0.55
def scratch():
    t = tt(0.5); f = 600 + 500 * np.sin(2 * np.pi * 7 * t); y = signal.sawtooth(2 * np.pi * np.cumsum(f) / SR) * 0.3 + bp(noise(0.5), 800, 4000) * 0.6
    return lp(y, 3500) * np.sin(np.pi * t / 0.5) * 0.7
def creak(d=0.7):
    t = tt(d); f = 140 + 60 * t / d; y = signal.sawtooth(2 * np.pi * np.cumsum(f) / SR) * (0.5 + 0.5 * np.sin(2 * np.pi * 31 * t)); y = bp(y, 300, 2200)
    return y * np.sin(np.pi * t / d) * 0.35
def party_horn(d=0.7):
    t = tt(d); f = 520 * (1 + 0.06 * np.minimum(1, t / 0.15)) * (1 + 0.01 * np.sin(2 * np.pi * 30 * t)); y = signal.square(2 * np.pi * np.cumsum(f) / SR) ; y = bp(y, 400, 3500)
    return y * env(len(t), 0.02, 0.08, d - 0.08) * 0.22
def confetti():
    out = np.zeros(int(0.6 * SR))
    for k in range(9):
        t = tt(0.05); y = hp(noise(0.05), 3000) * np.exp(-t * 90) * 0.25; i = int(rng.uniform(0, 0.5) * SR); out[i:i + len(y)] += y
    return out
def clatter():
    out = np.zeros(int(0.6 * SR))
    for k, at in enumerate([0.0, 0.11, 0.19, 0.25]):
        t = tt(0.08); y = (np.sin(2 * np.pi * (1900 - k * 200) * t) * 0.5 + hp(noise(0.08), 2000) * 0.4) * np.exp(-t * 60) * (1 - k * 0.2); i = int(at * SR); out[i:i + len(y)] += y
    return out * 0.7
def pop():
    t = tt(0.18); f = 700 + 1100 * (1 - np.exp(-t * 40)); y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 26)
    return y * 0.6 + hp(noise(0.18), 4000) * np.exp(-t * 200) * 0.3
def dun(m=38, d=0.5):
    t = tt(d); f = mtof(m); y = sum((1 / k) * np.sin(2 * np.pi * f * k * t) for k in range(1, 10)); y = lp(y, 900) * np.exp(-t * 3.5)
    return (y + np.sin(2 * np.pi * f / 2 * t) * np.exp(-t * 4) * 0.6) * env(len(t), 0.01) * 0.45
def boom():
    t = tt(1.4); f = 32 + 40 * np.exp(-t * 6); y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 2.2)
    return y * 0.9 + lp(noise(1.4), 200) * np.exp(-t * 5) * 0.15

def engine(d=3.0):
    t = tt(d); f = 38 + 10 * np.minimum(1, t / 1.5) - 14 * np.maximum(0, t - 2.2)
    y = signal.sawtooth(2 * np.pi * np.cumsum(f) / SR) * 0.5 + np.sin(2 * np.pi * np.cumsum(f * 0.5) / SR)
    y = lp(y, 260) + lp(noise(d), 700) * 0.25 * (0.5 + 0.5 * np.sin(2 * np.pi * 9 * t))
    return y * np.minimum(1, t / 1.2) * np.minimum(1, (d - t) / 0.6) * 0.5
def car_door():
    t = tt(0.5); y = np.sin(2 * np.pi * 70 * t) * np.exp(-t * 14) + lp(noise(0.5), 900) * np.exp(-t * 22) * 0.6 + hp(noise(0.5), 3000) * np.exp(-t * 80) * 0.15
    return y * 0.9
def heartbeat(n=4, gap=0.62):
    out = np.zeros(int((n * gap + 0.4) * SR))
    for k in range(n):
        for off, g in ((0, 1.0), (0.17, 0.7)):
            t = tt(0.25); y = np.sin(2 * np.pi * (52 + 30 * np.exp(-t * 30)) * t) * np.exp(-t * 16) * g
            i = int((k * gap + off) * SR); out[i:i + len(y)] += y
    return out * 0.8
def crash():
    out = np.zeros(int(2.0 * SR))
    for k in range(26):
        at = rng.uniform(0, 1.3) ** 1.6; d = 0.25; t = tt(d)
        f = rng.uniform(150, 900); y = (np.sin(2 * np.pi * f * t) * 0.4 + bp(noise(d), 300, 5000) * 0.7) * np.exp(-t * rng.uniform(12, 30))
        i = int(at * SR); out[i:i + len(y)] += y * rng.uniform(0.4, 1.0)
    t = tt(2.0); out += lp(noise(2.0), 400) * np.exp(-t * 2.5) * 0.5 + np.sin(2 * np.pi * 45 * t) * np.exp(-t * 3) * 0.6
    return out * 0.8
def switch():
    t = tt(0.12); y = bp(noise(0.12), 900, 3000) * np.exp(-t * 90) + np.sin(2 * np.pi * 320 * t) * np.exp(-t * 60) * 0.4
    return y * 0.6
def steps(n=4, gap=0.42):
    out = np.zeros(int((n * gap + 0.3) * SR))
    for k in range(n):
        t = tt(0.2); y = lp(noise(0.2), 500) * np.exp(-t * 30) + np.sin(2 * np.pi * 80 * t) * np.exp(-t * 35) * 0.5
        i = int(k * gap * SR); out[i:i + len(y)] += y * (0.8 + 0.2 * (k % 2))
    return out * 0.7
def tape_ff():
    t = tt(0.6); f = 200 * (12 ** (t / 0.6)); y = signal.sawtooth(2 * np.pi * np.cumsum(f) / SR) * 0.3; y = bp(y, 300, 5000)
    return y * np.sin(np.pi * t / 0.6) * 0.5 + whoosh(0.6, 400, 6000)[: len(t)] * 0.4
def dun_dun_dun():
    return np.concatenate([dun(40, 0.42), dun(39, 0.42), dun(35, 1.2)])

FX = {'engine': engine, 'car_door': car_door, 'heartbeat': heartbeat, 'crash': crash, 'switch': switch, 'steps': steps, 'tape': tape_ff, 'dundundun': dun_dun_dun,
      'slap': slap, 'whoosh': whoosh, 'boing': boing, 'slurp': slurp, 'chomp': chomp, 'gulp': gulp, 'ding': ding, 'twinkle': twinkle,
      'scratch': scratch, 'creak': creak, 'horn': party_horn, 'confetti': confetti, 'clatter': clatter, 'pop': pop, 'boom': boom,
      'dun': lambda: np.concatenate([dun(38, 0.32), dun(38, 0.32), dun(37, 0.7)]),
      'slide_up': lambda: slide_whistle(500, 1500, 0.55), 'slide_down': lambda: slide_whistle(1300, 380, 0.7),
      'whistle': lambda: whistle_tune([(79, 0.18), (83, 0.18), (86, 0.32), (83, 0.36)]),
      'trombone': lambda: trombone([(58, 0.42, False), (57, 0.42, False), (56, 0.42, False), (55, 1.3, True)]),
      'blip_down': lambda: slide_whistle(900, 300, 0.35), 'scrape': lambda: scrape(1.5)}

# ---------------- score ----------------
def score_sneaky(t0, t1):
    beat = 60 / 112; bass = [50, 53, 57, 61, 62, 61, 57, 53]  # D F A C# D C# A F (sneaky minor walk)
    mel = [74, None, 77, None, 76, 73, None, 74, 69, None, 72, 71, 70, None, 69, None]
    k = 0; t = t0
    while t < t1 - 0.05:
        place(music, pizz(mtof(bass[k % 8] - 12), 0.42), t, 0.9, -0.15)
        if k % 2 == 1: place(music, bassoon(mtof([62, 65, 64, 61][(k // 2) % 4] - 12), 0.14), t + beat * 0.5, 0.55, 0.2)
        m = mel[k % 16]
        if m and k >= 8: place(music, marimba(mtof(m), 0.5), t + beat * 0.5, 0.42, 0.3)
        k += 1; t += beat
def score_cool(t0, t1):
    beat = 60 / 84; chords = [[50, 57, 60, 65], [55, 59, 62, 65], [50, 57, 60, 64], [55, 59, 62, 65]]  # Dm9-ish / G7
    bar = 0; t = t0
    while t < t1 - 0.1:
        ch = chords[bar % 4]
        for m in ch: place(music, epiano(mtof(m + 12), beat * 3.6), t, 0.6, 0.1 * (m % 3 - 1))
        place(music, subbass(mtof(ch[0] - 12), beat * 1.6), t, 0.9); place(music, subbass(mtof(ch[0] - 12), beat * 0.8), t + beat * 2.5, 0.7)
        for b in range(4):
            if b in (0, 2) or (b == 3 and bar % 2): place(music, kick(), t + b * beat + (0.36 * beat if b == 3 else 0), 0.75)
            if b in (1, 3): place(music, snare(0.7), t + b * beat, 0.42)
        bar += 1; t += beat * 4
def score_tense(t0, t1, root=38):
    d = t1 - t0; t = tt(d); y = np.zeros(len(t))
    for m, g in ((root, 1.0), (root + 7, 0.5), (root + 13, 0.25)):
        f = mtof(m); y += g * lp(signal.sawtooth(2 * np.pi * f * t + np.sin(2 * np.pi * 0.3 * t)), 500)
    y *= np.minimum(1, t / 0.8) * np.minimum(1, (d - t) / 0.4) * (0.75 + 0.25 * np.sin(2 * np.pi * 0.5 * t))
    place(music, y * 0.22, t0)
def score_frantic(t0, t1):
    beat = 60 / 176; bass = [48, 55, 52, 55, 50, 57, 53, 57]; mel = [72, 74, 76, 79, 77, 76, 74, 72, 71, 72, 74, 76, 74, 72, 71, 67]
    k = 0; t = t0
    while t < t1 - 0.05:
        place(music, pizz(mtof(bass[k % 8] - 12), 0.3), t, 0.85, -0.1)
        place(music, marimba(mtof(mel[k % 16]), 0.3), t, 0.4, 0.25)
        if k % 2: place(music, pizz(mtof(mel[(k + 4) % 16] - 12), 0.25, 1.4), t + beat * 0.5, 0.35, -0.25)
        k += 1; t += beat
def score_happy(t0, t1, root=62):
    beat = 60 / 132; t = t0; k = 0
    prog = [[root, root + 4, root + 7], [root + 5, root + 9, root + 12], [root + 7, root + 11, root + 14], [root, root + 4, root + 7]]
    while t < t1 - 0.05:
        ch = prog[(k // 2) % 4]
        place(music, pizz(mtof(ch[0] - 12), 0.35), t, 0.8)
        for i, m in enumerate(ch): place(music, marimba(mtof(m + 12), 0.4), t + beat * 0.5 + i * 0.03, 0.35, 0.2)
        k += 1; t += beat

for sec in CFG['sections']:
    kind, a, b = sec['kind'], sec['start'], sec['end']
    if kind == 'sneaky': score_sneaky(a, b)
    elif kind == 'cool': score_cool(a, b)
    elif kind == 'happy': score_happy(a, b, sec.get('root', 62))
    elif kind == 'tense': score_tense(a, b, sec.get('root', 38))
    elif kind == 'frantic': score_frantic(a, b)
    elif kind == 'choir': place(music, choir(sec.get('notes', [62, 66, 69, 74]), b - a), a, sec.get('gain', 1.0))
# section edges: short fades so cuts between styles don't click
for sec in CFG['sections']:
    if sec['kind'] in ('sneaky', 'cool', 'happy', 'frantic'):
        b = int(sec['end'] * SR); w = int(0.05 * SR)
        if b < N: music[max(0, b - w):b] *= np.linspace(1, 0.0, min(w, b))[:, None]
for d in CFG.get('ducks', []):  # [start, end, level] — let a big gag breathe
    a, b, lv = int(d[0] * SR), int(d[1] * SR), d[2]
    music[a:b] *= lv
for c in CFG['cues']:
    y = FX[c['name']]()
    place(fx, y, c['t'], c.get('gain', 1.0), c.get('pan', 0.0))

mix = music * 0.55 + fx * 0.9
# gentle bus: soft-knee tanh + loudness target
mix = np.tanh(mix * 1.1) / 1.1
pk = np.max(np.abs(mix)); mix *= 0.89 / max(pk, 1e-6)  # peak -1 dBFS; loudness is set after with ffmpeg loudnorm
import soundfile as sf
os.makedirs(os.path.join(ROOT, 'data'), exist_ok=True)
OUTP = f'data/mix_{FILM}.wav' if FILM else 'data/mix.wav'
sf.write(os.path.join(ROOT, OUTP), mix.astype(np.float32), SR, subtype='PCM_24')
sf.write(os.path.join(ROOT, 'data/music.wav'), (music * 0.55).astype(np.float32), SR, subtype='PCM_24')
sf.write(os.path.join(ROOT, 'data/fx.wav'), (fx * 0.9).astype(np.float32), SR, subtype='PCM_24')
print(OUTP, f'{DUR:.2f}s written (peak-normalised)')
