// Props (style/06-props.png): pizza box with one slice, the slice (with a lick shine), a whole pizza, sparkles.
import * as THREE from 'three';
import { plastic, rbox } from '../chars/avatar.js';
import { canvas, tex } from '../core/tex.js';
import { hash } from '../core/util.js';

function cheeseTex(slice = true) {
  const c = canvas(512, 512), x = c.getContext('2d');
  x.fillStyle = '#ffcf3f'; x.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 90; i++) { x.fillStyle = `rgba(255,${180 + hash(i) * 50},60,0.5)`; x.beginPath(); x.ellipse(hash(i + 3) * 512, hash(i + 7) * 512, 14 + hash(i) * 22, 8 + hash(i + 1) * 12, hash(i + 2) * 3, 0, 7); x.fill(); }
  for (let i = 0; i < 40; i++) { x.fillStyle = 'rgba(214,120,40,0.35)'; x.beginPath(); x.arc(hash(i + 50) * 512, hash(i + 60) * 512, 4 + hash(i) * 6, 0, 7); x.fill(); }
  const pep = slice ? [[0.5, 0.35], [0.36, 0.62], [0.64, 0.62], [0.5, 0.82]] : Array.from({ length: 18 }, (_, i) => { const a = i * 2.4, r = 0.12 + (i % 5) * 0.075; return [0.5 + Math.cos(a) * r, 0.5 + Math.sin(a) * r]; });
  for (const [u, v] of pep) {
    x.fillStyle = '#d93a2b'; x.beginPath(); x.arc(u * 512, v * 512, slice ? 46 : 30, 0, 7); x.fill();
    x.fillStyle = 'rgba(120,20,10,0.35)'; for (let k = 0; k < 5; k++) { x.beginPath(); x.arc(u * 512 + (hash(k + u * 9) - 0.5) * 50, v * 512 + (hash(k + v * 7) - 0.5) * 50, 4, 0, 7); x.fill(); }
    x.fillStyle = 'rgba(255,255,255,0.35)'; x.beginPath(); x.arc(u * 512 - 10, v * 512 - 12, 9, 0, 7); x.fill();
  }
  if (!slice) { x.strokeStyle = 'rgba(160,90,20,0.45)'; x.lineWidth = 6; for (let i = 0; i < 4; i++) { const a = i * Math.PI / 4; x.beginPath(); x.moveTo(256 - Math.cos(a) * 256, 256 - Math.sin(a) * 256); x.lineTo(256 + Math.cos(a) * 256, 256 + Math.sin(a) * 256); x.stroke(); } }
  return c;
}

/** one slice: tip at +z (pointing away from the crust), crust at -z. length ~1.1 studs */
export function makeSlice() {
  const g = new THREE.Group();
  const L = 1.15, Wd = 0.95;
  const shp = new THREE.Shape(); shp.moveTo(-Wd / 2, 0); shp.lineTo(Wd / 2, 0); shp.lineTo(0, L); shp.closePath();
  const geo = new THREE.ExtrudeGeometry(shp, { depth: 0.1, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.03, bevelSegments: 2 });
  geo.rotateX(Math.PI / 2); geo.translate(0, 0.13, 0); // lay flat: shape y → +z, extrude down
  // planar UVs from top
  const p = geo.attributes.position, uv = geo.attributes.uv; for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / Wd + 0.5, p.getZ(i) / L);
  const cheese = new THREE.MeshPhysicalMaterial({ map: tex(cheeseTex(true)), roughness: 0.35, clearcoat: 0.6, clearcoatRoughness: 0.25 });
  const top = new THREE.Mesh(geo, cheese); g.add(top);
  const crust = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, Wd * 1.08, 16), plastic(0xd9892f, { roughness: 0.6 }));
  crust.rotation.z = Math.PI / 2; crust.position.set(0, 0.1, -0.02); g.add(crust);
  // the lick: a wet shine streak (hidden until licked)
  const shine = new THREE.Mesh(new THREE.PlaneGeometry(0.28, 0.75), new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.0, roughness: 0.02, clearcoat: 1, emissive: 0xffffff, emissiveIntensity: 0.25 }));
  shine.rotation.x = -Math.PI / 2; shine.position.set(0.04, 0.2, 0.5); g.add(shine);
  g.traverse((o) => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
  shine.castShadow = false;
  g.userData.shine = shine;
  return g;
}

/** open pizza box (lid hinged at the back, red check band), base 2.5 x 2.5 */
export function makePizzaBox() {
  const g = new THREE.Group();
  const card = plastic(0xc89462, { roughness: 0.85, clearcoat: 0 }), inner = plastic(0xe6c9a0, { roughness: 0.9, clearcoat: 0 });
  const S = 2.5, H = 0.3;
  const base = new THREE.Mesh(new THREE.BoxGeometry(S, 0.05, S), inner); base.position.y = 0.03; g.add(base);
  const check = (() => { const c = canvas(512, 64), x = c.getContext('2d'); x.fillStyle = '#c89462'; x.fillRect(0, 0, 512, 64); for (let i = 0; i < 16; i++) for (let j = 0; j < 2; j++) if ((i + j) % 2 === 0) { x.fillStyle = '#d6322b'; x.fillRect(i * 32, 8 + j * 24, 32, 24); } return plastic(0xffffff, { map: tex(c), roughness: 0.85, clearcoat: 0 }); })();
  for (const [x, z, ry] of [[0, S / 2, 0], [0, -S / 2, 0], [S / 2, 0, Math.PI / 2], [-S / 2, 0, Math.PI / 2]]) { const w = new THREE.Mesh(new THREE.BoxGeometry(S, H, 0.05), [card, card, card, card, check, check]); w.position.set(x, H / 2, z); w.rotation.y = ry; g.add(w); }
  const lidPivot = new THREE.Group(); lidPivot.position.set(0, H, -S / 2); g.add(lidPivot);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(S, 0.05, S), [card, card, card, inner, card, card]); lid.position.z = S / 2; lidPivot.add(lid);
  lidPivot.rotation.x = -2.92; g.userData.lid = lidPivot;
  for (let i = 0; i < 10; i++) { const cr = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 4), plastic(0xd9892f)); cr.position.set((hash(i) - 0.5) * 1.8, 0.07, (hash(i + 5) - 0.5) * 1.8); g.add(cr); }
  g.traverse((o) => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
  return g;
}

export function makeWholePizza(r = 1.25) {
  const g = new THREE.Group();
  const top = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 0.12, 48), [plastic(0xd9892f), new THREE.MeshPhysicalMaterial({ map: tex(cheeseTex(false)), roughness: 0.35, clearcoat: 0.6 }), plastic(0xd9892f)]);
  top.position.y = 0.08; g.add(top);
  const crust = new THREE.Mesh(new THREE.TorusGeometry(r, 0.13, 12, 64), plastic(0xd9892f, { roughness: 0.6 })); crust.rotation.x = Math.PI / 2; crust.position.y = 0.14; g.add(crust);
  const tray = new THREE.Mesh(new THREE.CylinderGeometry(r + 0.3, r + 0.3, 0.05, 48), new THREE.MeshStandardMaterial({ color: 0x9ea3aa, metalness: 0.8, roughness: 0.35 })); g.add(tray);
  g.traverse((o) => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });
  return g;
}

/** 4-point twinkle sprites (for the "glorious slice" insert) */
export function makeSparkles(n = 6) {
  const c = canvas(128, 128), x = c.getContext('2d');
  const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,250,200,0.6)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = gr; x.fillRect(0, 0, 128, 128);
  x.fillStyle = '#fff'; x.beginPath(); x.moveTo(64, 0); x.lineTo(70, 58); x.lineTo(128, 64); x.lineTo(70, 70); x.lineTo(64, 128); x.lineTo(58, 70); x.lineTo(0, 64); x.lineTo(58, 58); x.closePath(); x.fill();
  const t = new THREE.CanvasTexture(c);
  const g = new THREE.Group();
  for (let i = 0; i < n; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false, toneMapped: false })); g.add(s); }
  g.userData.update = (time, on, spread = 0.8) => g.children.forEach((s, i) => {
    const ph = (time * 1.6 + i * 0.37) % 1; const a = Math.sin(ph * Math.PI);
    s.position.set((hash(i * 3.1) - 0.5) * spread * 1.6, 0.25 + hash(i * 5.7) * spread * 0.6, (hash(i * 7.3) - 0.5) * spread);
    s.scale.setScalar(0.32 * a * on); s.material.opacity = a * on;
  });
  return g;
}
