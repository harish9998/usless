// 2D layer over the render: the "WHEN ..." title (from frame 1), speaker tag + line, comic words, like-heart ending.
import { clamp, E } from './core/util.js';

const NAVY = '#1b1f3b', RED = '#ff2d2d';
// caption look of the winning Roblox shorts: clean heavy sans, white, thin dark edge + soft drop shadow
const FONT = '800 SIZEpx "Montserrat", "Arial Black", sans-serif';
const font = (size) => FONT.replace('SIZE', size);

function wrap(ctx, text, maxW) {
  const words = text.split(' '), lines = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur); return lines;
}
function outlined(ctx, text, x, y, size, fill = '#fff', stroke = 'rgba(10,10,20,0.85)', sw = 0.07) {
  ctx.font = font(size); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.lineJoin = 'round'; ctx.miterLimit = 2;
  ctx.shadowColor = 'rgba(0,0,0,0.65)'; ctx.shadowBlur = size * 0.18; ctx.shadowOffsetY = size * 0.07;
  ctx.strokeStyle = stroke; ctx.lineWidth = size * sw; ctx.strokeText(text, x, y);
  ctx.shadowColor = 'transparent';
  ctx.fillStyle = fill; ctx.fillText(text, x, y);
}
const pop = (u) => (u <= 0 ? 0 : u >= 1 ? 1 : E.back(u));

/** cap: { title, speaker, line, red, at (time line appeared), word: {text, at, x, y, color, rot} } */
export function drawOverlay(ctx, W, H, t, cap = {}) {
  ctx.save();
  let below = 330;
  if (cap.title) {
    const size = 70; ctx.font = font(size);
    const lines = wrap(ctx, cap.title, W * 0.9);
    lines.forEach((l, i) => outlined(ctx, l, W / 2, 190 + i * size * 1.1, size));
    below = 190 + (lines.length - 1) * size * 1.1 + 120;
  }
  if (cap.speaker || cap.line) {
    const u = pop(clamp((t - (cap.at ?? -9)) / 0.18));
    ctx.save(); ctx.translate(W / 2, below); ctx.scale(u, u);
    if (cap.speaker) outlined(ctx, cap.speaker, 0, 0, 58);
    if (cap.line) {
      const size = 70; ctx.font = font(size);
      wrap(ctx, cap.line, W * 0.84).forEach((l, i) => outlined(ctx, l, 0, (cap.speaker ? 84 : 0) + i * size * 1.1, size, cap.red ? RED : '#ffffff'));
    }
    ctx.restore();
  }
  if (cap.timer != null) drawTimer(ctx, W, H, t, cap.timer, cap.timerAt ?? -9);
  if (cap.ff) drawFF(ctx, W, H, t, cap.ff);
  if (cap.word) {
    const w = cap.word, u = clamp((t - w.at) / 0.12), fade = 1 - clamp((t - w.at - (w.dur ?? 0.7)) / 0.15);
    if (u > 0 && fade > 0) {
      ctx.save(); ctx.globalAlpha = fade; ctx.translate(w.x * W, w.y * H); ctx.rotate((w.rot ?? -8) * Math.PI / 180); const s = 0.5 + 0.7 * E.back(u); ctx.scale(s, s);
      burst(ctx, w.r ?? 190, w.burst ?? '#ffe14a');
      ctx.save(); ctx.font = font(w.size ?? 104); ctx.textAlign = 'center'; ctx.lineJoin = 'round'; ctx.strokeStyle = NAVY; ctx.lineWidth = (w.size ?? 104) * 0.16; ctx.strokeText(w.text, 0, 34); ctx.fillStyle = w.color ?? '#ffffff'; ctx.fillText(w.text, 0, 34); ctx.restore();
      ctx.restore();
    }
  }
  ctx.restore();
}
// red seven-segment countdown in a black clock body (nod to the 3:00 alarm clock of the 3 AM short)
const SEG = { 0: 'abcdef', 1: 'bc', 2: 'abged', 3: 'abgcd', 4: 'fgbc', 5: 'afgcd', 6: 'afgedc', 7: 'abc', 8: 'abcdefg', 9: 'abcdfg' };
function digit(ctx, d, x, y, w, h, on, off) {
  const t = w * 0.2, segs = { a: [x + t, y, w - 2 * t, t], d: [x + t, y + h - t, w - 2 * t, t], g: [x + t, y + h / 2 - t / 2, w - 2 * t, t], f: [x, y + t, t, h / 2 - t * 1.5], b: [x + w - t, y + t, t, h / 2 - t * 1.5], e: [x, y + h / 2 + t / 2, t, h / 2 - t * 1.5], c: [x + w - t, y + h / 2 + t / 2, t, h / 2 - t * 1.5] };
  for (const [k, r] of Object.entries(segs)) { ctx.fillStyle = SEG[d].includes(k) ? on : off; ctx.beginPath(); ctx.roundRect(...r, t * 0.4); ctx.fill(); }
}
function drawTimer(ctx, W, H, t, secs, at) {
  const u = pop(clamp((t - at) / 0.25)); if (u <= 0) return;
  const s = Math.max(0, Math.ceil(secs - 1e-6)), mm = Math.floor(s / 60), ss = s % 60;
  const urgent = s <= 5, blink = urgent && Math.floor(t * 4) % 2 === 0;
  ctx.save(); ctx.translate(W / 2, H * 0.78); ctx.scale(u, u); ctx.rotate(-0.03);
  ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 30; ctx.fillStyle = '#121214'; ctx.beginPath(); ctx.roundRect(-250, -95, 500, 190, 40); ctx.fill(); ctx.shadowColor = 'transparent';
  ctx.fillStyle = '#1d1d21'; ctx.beginPath(); ctx.roundRect(-226, -72, 452, 144, 26); ctx.fill();
  const on = blink ? '#ff9a9a' : '#ff2a2a', off = 'rgba(255,40,40,0.08)';
  ctx.shadowColor = on; ctx.shadowBlur = 18;
  const dw = 70, dh = 112, y = -dh / 2; const xs = [-200, -116, 18, 102];
  [Math.floor(mm / 10), mm % 10, Math.floor(ss / 10), ss % 10].forEach((d, i) => digit(ctx, d, xs[i], y, dw, dh, on, off));
  ctx.fillStyle = on; ctx.beginPath(); ctx.arc(-14, -22, 9, 0, 7); ctx.arc(-14, 22, 9, 0, 7); ctx.fill();
  ctx.restore();
}
function drawFF(ctx, W, H, t, label) {
  ctx.save(); ctx.translate(W - 70, H * 0.3); ctx.textAlign = 'right';
  const on = Math.floor(t * 3) % 2 === 0;
  ctx.font = font(66); ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 14; ctx.fillStyle = '#ffffff';
  ctx.fillText(typeof label === 'string' ? label : 'x10', 0, 0);
  if (on) { ctx.beginPath(); for (const ox of [-250, -205]) { ctx.moveTo(ox, -50); ctx.lineTo(ox + 40, -25); ctx.lineTo(ox, 0); } ctx.fill(); }
  ctx.restore();
}
function burst(ctx, r, col) {
  ctx.fillStyle = col; ctx.strokeStyle = NAVY; ctx.lineWidth = 10; ctx.beginPath();
  for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2, rr = i % 2 ? r * 0.72 : r; ctx.lineTo(Math.cos(a) * rr * 1.25, Math.sin(a) * rr * 0.85); }
  ctx.closePath(); ctx.fill(); ctx.stroke();
}

/** like-heart ending over the blurred last frame: outline heart → cursor glides in → click → red + count 1 */
export function drawLike(ctx, W, H, lt) {
  const cx = W / 2, cy = H * 0.5, S = 230;
  const appear = E.back(clamp(lt / 0.3));
  const click = 0.95, filled = lt >= click;
  const bump = filled ? 1 + 0.25 * Math.sin(clamp((lt - click) / 0.25) * Math.PI) : 1;
  ctx.save(); ctx.translate(cx, cy); ctx.scale(appear * bump, appear * bump);
  heartPath(ctx, S);
  if (filled) { ctx.fillStyle = '#ff2d3d'; ctx.shadowColor = 'rgba(0,0,0,0.3)'; ctx.shadowBlur = 30; ctx.fill(); ctx.shadowColor = 'transparent'; }
  else { ctx.lineWidth = 26; ctx.strokeStyle = '#ffffff'; ctx.shadowColor = 'rgba(0,0,0,0.3)'; ctx.shadowBlur = 24; ctx.stroke(); ctx.shadowColor = 'transparent'; }
  ctx.restore();
  ctx.font = font(80); ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.lineWidth = 12; ctx.strokeStyle = NAVY;
  const n = filled ? '1' : '0'; ctx.strokeText(n, cx, cy + S * 1.25); ctx.fillText(n, cx, cy + S * 1.25);
  // cursor
  const m = E.io(clamp((lt - 0.25) / 0.6));
  const px = cx + 420 * (1 - m) + 40, py = cy + 520 * (1 - m) + 60;
  const press = lt > click - 0.06 && lt < click + 0.1 ? 0.85 : 1;
  ctx.save(); ctx.translate(px, py); ctx.scale(2.6 * press, 2.6 * press);
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 34); ctx.lineTo(8, 27); ctx.lineTo(14, 40); ctx.lineTo(20, 37); ctx.lineTo(14, 25); ctx.lineTo(24, 25); ctx.closePath();
  ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.2; ctx.strokeStyle = '#111'; ctx.stroke();
  ctx.restore();
  if (lt > click && lt < click + 0.35) { // click ring
    const u = (lt - click) / 0.35; ctx.strokeStyle = `rgba(255,255,255,${1 - u})`; ctx.lineWidth = 8; ctx.beginPath(); ctx.arc(cx + 40, cy + 60, 30 + u * 90, 0, 7); ctx.stroke();
  }
}
function heartPath(ctx, s) {
  ctx.beginPath();
  ctx.moveTo(0, s * 0.85);
  ctx.bezierCurveTo(-s * 1.55, -s * 0.05, -s * 0.75, -s * 1.15, 0, -s * 0.42);
  ctx.bezierCurveTo(s * 0.75, -s * 1.15, s * 1.55, -s * 0.05, 0, s * 0.85);
  ctx.closePath();
}
