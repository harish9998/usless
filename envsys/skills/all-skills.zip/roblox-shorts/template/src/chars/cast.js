// The Block Family (style/01-style-sheet.png, 02/03 model sheets). Outfits are painted canvases on the boxes.
import * as THREE from 'three';
import { Avatar, plastic, fabric, rbox, headGeometry } from './avatar.js';
import { canvas, tex, star, heart, floral, seams } from '../core/tex.js';

const C = { yellow: 0xf5cd30, orange: 0xff8a1f, mint: 0x3ddc97, pink: 0xff6fae, lav: 0xb28dff, navy: 0x1f3a8a, white: 0xf7f7f5 };

// ---- clothing textures ----
function shirtMats(paintFront, paintBack, sideColor, opts = {}) {
  const mk = (paint, w = 512, h = 512) => { const c = canvas(w, h); const x = c.getContext('2d'); paint(x, w, h); return fabric(0xffffff, { map: tex(c), ...opts }); };
  const side = typeof sideColor === 'function' ? mk(sideColor) : fabric(sideColor, opts);
  // BoxGeometry face order: +x, -x, +y, -y, +z (front), -z (back)
  return [side, side, side, side, mk(paintFront), mk(paintBack)];
}
const fill = (col) => (x, w, h) => { x.fillStyle = col; x.fillRect(0, 0, w, h); seams(x, w, h, 0.12); };

function lilBroShirt() {
  return shirtMats((x, w, h) => { fill('#3ddc97')(x, w, h); x.fillStyle = 'rgba(0,0,0,0.08)'; x.fillRect(w * 0.36, 0, w * 0.28, h * 0.06); star(x, w / 2, h * 0.48, w * 0.2); },
    fill('#3ddc97'), 0x3ddc97);
}
function sisHoodie() {
  return shirtMats((x, w, h) => {
    fill('#ff6fae')(x, w, h);
    x.strokeStyle = 'rgba(160,30,80,0.35)'; x.lineWidth = 6; x.beginPath(); x.moveTo(w * 0.2, h * 0.92); x.lineTo(w * 0.8, h * 0.92); x.stroke();
    x.fillStyle = 'rgba(255,255,255,0.9)'; x.fillRect(w * 0.43, 0, 5, h * 0.22); x.fillRect(w * 0.56, 0, 5, h * 0.2);
    heart(x, w / 2, h * 0.47, w * 0.17);
  }, (x, w, h) => { fill('#ff6fae')(x, w, h); x.fillStyle = 'rgba(0,0,0,0.12)'; x.beginPath(); x.ellipse(w / 2, 0, w * 0.32, h * 0.3, 0, 0, Math.PI); x.fill(); }, 0xff6fae);
}
function momCardigan() {
  const fl = floral(512, 512, '#f26b5b', '#ffffff', '#f7c531', 14, 26, 3);
  const front = (x, w, h) => { x.drawImage(fl, 0, 0); x.fillStyle = '#ffffff'; x.fillRect(w * 0.3, 0, w * 0.4, h); x.fillStyle = 'rgba(0,0,0,0.12)'; x.fillRect(w * 0.29, 0, 8, h); x.fillRect(w * 0.7 - 8, 0, 8, h); seams(x, w, h, 0.1); };
  const back = (x, w, h) => { x.drawImage(fl, 0, 0); seams(x, w, h, 0.1); };
  return shirtMats(front, back, back);
}
function dadPolo() {
  return shirtMats((x, w, h) => {
    fill('#2fa84f')(x, w, h);
    x.fillStyle = '#26913f'; x.beginPath(); x.moveTo(w * 0.22, 0); x.lineTo(w * 0.5, h * 0.2); x.lineTo(w * 0.78, 0); x.closePath(); x.fill();
    x.fillStyle = '#ffffff'; x.beginPath(); x.moveTo(w * 0.33, 0); x.lineTo(w * 0.5, h * 0.13); x.lineTo(w * 0.67, 0); x.closePath(); x.fill();
    x.fillStyle = '#2fa84f'; x.fillRect(w * 0.46, h * 0.1, w * 0.08, h * 0.24);
    x.fillStyle = '#f5f5f5'; for (const y of [0.18, 0.28]) { x.beginPath(); x.arc(w * 0.5, h * y, 9, 0, 7); x.fill(); }
    x.strokeStyle = 'rgba(0,0,0,0.25)'; x.lineWidth = 5; x.strokeRect(w * 0.6, h * 0.3, w * 0.17, h * 0.17);
  }, fill('#2fa84f'), 0x2fa84f);
}
function grannyCardigan() {
  const fl = floral(512, 512, '#7b3fc4', '#ffffff', '#ff9ad5', 18, 22, 7);
  const inner = floral(512, 512, '#d7c2fb', '#ffffff', '#c9a6ff', 10, 14, 9);
  const front = (x, w, h) => { x.drawImage(fl, 0, 0); x.drawImage(inner, w * 0.3, 0, w * 0.4, h, w * 0.3, 0, w * 0.4, h); x.fillStyle = '#ffffff'; for (const y of [0.15, 0.32, 0.5]) { x.beginPath(); x.arc(w * 0.5, h * y, 8, 0, 7); x.fill(); } seams(x, w, h, 0.1); };
  const back = (x, w, h) => { x.drawImage(fl, 0, 0); seams(x, w, h, 0.1); };
  return shirtMats(front, back, back);
}
function texMat(paint, w = 256, h = 512) { const c = canvas(w, h); paint(c.getContext('2d'), w, h); return fabric(0xffffff, { map: tex(c) }); }
const jeans = () => texMat((x, w, h) => { x.fillStyle = '#3b7bd0'; x.fillRect(0, 0, w, h); x.strokeStyle = 'rgba(255,220,150,0.5)'; x.lineWidth = 3; x.setLineDash([8, 6]); x.beginPath(); x.moveTo(w * 0.15, 0); x.lineTo(w * 0.15, h); x.stroke(); x.setLineDash([]); x.fillStyle = 'rgba(0,0,0,0.1)'; x.fillRect(0, h * 0.94, w, h * 0.06); });
const navyPants = () => texMat((x, w, h) => { x.fillStyle = '#1f3a8a'; x.fillRect(0, 0, w, h); x.fillStyle = 'rgba(255,255,255,0.06)'; x.fillRect(w * 0.12, 0, 4, h); });
const pjPants = () => { const c = floral(256, 512, '#c9adf5', '#ffffff', '#ff9ad5', 10, 18, 11); return fabric(0xffffff, { map: tex(c) }); };

// ---- accessories ----
function hairMat(color) { return plastic(color, { roughness: 0.42, clearcoat: 0.5, clearcoatRoughness: 0.3 }); }
function puffCluster(mat, r, n = 7, seed = 1) {
  const g = new THREE.Group();
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + seed, rr = r * (0.55 + ((i * 37 + seed * 11) % 7) / 18);
    const m = new THREE.Mesh(new THREE.SphereGeometry(rr, 20, 14), mat);
    m.position.set(Math.cos(a) * r * 0.5, Math.sin(a * 1.7) * r * 0.35, Math.sin(a) * r * 0.5); g.add(m);
  }
  const core = new THREE.Mesh(new THREE.SphereGeometry(r * 0.8, 24, 16), mat); g.add(core);
  return g;
}
/** hair cap for the round heads: rounded crown down to the hairline (above the brows) + a back half-shell to the neck */
function hairCap(av, mat, { line = 0.2, back = 0.95, side = 0.55, thick = 0.12, fringe = 0 } = {}) {
  const { hw, hh, hd } = av.dims, g = new THREE.Group();
  const hl = hh / 2 - hh * line, ch = hh / 2 - hl + thick + 0.1;
  const crown = new THREE.Mesh(headGeometry(hw + thick * 2, ch, hd + thick * 2, 2.35, Math.min(ch * 0.48, 0.3)), mat); crown.position.y = hl + ch / 2; g.add(crown);
  const r = (hw + thick * 2) / 2, bh = hh * back;
  const bk = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.98, bh, 40, 1, false, Math.PI / 2 + 0.35, Math.PI - 0.7), mat); bk.position.set(0, hh / 2 - bh / 2 + thick * 0.4, 0); bk.scale.z = (hd + thick * 2) / (hw + thick * 2); g.add(bk);
  bk.material = mat.clone(); bk.material.side = THREE.DoubleSide;
  if (fringe > 0) { const fr = new THREE.Mesh(rbox(hw * 0.9, hh * fringe, thick * 1.2, 0.07), mat); fr.position.set(0, hl - hh * fringe / 2 + 0.05, hd / 2 + thick * 0.1); g.add(fr); }
  return g;
}
function glasses(shape, color, { w = 0.42, h = 0.34, gap = 0.12, thick = 0.05 } = {}) {
  const g = new THREE.Group(); const mat = plastic(color, { roughness: 0.3, metalness: shape === 'round' ? 0.6 : 0 });
  for (const s of [-1, 1]) {
    let geo;
    if (shape === 'round') geo = new THREE.TorusGeometry(w / 2, thick * 0.6, 10, 40);
    else {
      const o = new THREE.Shape(); const rr = 0.05, W = w, H = h;
      o.moveTo(-W / 2 + rr, -H / 2); o.lineTo(W / 2 - rr, -H / 2); o.quadraticCurveTo(W / 2, -H / 2, W / 2, -H / 2 + rr); o.lineTo(W / 2, H / 2 - rr); o.quadraticCurveTo(W / 2, H / 2, W / 2 - rr, H / 2); o.lineTo(-W / 2 + rr, H / 2); o.quadraticCurveTo(-W / 2, H / 2, -W / 2, H / 2 - rr); o.lineTo(-W / 2, -H / 2 + rr); o.quadraticCurveTo(-W / 2, -H / 2, -W / 2 + rr, -H / 2);
      const i = new THREE.Path(); const t = thick; i.moveTo(-W / 2 + t, -H / 2 + t); i.lineTo(W / 2 - t, -H / 2 + t); i.lineTo(W / 2 - t, H / 2 - t); i.lineTo(-W / 2 + t, H / 2 - t); i.closePath(); o.holes.push(i);
      geo = new THREE.ExtrudeGeometry(o, { depth: 0.04, bevelEnabled: false });
    }
    const m = new THREE.Mesh(geo, mat); m.position.x = s * (w / 2 + gap / 2); g.add(m);
  }
  const br = new THREE.Mesh(new THREE.BoxGeometry(gap + 0.02, 0.035, 0.035), mat); br.position.y = shape === 'round' ? 0.03 : h * 0.25; g.add(br);
  return g;
}

export const DEFS = {
  lilbro: {
    id: 'lilbro', skin: C.yellow, head: [1.3, 1.28, 1.24], torso: [1.75, 1.55, 0.95], arm: [0.82, 1.55, 0.84], leg: [0.86, 1.35, 0.9],
    shirt: { mats: lilBroShirt() }, sleeve: { frac: 0.32, mat: fabric(0x3ddc97) },
    legs: [{ frac: 1.0, mat: navyPants() }], shoe: { color: C.white, h: 0.3, len: 0.18 },
    face: { iris: '#2f63e0' },
    acc(av) {
      const { hw, hh, hd } = av.dims; const mat = plastic(C.orange, { roughness: 0.5 });
      const cap = new THREE.Group();
      const crown = new THREE.Mesh(headGeometry(hw * 1.12, 0.62, hd * 1.12, 2.35, 0.28), mat); crown.position.y = hh / 2 + 0.1; cap.add(crown);
      const band = new THREE.Mesh(new THREE.CylinderGeometry(hw * 0.565, hw * 0.565, 0.14, 40, 1, true), plastic(0xb8c0cc, { metalness: 0.7, roughness: 0.3 })); band.scale.z = hd / hw; band.position.y = hh / 2 - 0.16; cap.add(band); band.material.side = THREE.DoubleSide;
      const brim = new THREE.Mesh(rbox(hw * 0.8, 0.07, 0.62, 0.03), mat); brim.position.set(0, hh / 2 - 0.12, -hd / 2 - 0.24); brim.rotation.x = 0.12; cap.add(brim);
      
      const btn = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 8), mat); btn.position.y = hh / 2 + 0.33; cap.add(btn);
      av.cap = cap; av.headPivot.add(cap); cap.position.y = hh / 2;
      // sunglasses (hidden until used)
      const sg = new THREE.Group(); const sm = plastic(0x0d0d0f, { roughness: 0.15, clearcoat: 1 });
      for (const s of [-1, 1]) { const l = new THREE.Mesh(rbox(0.52, 0.32, 0.06, 0.06), sm); l.position.x = s * 0.31; sg.add(l); }
      const bar = new THREE.Mesh(rbox(1.22, 0.07, 0.06, 0.02), sm); bar.position.y = 0.12; sg.add(bar);
      sg.position.set(0, hh / 2 + 0.07, hd / 2 + 0.05); av.headPivot.add(sg); av.shades = sg; sg.visible = false;
    },
  },
  lilsis: {
    id: 'lilsis', skin: 0xf0b98a, head: [1.24, 1.22, 1.18], torso: [1.45, 1.3, 0.86], arm: [0.7, 1.3, 0.72], leg: [0.72, 1.1, 0.78],
    shirt: { mats: sisHoodie() }, sleeve: { frac: 0.84, mat: fabric(0xff6fae) },
    legs: [{ frac: 1.0, mat: fabric(C.lav) }], shoe: { color: 0xffffff, h: 0.26, len: 0.16 },
    face: { lashes: true, blush: true, iris: '#7a4a22' },
    acc(av) {
      const { hw, hh } = av.dims, hm = hairMat(0x7a4426);
      const cap = hairCap(av, hm, { line: 0.2, back: 0.9, side: 0.55 }); av.headPivot.add(cap); cap.position.y = hh / 2;
      const sc = plastic(0xa06cf0);
      for (const s of [-1, 1]) {
        const puff = puffCluster(hm, 0.36, 7, s + 3); puff.position.set(s * (hw / 2 + 0.28), hh + 0.12, -0.05); av.headPivot.add(puff);
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.08, 10, 24), sc); ring.position.set(s * (hw / 2 + 0.06), hh + 0.02, -0.05); ring.rotation.y = Math.PI / 2; ring.rotation.x = 0.4 * s; av.headPivot.add(ring);
      }
    },
  },
  mom: {
    id: 'mom', skin: 0xf2c49b, head: [1.24, 1.24, 1.18], torso: [1.8, 1.8, 0.92], arm: [0.78, 1.8, 0.8], leg: [0.86, 1.95, 0.92],
    shirt: { mats: momCardigan() }, sleeve: { frac: 0.9, mat: fabric(0xffffff, { map: tex(floral(256, 512, '#f26b5b', '#ffffff', '#f7c531', 9, 26, 5)) }) },
    legs: [{ frac: 1.0, mat: jeans() }], shoe: { color: 0xffffff, h: 0.3, len: 0.18 },
    face: { lashes: true, blush: true, lips: true, iris: '#5b3a20' },
    acc(av) {
      const { hw, hh, hd } = av.dims, hm = hairMat(0x6b3a22);
      const cap = hairCap(av, hm, { line: 0.17, back: 1.15, side: 0.8 }); av.headPivot.add(cap); cap.position.y = hh / 2;
      const bun = puffCluster(hm, 0.42, 8, 2); bun.position.set(0, hh + 0.42, -0.12); av.headPivot.add(bun);
      for (const s of [-1, 1]) { // long side bangs framing the face
        const b = new THREE.Mesh(rbox(0.15, hh * 0.95, 0.2, 0.07), hm); b.position.set(s * (hw / 2 + 0.02), hh * 0.5, hd / 2 - 0.06); b.rotation.z = s * 0.05; av.headPivot.add(b);
      }
    },
  },
  dad: {
    id: 'dad', skin: C.yellow, head: [1.32, 1.3, 1.26], torso: [2.25, 1.95, 1.05], arm: [0.95, 1.95, 0.95], leg: [1.05, 1.9, 1.0],
    shirt: { mats: dadPolo() }, sleeve: { frac: 0.36, mat: fabric(0x2fa84f) },
    legs: [{ frac: 0.46, mat: fabric(0xd2b48c), grow: 1.04 }, { frac: 0.3, color: C.yellow }, { frac: 0.24, color: 0xffffff }],
    shoe: { color: 0x6b3d1f, h: 0.16, len: 0.22, extra(piv, av) { const st = new THREE.Mesh(rbox(av.dims.lw * 1.08, 0.14, 0.22, 0.05), plastic(0x6b3d1f)); st.position.set(0, -av.dims.lh + 0.28, 0.25); piv.add(st); } },
    face: { beard: true, iris: '#4a2e18' },
    acc(av) {
      const { hh, hd } = av.dims;
      const g = glasses('square', 0x111111, { w: 0.46, h: 0.36, gap: 0.04 }); g.position.set(0, hh / 2 + 0.07, hd / 2 + 0.03); av.headPivot.add(g);
    },
  },
  granny: {
    id: 'granny', skin: 0xf3cba8, head: [1.22, 1.2, 1.16], torso: [1.8, 1.6, 0.96], arm: [0.78, 1.6, 0.8], leg: [0.84, 1.62, 0.92],
    shirt: { mats: grannyCardigan() }, sleeve: { frac: 0.88, mat: fabric(0xffffff, { map: tex(floral(256, 512, '#7b3fc4', '#ffffff', '#ff9ad5', 9, 20, 6)) }) },
    legs: [{ frac: 1.0, mat: pjPants() }], shoe: { color: 0xffa6c9, h: 0.34, len: 0.26, extra(piv, av) { const m = plastic(0xffc0da, { roughness: 0.9, clearcoat: 0 }); for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 8), m); e.position.set(s * 0.2, -av.dims.lh + 0.38, 0.42); piv.add(e); } } },
    face: { lashes: true, blush: true, iris: '#5d7fa8', brow: '#b9b4bd' }, lean: 6,
    acc(av) {
      const { hw, hh, hd } = av.dims, hm = hairMat(0xf2f0f5);
      const cap = hairCap(av, hm, { line: 0.15, back: 0.85, side: 0.5, thick: 0.1 }); av.headPivot.add(cap); cap.position.y = hh / 2;
      for (let i = 0; i < 16; i++) { // curls
        const a = (i / 16) * Math.PI * 2; const r = 0.17 + (i % 3) * 0.03;
        const m = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 10), hm); m.position.set(Math.cos(a) * hw * 0.5, hh + 0.05 + (i % 2) * 0.08, Math.sin(a) * hd * 0.5 - 0.05); av.headPivot.add(m);
      }
      const bun = puffCluster(hm, 0.36, 9, 5); bun.position.set(0, hh + 0.4, -0.08); av.headPivot.add(bun);
      const g = glasses('round', 0xd4a531, { w: 0.42, gap: 0.04, thick: 0.05 }); g.position.set(0, hh / 2 + 0.06, hd / 2 + 0.04); av.headPivot.add(g);
      // cane in the right hand
      const cm = plastic(0x7a4a26, { roughness: 0.5 });
      const cane = new THREE.Group();
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 3.3, 14), cm); shaft.position.y = -1.6; cane.add(shaft);
      const hook = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.07, 10, 24, Math.PI), cm); hook.position.set(0.22, 0.02, 0); cane.add(hook);
      av.hand('R').add(cane); av.cane = cane; cane.position.set(0, 0.0, 0.2);
    },
  },
};

export function buildCast() {
  const cast = {};
  for (const [k, d] of Object.entries(DEFS)) { d.skinCss = '#' + new THREE.Color(d.skin).getHexString(); cast[k] = new Avatar(d); }
  return cast;
}
