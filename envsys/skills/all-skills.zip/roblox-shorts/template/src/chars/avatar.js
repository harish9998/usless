// Roblox-style avatar: rounded head with a drawn face decal, boxy torso, block arms + legs on pivots, accessories.
// Units are studs. Root sits at the feet, avatar faces +Z.
import * as THREE from 'three';
import { RoundedBoxGeometry } from '../../vendor/addons/geometries/RoundedBoxGeometry.js';
import { drawFace, faceKey } from './face.js';

export function plastic(color, extra = {}) {
  return new THREE.MeshPhysicalMaterial({ color, roughness: 0.3, metalness: 0, clearcoat: 0.8, clearcoatRoughness: 0.14, ...extra });
}
let _fabricBump = null;
function fabricBump() {
  if (_fabricBump) return _fabricBump;
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
  x.fillStyle = '#808080'; x.fillRect(0, 0, 256, 256);
  let seed = 12345; const R = () => ((seed = (seed * 16807) % 2147483647) / 2147483647); // deterministic: every render worker must match
  for (let i = 0; i < 2600; i++) { const v = 100 + Math.floor(R() * 60); x.fillStyle = `rgb(${v},${v},${v})`; x.fillRect(R() * 256, R() * 256, 2, 5); }
  for (let i = 0; i < 9; i++) { x.strokeStyle = 'rgba(40,40,40,0.35)'; x.lineWidth = 3; x.beginPath(); const y = R() * 256; x.moveTo(0, y); x.bezierCurveTo(80, y + 20, 170, y - 20, 256, y + 6); x.stroke(); }
  _fabricBump = new THREE.CanvasTexture(c); _fabricBump.wrapS = _fabricBump.wrapT = THREE.RepeatWrapping; _fabricBump.repeat.set(2, 2);
  return _fabricBump;
}
/** cloth: soft sheen, folds in the bump map (layered-clothing look) */
export function fabric(color, extra = {}) {
  return new THREE.MeshPhysicalMaterial({ color, roughness: 0.78, metalness: 0, sheen: 0.6, sheenRoughness: 0.55, sheenColor: new THREE.Color(0xffffff), bumpMap: fabricBump(), bumpScale: 0.6, ...extra });
}
export function rbox(w, h, d, r = 0.07, seg = 3) { return new RoundedBoxGeometry(w, h, d, seg, Math.min(r, w / 2, h / 2, d / 2)); }

/** squircle-section head with rounded top/bottom (Roblox classic head feel) */
export function headGeometry(w, h, d, n = 5, bevel = 0.22, segU = 64, ringsB = 8) {
  const prof = []; // [scale, y]
  const hh = h / 2;
  for (let i = 0; i <= ringsB; i++) { const a = (i / ringsB) * Math.PI / 2; prof.push([1 - (bevel / (w / 2)) * (1 - Math.sin(a)), -hh + bevel * (1 - Math.cos(a))]); }
  for (let i = 0; i <= ringsB; i++) { const a = (i / ringsB) * Math.PI / 2; prof.push([1 - (bevel / (w / 2)) * (1 - Math.cos(a)), hh - bevel + bevel * Math.sin(a)]); }
  const pos = [], uv = [], idx = [];
  const sq = (t) => [Math.sign(Math.cos(t)) * Math.abs(Math.cos(t)) ** (2 / n), Math.sign(Math.sin(t)) * Math.abs(Math.sin(t)) ** (2 / n)];
  // bottom cap centre
  pos.push(0, -hh, 0); uv.push(0.5, 0);
  for (let r = 0; r < prof.length; r++) {
    const [s, y] = prof[r];
    for (let u = 0; u <= segU; u++) { const t = (u / segU) * Math.PI * 2; const [cx, cz] = sq(t); pos.push(cx * w / 2 * s, y, cz * d / 2 * s); uv.push(u / segU, r / (prof.length - 1)); }
  }
  pos.push(0, hh, 0); uv.push(0.5, 1);
  const ring = (r) => 1 + r * (segU + 1);
  for (let u = 0; u < segU; u++) idx.push(0, ring(0) + u, ring(0) + u + 1);
  for (let r = 0; r < prof.length - 1; r++) for (let u = 0; u < segU; u++) {
    const a = ring(r) + u, b = ring(r) + u + 1, c = ring(r + 1) + u, e = ring(r + 1) + u + 1;
    idx.push(a, e, b, a, c, e);
  }
  const top = pos.length / 3 - 1, lr = ring(prof.length - 1);
  for (let u = 0; u < segU; u++) idx.push(top, lr + u + 1, lr + u);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}
/** front patch of the head surface, pushed out a hair, with planar UVs for the face decal */
function faceShellGeometry(w, h, d, n, bevel) {
  const base = headGeometry(w * 1.004, h * 1.004, d * 1.004, n, bevel, 96, 10);
  const p = base.attributes.position, nrm = base.attributes.normal, idx = base.index.array;
  const keep = [], map = new Map(), pos = [], uv = [], nor = [];
  const ok = (i) => p.getZ(i) > d * 0.12;
  for (let t = 0; t < idx.length; t += 3) {
    const a = idx[t], b = idx[t + 1], c = idx[t + 2];
    if (!(ok(a) && ok(b) && ok(c))) continue;
    for (const v of [a, b, c]) {
      if (!map.has(v)) { map.set(v, pos.length / 3); pos.push(p.getX(v), p.getY(v), p.getZ(v)); nor.push(nrm.getX(v), nrm.getY(v), nrm.getZ(v)); uv.push(p.getX(v) / w + 0.5, p.getY(v) / h + 0.5); }
      keep.push(map.get(v));
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(keep);
  return g;
}

const D = Math.PI / 180;
export class Avatar {
  /** def: { id, skin, head:[w,h,d], torso:[w,h,d], arm:[w,h,d], leg:[w,h,d], shirt:{front,back,side,top,color}, sleeve:{frac,color,map},
   *        legs:[{frac,color,map}], shoe:{color,h,len,map}, face:{lashes,blush,beard,lips}, acc(av) } */
  constructor(def) {
    this.def = def; this.id = def.id;
    const root = this.root = new THREE.Group(); root.name = def.id;
    const [tw, th, td] = def.torso, [aw, ah, ad] = def.arm, [lw, lh, ld] = def.leg, [hw, hhh, hd] = def.head;
    this.dims = { tw, th, td, aw, ah, ad, lw, lh, ld, hw, hh: hhh, hd };
    this.hips = new THREE.Group(); this.hips.position.y = lh; root.add(this.hips);
    // torso
    const tm = def.shirt.mats || plastic(def.shirt.color);
    this.torso = new THREE.Mesh(rbox(tw, th, td, 0.08), tm); this.torso.position.y = th / 2; this.hips.add(this.torso);
    // head
    this.neck = new THREE.Group(); this.neck.position.y = th + 0.02; this.hips.add(this.neck);
    this.headPivot = new THREE.Group(); this.neck.add(this.headPivot);
    const n = def.headN ?? 2.35, bev = def.headBevel ?? 0.2;
    this.skinMat = plastic(def.skin);
    this.head = new THREE.Mesh(headGeometry(hw, hhh, hd, n, bev), this.skinMat); this.head.position.y = hhh / 2; this.headPivot.add(this.head);
    this.faceCanvas = document.createElement('canvas'); this.faceCanvas.width = this.faceCanvas.height = 512;
    this.faceTex = new THREE.CanvasTexture(this.faceCanvas); this.faceTex.colorSpace = THREE.SRGBColorSpace; this.faceTex.anisotropy = 8;
    this.faceMat = new THREE.MeshStandardMaterial({ map: this.faceTex, transparent: true, alphaTest: 0.02, roughness: 0.75, envMapIntensity: 0.2, polygonOffset: true, polygonOffsetFactor: -2, depthWrite: false });
    this.faceMesh = new THREE.Mesh(faceShellGeometry(hw, hhh, hd, n, bev), this.faceMat); this.faceMesh.renderOrder = 2; this.head.add(this.faceMesh);
    this._faceKey = '';
    // arms (pivot at shoulder: top-centre of the arm)
    this.arms = {};
    for (const s of ['L', 'R']) {
      const sx = s === 'L' ? 1 : -1; // avatar's left is +x (it faces +z)
      const piv = new THREE.Group(); piv.position.set(sx * (tw / 2 + aw / 2 + 0.01), th - aw / 2, 0); this.hips.add(piv);
      const sf = def.sleeve.frac;
      const sleeve = new THREE.Mesh(rbox(aw * 1.02, ah * sf, ad * 1.02, 0.07), def.sleeve.mat || plastic(def.sleeve.color));
      sleeve.position.y = aw / 2 - (ah * sf) / 2; piv.add(sleeve);
      if (sf < 0.999) { const sk = new THREE.Mesh(rbox(aw, ah * (1 - sf) + 0.04, ad, 0.07), this.skinMat); sk.position.y = aw / 2 - ah * sf - (ah * (1 - sf)) / 2 + 0.02; piv.add(sk); }
      const hand = new THREE.Group(); hand.position.y = aw / 2 - ah + 0.12; piv.add(hand);
      this.arms[s] = { piv, hand };
    }
    // legs (pivot at hip)
    this.legs = {};
    for (const s of ['L', 'R']) {
      const sx = s === 'L' ? 1 : -1;
      const piv = new THREE.Group(); piv.position.set(sx * (lw / 2 + 0.005), 0, 0); this.hips.add(piv);
      let y = 0;
      for (const seg of def.legs) {
        const hseg = lh * seg.frac;
        const m = new THREE.Mesh(rbox(lw * (seg.grow ?? 1), hseg + 0.02, ld * (seg.grow ?? 1), seg.r ?? 0.07), seg.mat || plastic(seg.color));
        m.position.y = -y - hseg / 2; piv.add(m); y += hseg;
      }
      const sh = def.shoe;
      const shoe = new THREE.Mesh(rbox(lw * 1.06, sh.h, ld * 1.0 + sh.len, 0.09), sh.mat || plastic(sh.color));
      shoe.position.set(0, -lh + sh.h / 2, sh.len / 2); piv.add(shoe);
      if (sh.extra) sh.extra(piv, this);
      this.legs[s] = { piv };
    }
    root.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    this.faceMesh.castShadow = false;
    if (def.acc) def.acc(this);
    root.traverse((o) => { if (o.isMesh && o !== this.faceMesh) { o.castShadow = true; o.receiveShadow = true; } });
    this.pose({});
  }
  /** attach a mesh to the head (head-centre coordinates) */
  onHead(obj) { obj.position.y += this.dims.hh / 2; this.headPivot.add(obj); return obj; }
  hand(s = 'R') { return this.arms[s].hand; }
  /** world height of the top of the head */
  get height() { return this.dims.lh + this.dims.th + this.dims.hh; }

  pose(p) {
    const r = this.root, def = this.def;
    r.visible = p.visible ?? true;
    r.position.set(p.x ?? 0, p.y ?? 0, p.z ?? 0);
    r.rotation.set(0, (p.ry ?? 0) * D, 0);
    const sq = p.squash ?? 0;
    r.scale.set(1 + sq * 0.5, 1 - sq, 1 + sq * 0.5);
    this.hips.position.y = this.dims.lh + (p.hop ?? 0);
    this.hips.rotation.set((p.lean ?? def.lean ?? 0) * D, (p.twist ?? 0) * D, (p.tilt ?? 0) * D);
    const [hx, hy, hz] = p.head || [0, 0, 0];
    this.headPivot.rotation.set(hx * D, hy * D, hz * D, 'YXZ');
    for (const s of ['L', 'R']) {
      const a = p['arm' + s] || [0, 0, 0]; const sgn = s === 'L' ? 1 : -1;
      // rx: + swings the arm forward/up; rz: + raises it out to the side; ry: twist
      this.arms[s].piv.rotation.set(-a[0] * D, (a[2] ?? 0) * D * sgn, a[1] * D * sgn, 'XZY');
      this.arms[s].piv.scale.y = p['stretch' + s] ?? 1;
      const l = p['leg' + s] ?? 0; this.legs[s].piv.rotation.set(-l * D, 0, 0);
    }
    const f = { expr: 'neutral', blink: 0, talk: 0, look: null, ...(p.face || {}) };
    const key = faceKey(f);
    if (key !== this._faceKey) {
      drawFace(this.faceCanvas.getContext('2d'), f, { ...(def.face || {}), skin: def.skinCss });
      this.faceTex.needsUpdate = true; this._faceKey = key;
    }
    if (p.tint) this.skinMat.color.set(def.skin).lerp(new THREE.Color(p.tint[0]), p.tint[1]); else this.skinMat.color.set(def.skin);
    if (this.update) this.update(p);
  }
}

/** idle breathing / blink / walk helpers (deterministic in t) */
export function blinkAt(t, seed = 0) {
  const period = 3.1 + (seed % 5) * 0.37, ph = ((t + seed * 0.71) % period + period) % period;
  return ph < 0.09 ? Math.sin((ph / 0.09) * Math.PI) : 0;
}
export function walk(phase, amp = 32) {
  const s = Math.sin(phase);
  return { legL: s * amp, legR: -s * amp, armL: [-s * amp * 0.8, 4, 0], armR: [s * amp * 0.8, 4, 0], hop: Math.abs(Math.cos(phase)) * 0.08 };
}
