// Drawn Roblox-style face decals (style/04-faces.png): white eyes with black outline, black pupil + shine, thick brows,
// orange nose dot, cartoon mouths. Drawn per frame into the avatar's face canvas (only when the face key changes).
// face = { expr, look:[x,y] (-1..1), blink 0..1, talk 0..1 }
const INK = '#141414', RED = '#ef4b4b', TONGUE = '#f06aa0', NOSE = '#e8913a';

const EXPR = {
  //            eye scale, lid (0 open..1 closed top), brow: [lift, tilt(+ = angry V), arch], mouth
  neutral:   { eye: 1.0, lid: 0, brow: [0, 0, 1], mouth: 'flat' },
  talk:      { eye: 1.0, lid: 0, brow: [0.15, 0, 1], mouth: 'open' },
  happy:     { eye: 1.0, lid: 0, brow: [0.2, 0, 1], mouth: 'smileOpen' },
  grin:      { eye: 1.04, lid: 0, brow: [0.3, 0, 1], mouth: 'grin' },
  smug:      { eye: 1.0, lid: 0.42, brow: [-0.05, 0.25, 0.6], mouth: 'smirk' },
  sideeye:   { eye: 1.0, lid: 0.38, brow: [-0.1, 0.1, 0.5], mouth: 'frownSmall', look: [0.85, 0] },
  shocked:   { eye: 1.12, lid: 0, brow: [0.55, -0.1, 1.2], mouth: 'O', pupil: 0.78 },
  scared:    { eye: 1.08, lid: 0, brow: [0.35, -0.6, 0.8], mouth: 'scared', sweat: true, pupil: 0.82 },
  crying:    { eye: 1.0, lid: 0, brow: [0.25, -0.7, 0.8], mouth: 'cry', tears: true },
  angry:     { eye: 1.0, lid: 0.12, brow: [-0.3, 0.95, 0.3], mouth: 'teeth' },
  disgusted: { eye: 1.0, lid: 0.45, brow: [-0.15, 0.7, 0.4], mouth: 'tongueOut' },
  lick:      { eye: 1.0, lid: 0, brow: [0.2, 0, 1], mouth: 'lick' },
  sick:      { eye: 1.0, lid: 0.1, brow: [0.2, -0.65, 0.8], mouth: 'wavy', green: true },
  love:      { eye: 1.05, lid: 0, brow: [0.3, 0, 1], mouth: 'smileOpen', hearts: true },
  cool:      { eye: 1.0, lid: 0.3, brow: [0.1, 0.2, 0.8], mouth: 'smirk' },
  closed:    { eye: 1.0, lid: 1, brow: [0.15, 0, 1], mouth: 'smile', happyClosed: true },
  yawn:      { eye: 1.0, lid: 1, brow: [0.35, -0.3, 1], mouth: 'yawn' },
  whistle:   { eye: 1.0, lid: 0.05, brow: [0.45, -0.2, 1], mouth: 'whistle', look: [0.3, 0.9] },
  chew:      { eye: 1.0, lid: 1, brow: [0.2, 0, 1], mouth: 'chew', happyClosed: true, cheeks: true },
  pout:      { eye: 1.0, lid: 0.05, brow: [0.1, 0.55, 0.5], mouth: 'pout' },
  sneaky:    { eye: 1.0, lid: 0.35, brow: [-0.05, 0.45, 0.6], mouth: 'smirk', look: [-0.8, -0.2] },
};
export const EXPRESSIONS = Object.keys(EXPR);

export function faceKey(f) {
  const q = (v) => Math.round(v * 20) / 20;
  return `${f.expr}|${q(f.look?.[0] ?? 0)},${q(f.look?.[1] ?? 0)}|${q(f.blink ?? 0)}|${q(f.talk ?? 0)}`;
}

/** style: { girl, lashes, blush, beard, skin } */
export function drawFace(ctx, f, style = {}) {
  const S = ctx.canvas.width, k = S / 512;
  ctx.setTransform(k, 0, 0, k, 0, 0);
  ctx.clearRect(0, 0, 512, 512);
  const E = EXPR[f.expr] || EXPR.neutral;
  const look = f.look || E.look || [0, 0];
  const lid = Math.max(E.lid, f.blink ?? 0);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';

  if (style.beard) beard(ctx);
  if (E.green) { ctx.fillStyle = 'rgba(140,200,60,0.75)'; for (const s of [-1, 1]) { ctx.beginPath(); ctx.ellipse(256 + s * 132, 318, 40, 24, 0, 0, 7); ctx.fill(); } }
  if (style.blush && !E.green) { ctx.fillStyle = 'rgba(255,120,140,0.45)'; for (const s of [-1, 1]) { ctx.beginPath(); ctx.ellipse(256 + s * 138, 312, 34, 20, 0, 0, 7); ctx.fill(); } }
  if (E.cheeks) { ctx.fillStyle = 'rgba(0,0,0,0.10)'; for (const s of [-1, 1]) { ctx.beginPath(); ctx.arc(256 + s * 120, 340, 46, 0, 7); ctx.fill(); } }

  // eyes (Roblox-animation style: oval sclera, coloured iris, pupil, two shines, dark upper-lid line, soft lower lid)
  const ew = 50 * E.eye, eh = 46 * E.eye, iris = style.iris || '#3d6fd8';
  for (const s of [-1, 1]) {
    const cx = 256 + s * 90, cy = 238;
    if (E.happyClosed || lid >= 0.98) {
      ctx.strokeStyle = INK; ctx.lineWidth = 9;
      ctx.beginPath();
      if (E.happyClosed) ctx.arc(cx, cy + 20, ew * 0.75, Math.PI * 1.15, Math.PI * 1.85);
      else { ctx.moveTo(cx - ew * 0.9, cy + 4); ctx.quadraticCurveTo(cx, cy + 18, cx + ew * 0.9, cy + 4); }
      ctx.stroke();
      if (style.lashes) lashes(ctx, cx, cy + 4, s, ew * 0.8, true);
      continue;
    }
    ctx.save();
    ctx.beginPath(); ctx.ellipse(cx, cy, ew, eh, 0, 0, 7); ctx.fillStyle = '#ffffff'; ctx.fill();
    ctx.clip();
    if (E.hearts) heartEye(ctx, cx, cy + 4, ew * 0.7);
    else {
      const pr = 30 * (E.pupil ?? 1) * E.eye;
      const px = cx + look[0] * ew * 0.42, py = cy + 2 - look[1] * eh * 0.36;
      const g = ctx.createRadialGradient(px, py - pr * 0.3, pr * 0.2, px, py, pr);
      g.addColorStop(0, shade(iris, 1.35)); g.addColorStop(1, shade(iris, 0.7));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, pr, 0, 7); ctx.fill();
      ctx.strokeStyle = shade(iris, 0.45); ctx.lineWidth = 3; ctx.stroke();
      ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(px, py, pr * 0.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(px + pr * 0.35, py - pr * 0.38, pr * 0.27, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(px - pr * 0.35, py + pr * 0.35, pr * 0.11, 0, 7); ctx.fill();
    }
    ctx.fillStyle = 'rgba(0,0,0,0.10)'; ctx.fillRect(cx - ew, cy - eh, ew * 2, eh * 0.35); // lid shadow on the white
    if (lid > 0.01) { ctx.fillStyle = style.skin || '#f5cd30'; const ly = cy - eh + lid * eh * 1.7; ctx.fillRect(cx - ew * 1.3, cy - eh * 1.4, ew * 2.6, ly - (cy - eh * 1.4)); }
    ctx.restore();
    // upper lid line (thick, dark) + thin lower lid
    const ly = cy - eh + Math.max(0, lid) * eh * 1.7;
    ctx.strokeStyle = INK; ctx.lineWidth = style.lashes ? 10 : 8;
    ctx.beginPath();
    if (lid > 0.01) { ctx.moveTo(cx - ew * 1.02, ly + 2); ctx.quadraticCurveTo(cx, ly - 4, cx + ew * 1.02, ly + 2); }
    else ctx.ellipse(cx, cy, ew, eh, 0, Math.PI * 1.05, Math.PI * 1.95);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(60,30,20,0.35)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.ellipse(cx, cy, ew * 0.98, eh * 0.98, 0, Math.PI * 0.2, Math.PI * 0.8); ctx.stroke();
    if (style.lashes) lashes(ctx, cx, ly + 2, s, ew, false);
  }
  // brows
  const [lift, tilt, arch] = E.brow;
  ctx.strokeStyle = style.brow || '#3a2416'; ctx.lineWidth = 11;
  for (const s of [-1, 1]) {
    const cx = 256 + s * 92, cy = 150 - lift * 30;
    const inner = cx - s * 42, outer = cx + s * 46;
    ctx.beginPath();
    ctx.moveTo(inner, cy + tilt * 26); ctx.quadraticCurveTo(cx, cy - 16 * arch + tilt * 6, outer, cy - tilt * 10 + 8);
    ctx.stroke();
  }
  // nose
  ctx.save(); ctx.translate(256, 368); ctx.scale(0.72, 0.72); ctx.translate(-256, -368);
  mouth(ctx, f.talk > 0.05 && ['flat', 'smile', 'smirk', 'frownSmall', 'pout'].includes(E.mouth) ? 'open' : E.mouth, f.talk ?? 0, style);
  ctx.restore();

  if (E.tears) for (const s of [-1, 1]) {
    const x = 256 + s * 92;
    ctx.fillStyle = '#3cb4f0'; ctx.strokeStyle = '#1d7fc0'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(x - 20, 270); ctx.bezierCurveTo(x - 30, 360, x - 14, 430, x - 26, 512); ctx.lineTo(x + 18, 512); ctx.bezierCurveTo(x + 8, 430, x + 26, 360, x + 18, 270); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.fillRect(x - 8, 300, 6, 90);
  }
  if (E.sweat) { ctx.fillStyle = '#3cb4f0'; ctx.beginPath(); ctx.moveTo(430, 150); ctx.quadraticCurveTo(452, 200, 440, 214); ctx.arc(430, 206, 14, 0.4, Math.PI - 0.1); ctx.quadraticCurveTo(410, 196, 430, 150); ctx.fill(); }
}

function shade(hex, k) { const n = parseInt(hex.slice(1), 16); const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => Math.max(0, Math.min(255, Math.round(v * k)))); return `rgb(${c.join(',')})`; }
function lashes(ctx, cx, top, s, r, closed) {
  ctx.strokeStyle = INK; ctx.lineWidth = 7;
  for (let i = 0; i < 3; i++) {
    const a = (closed ? -0.2 : -0.7) - i * 0.28;
    const x0 = cx + s * r * (0.55 + i * 0.16), y0 = top + (closed ? 0 : 6 + i * 10);
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + s * Math.cos(a) * 26, y0 + Math.sin(a) * 26); ctx.stroke();
  }
}
function heartEye(ctx, cx, cy, s) {
  ctx.fillStyle = '#f03a3a'; ctx.beginPath();
  ctx.moveTo(cx, cy + s * 0.85);
  ctx.bezierCurveTo(cx - s * 1.5, cy, cx - s * 0.7, cy - s * 1.0, cx, cy - s * 0.3);
  ctx.bezierCurveTo(cx + s * 0.7, cy - s * 1.0, cx + s * 1.5, cy, cx, cy + s * 0.85); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.beginPath(); ctx.arc(cx - s * 0.45, cy - s * 0.35, s * 0.18, 0, 7); ctx.fill();
}
function beard(ctx) {
  ctx.fillStyle = '#1f1a17';
  ctx.beginPath();
  ctx.moveTo(18, 230); ctx.lineTo(18, 360); ctx.quadraticCurveTo(40, 500, 256, 512); ctx.quadraticCurveTo(472, 500, 494, 360); ctx.lineTo(494, 230);
  ctx.lineTo(450, 236); ctx.quadraticCurveTo(440, 330, 380, 330); ctx.quadraticCurveTo(256, 300, 132, 330); ctx.quadraticCurveTo(72, 330, 62, 236); ctx.closePath(); ctx.fill();
}
function mouthShape(ctx, path, fill = INK, tongue = true, teethTop = false) {
  ctx.save(); ctx.beginPath(); path(); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); ctx.clip();
  if (teethTop) { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, 512, 372); }
  if (tongue) { ctx.fillStyle = RED; ctx.beginPath(); ctx.ellipse(256, 446, 70, 50, 0, 0, 7); ctx.fill(); }
  ctx.restore();
  ctx.strokeStyle = INK; ctx.lineWidth = 8; ctx.beginPath(); path(); ctx.closePath(); ctx.stroke();
}
function mouth(ctx, m, talk, style) {
  ctx.strokeStyle = INK; ctx.lineWidth = 10;
  const lip = style.lips;
  switch (m) {
    case 'flat': ctx.beginPath(); ctx.moveTo(206, 372); ctx.quadraticCurveTo(256, 368, 306, 372); ctx.stroke(); break;
    case 'smile': ctx.beginPath(); ctx.moveTo(196, 358); ctx.quadraticCurveTo(256, 404, 316, 358); ctx.stroke(); break;
    case 'frownSmall': ctx.beginPath(); ctx.moveTo(220, 384); ctx.quadraticCurveTo(256, 362, 292, 384); ctx.stroke(); break;
    case 'smirk': ctx.beginPath(); ctx.moveTo(196, 380); ctx.quadraticCurveTo(270, 392, 330, 352); ctx.stroke(); ctx.beginPath(); ctx.moveTo(322, 344); ctx.lineTo(336, 360); ctx.stroke(); break;
    case 'pout': ctx.beginPath(); ctx.moveTo(226, 388); ctx.quadraticCurveTo(256, 364, 286, 388); ctx.stroke(); break;
    case 'open': {
      const o = 0.35 + 0.65 * Math.min(1, talk || 1);
      mouthShape(ctx, () => { ctx.moveTo(196, 352); ctx.quadraticCurveTo(256, 346, 316, 352); ctx.quadraticCurveTo(300, 352 + 90 * o, 256, 356 + 92 * o); ctx.quadraticCurveTo(212, 352 + 90 * o, 196, 352); });
      break;
    }
    case 'smileOpen':
      mouthShape(ctx, () => { ctx.moveTo(182, 344); ctx.quadraticCurveTo(256, 336, 330, 344); ctx.quadraticCurveTo(318, 452, 256, 456); ctx.quadraticCurveTo(194, 452, 182, 344); }, INK, true, true);
      break;
    case 'grin':
      mouthShape(ctx, () => { ctx.moveTo(150, 336); ctx.quadraticCurveTo(256, 360, 362, 336); ctx.quadraticCurveTo(340, 452, 256, 456); ctx.quadraticCurveTo(172, 452, 150, 336); }, '#ffffff', false);
      ctx.lineWidth = 5; ctx.strokeStyle = '#9a9a9a'; ctx.beginPath(); ctx.moveTo(166, 392); ctx.quadraticCurveTo(256, 410, 346, 392); ctx.stroke();
      ctx.strokeStyle = INK; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(142, 326); ctx.lineTo(156, 344); ctx.moveTo(370, 326); ctx.lineTo(356, 344); ctx.stroke();
      break;
    case 'O': mouthShape(ctx, () => ctx.ellipse(256, 392, 40, 54, 0, 0, 7)); break;
    case 'yawn': mouthShape(ctx, () => ctx.ellipse(256, 402, 54, 82, 0, 0, 7)); break;
    case 'whistle': ctx.fillStyle = INK; ctx.beginPath(); ctx.ellipse(270, 378, 16, 18, 0, 0, 7); ctx.fill(); ctx.strokeStyle = INK; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(270, 378, 26, 0, 7); ctx.stroke(); break;
    case 'scared':
      mouthShape(ctx, () => { ctx.moveTo(188, 420); ctx.quadraticCurveTo(256, 330, 324, 420); ctx.quadraticCurveTo(256, 404, 188, 420); }, INK, false, false);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(226, 372); ctx.quadraticCurveTo(256, 360, 286, 372); ctx.lineTo(282, 382); ctx.quadraticCurveTo(256, 374, 230, 382); ctx.fill();
      ctx.fillStyle = RED; ctx.beginPath(); ctx.ellipse(256, 408, 44, 10, 0, 0, 7); ctx.fill();
      break;
    case 'cry':
      mouthShape(ctx, () => { ctx.moveTo(196, 420); ctx.quadraticCurveTo(256, 336, 316, 420); ctx.quadraticCurveTo(256, 400, 196, 420); }, INK, false);
      ctx.fillStyle = RED; ctx.beginPath(); ctx.ellipse(256, 404, 40, 12, 0, 0, 7); ctx.fill();
      break;
    case 'teeth':
      mouthShape(ctx, () => { ctx.moveTo(184, 360); ctx.quadraticCurveTo(256, 340, 328, 360); ctx.lineTo(332, 420); ctx.quadraticCurveTo(256, 440, 180, 420); }, '#ffffff', false);
      ctx.strokeStyle = INK; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(184, 392); ctx.lineTo(330, 392); ctx.moveTo(256, 352); ctx.lineTo(256, 430); ctx.moveTo(220, 356); ctx.lineTo(220, 428); ctx.moveTo(292, 356); ctx.lineTo(292, 428); ctx.stroke();
      break;
    case 'tongueOut':
      ctx.beginPath(); ctx.moveTo(180, 396); ctx.quadraticCurveTo(230, 350, 300, 372); ctx.stroke();
      ctx.fillStyle = TONGUE; ctx.strokeStyle = INK; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(230, 372); ctx.quadraticCurveTo(222, 452, 262, 456); ctx.quadraticCurveTo(302, 456, 292, 372); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(261, 380); ctx.lineTo(261, 420); ctx.stroke();
      break;
    case 'lick':
      ctx.beginPath(); ctx.moveTo(190, 366); ctx.quadraticCurveTo(250, 392, 306, 372); ctx.stroke();
      ctx.fillStyle = TONGUE; ctx.strokeStyle = INK; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.ellipse(334, 360, 40, 30, -0.5, 0, 7); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(320, 350); ctx.quadraticCurveTo(334, 362, 344, 378); ctx.stroke();
      break;
    case 'wavy':
      ctx.beginPath(); ctx.moveTo(190, 384);
      for (let i = 0; i < 6; i++) ctx.quadraticCurveTo(201 + i * 22, i % 2 ? 404 : 364, 212 + i * 22, 384);
      ctx.stroke(); break;
    case 'chew':
      ctx.beginPath(); ctx.moveTo(214, 380); ctx.quadraticCurveTo(235, 360 + talk * 20, 256, 380); ctx.quadraticCurveTo(277, 400 - talk * 20, 298, 380); ctx.stroke(); break;
  }
  if (lip && ['smile', 'smirk', 'flat'].includes(m)) { ctx.strokeStyle = 'rgba(214,40,60,0.95)'; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(214, 376); ctx.quadraticCurveTo(256, 392, 298, 376); ctx.stroke(); }
}
