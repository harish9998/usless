// The kitchen of the Block Family mansion (style/05-the-house.png): white island with marble top, floor-to-ceiling
// windows with dark frames onto a sunny garden, wood plank floor, built-in oven (door opens), fridge, shelves, plants.
// Units: studs. Island centred at the origin, counter top at y = 3.2. Camera side is +Z.
import * as THREE from 'three';
import { RoomEnvironment } from '../../vendor/addons/environments/RoomEnvironment.js';
import { plastic, rbox } from '../chars/avatar.js';
import { tex, woodPlanks, marble, windowView, canvas } from '../core/tex.js';

export const COUNTER = 3.2;

function cabinetTex(cols = 3, w = 1024, h = 512) {
  const c = canvas(w, h), x = c.getContext('2d');
  x.fillStyle = '#f7f7f5'; x.fillRect(0, 0, w, h);
  x.strokeStyle = 'rgba(0,0,0,0.13)'; x.lineWidth = 4;
  for (let i = 0; i < cols; i++) { const cw = w / cols; x.strokeRect(i * cw + 10, 12, cw - 20, h - 24); x.fillStyle = '#b9bcc2'; x.fillRect(i * cw + cw / 2 - 40, 46, 80, 9); }
  return c;
}
function plantPot(mat, leaf) {
  const g = new THREE.Group();
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.42, 1.1, 24), mat); pot.position.y = 0.55; g.add(pot);
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2, l = new THREE.Mesh(new THREE.SphereGeometry(0.42, 12, 8), leaf);
    l.scale.set(0.5, 1.5, 0.22); l.position.set(Math.cos(a) * 0.35, 1.7 + (i % 3) * 0.25, Math.sin(a) * 0.35); l.rotation.set(Math.sin(a) * 0.5, a, Math.cos(a) * 0.5); g.add(l);
  }
  return g;
}

export function buildKitchen(renderer) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xdcefff);
  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 0.4;

  // ---- lights ----
  const hemi = new THREE.HemisphereLight(0xdff1ff, 0xb08a66, 1.15); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff3e0, 3.4); sun.position.set(14, 30, 22); sun.castShadow = true;
  sun.shadow.mapSize.set(4096, 4096); const sc = sun.shadow.camera; sc.left = -22; sc.right = 22; sc.top = 22; sc.bottom = -22; sc.near = 1; sc.far = 90;
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03; sun.shadow.radius = 3;
  scene.add(sun); scene.add(sun.target);
  const fill = new THREE.DirectionalLight(0xcfe6ff, 0.9); fill.position.set(-10, 12, -30); scene.add(fill); // window bounce from behind

  // ---- materials ----
  const wall = new THREE.MeshStandardMaterial({ color: 0xf4f4f2, roughness: 0.92 });
  const floorT = tex(woodPlanks(1024), { repeat: [6, 6] });
  const floor = new THREE.MeshStandardMaterial({ map: floorT, roughness: 0.55, envMapIntensity: 0.35 });
  const white = plastic(0xf7f7f5, { roughness: 0.3, clearcoat: 0.5 });
  const cab = (cols) => plastic(0xffffff, { map: tex(cabinetTex(cols)), roughness: 0.3, clearcoat: 0.5 });
  const marbleM = new THREE.MeshPhysicalMaterial({ map: tex(marble(1024), { repeat: [1, 1] }), roughness: 0.18, clearcoat: 0.8, clearcoatRoughness: 0.1 });
  const frame = plastic(0x34373c, { roughness: 0.45 });
  const steel = new THREE.MeshStandardMaterial({ color: 0xc9ccd1, roughness: 0.28, metalness: 0.85 });
  const wood = new THREE.MeshStandardMaterial({ map: tex(woodPlanks(512), { repeat: [1, 0.25] }), roughness: 0.55 });
  const potM = plastic(0xffffff, { roughness: 0.5 }), leafM = plastic(0x3f9a3a, { roughness: 0.6 });

  const add = (geo, mat, x, y, z, ry = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.y = ry; m.castShadow = m.receiveShadow = true; scene.add(m); return m; };

  // floor + ceiling + walls
  const fl = add(new THREE.PlaneGeometry(80, 80), floor, 0, 0, 0); fl.rotation.x = -Math.PI / 2; fl.castShadow = false;
  const ce = add(new THREE.PlaneGeometry(80, 80), wall, 0, 19, 0); ce.rotation.x = Math.PI / 2; ce.castShadow = false;
  add(new THREE.BoxGeometry(1, 19, 60), wall, -17.5, 9.5, 0);
  add(new THREE.BoxGeometry(1, 19, 60), wall, 17.5, 9.5, 0);
  add(new THREE.BoxGeometry(60, 19, 1), wall, 0, 9.5, 26).castShadow = false;

  // back wall = big window wall at z = -14 (glass gaps between frames)
  const BZ = -14;
  const view = new THREE.Mesh(new THREE.PlaneGeometry(150, 75), new THREE.MeshBasicMaterial({ map: tex(windowView(2048, 1024), { repeat: [1, 1] }), toneMapped: false }));
  view.position.set(0, 18, -60); scene.add(view);
  add(new THREE.BoxGeometry(60, 2.2, 1), wall, 0, 17.9, BZ); // header
  add(new THREE.BoxGeometry(60, 0.6, 1), wall, 0, 0.3, BZ); // sill
  for (const x of [-17, 17]) add(new THREE.BoxGeometry(6, 19, 1), wall, x + Math.sign(x) * 1.5, 9.5, BZ);
  for (let x = -14; x <= 14.01; x += 4.66) add(new THREE.BoxGeometry(0.35, 16.8, 0.5), frame, x, 8.6, BZ + 0.1);
  for (const y of [0.7, 7.5, 16.8]) add(new THREE.BoxGeometry(28.4, 0.32, 0.5), frame, 0, y, BZ + 0.1);
  const glass = new THREE.MeshPhysicalMaterial({ color: 0xffffff, transmission: 0, transparent: true, opacity: 0.08, roughness: 0.05, metalness: 0, clearcoat: 1 });
  const gp = new THREE.Mesh(new THREE.PlaneGeometry(28, 16.4), glass); gp.position.set(0, 8.7, BZ + 0.05); scene.add(gp);

  // back counter run under the window (left part) + sink
  add(rbox(10, 2.9, 2.6, 0.06), cab(4), -8.5, 1.45, -12.4);
  add(rbox(10.4, 0.3, 3.0, 0.08), marbleM, -8.5, 3.05, -12.3);
  add(new THREE.CylinderGeometry(0.08, 0.08, 1.6, 12), steel, -8.5, 4.0, -13.3);
  const spout = add(new THREE.TorusGeometry(0.5, 0.08, 10, 24, Math.PI), steel, -8.5, 4.8, -13.0); spout.rotation.y = Math.PI / 2;

  // left wall: fridge + tall cabinets
  add(rbox(4.2, 11, 3.2, 0.12), steel, -15.2, 5.5, -7.5, Math.PI / 2);
  add(new THREE.BoxGeometry(0.15, 10.6, 0.05), frame, -13.55, 5.6, -7.5);
  for (const z of [-8.2, -6.8]) add(rbox(0.12, 3.2, 0.12, 0.04), frame, -13.4, 6.2, z);
  add(rbox(3.6, 11, 3.2, 0.06), cab(2), -15.4, 5.5, -3.3, Math.PI / 2);

  // right wall: oven tower with a working door
  const OX = 15.6, OZ = -5.5;
  add(rbox(3.4, 16, 4.6, 0.06), white, OX, 8, OZ);
  const ovenFront = OX - 1.72;
  add(rbox(0.3, 3.4, 3.9, 0.08), frame, ovenFront - 0.05, 5.0, OZ); // oven frame
  const cavity = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.7, 3.2), new THREE.MeshStandardMaterial({ color: 0x2b1408, emissive: 0xff7a1a, emissiveIntensity: 0.0, roughness: 0.8 }));
  cavity.position.set(ovenFront - 0.12, 4.95, OZ); scene.add(cavity);
  const ovenLight = new THREE.PointLight(0xff9a3a, 0, 9, 1.6); ovenLight.position.set(ovenFront - 1.2, 5.0, OZ); scene.add(ovenLight);
  const doorPivot = new THREE.Group(); doorPivot.position.set(ovenFront - 0.22, 3.55, OZ); scene.add(doorPivot);
  const door = new THREE.Mesh(rbox(0.22, 2.9, 3.7, 0.06), frame); door.position.y = 1.45; door.castShadow = true; doorPivot.add(door);
  const win = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.5), new THREE.MeshStandardMaterial({ color: 0x150c08, emissive: 0xff7a1a, emissiveIntensity: 0.0, roughness: 0.2 }));
  win.position.set(-0.115, 1.5, 0); win.rotation.y = -Math.PI / 2; doorPivot.add(win);
  const handle = new THREE.Mesh(rbox(0.16, 0.16, 2.6, 0.06), steel); handle.position.set(-0.24, 2.6, 0); doorPivot.add(handle);
  add(rbox(0.2, 0.9, 3.6, 0.05), frame, ovenFront - 0.06, 7.4, OZ); // control strip
  // right wall upper cabinets + range
  add(rbox(3.2, 2.9, 7, 0.06), cab(3), 15.8, 1.45, 2.2, Math.PI / 2);
  add(rbox(3.6, 0.3, 7.4, 0.08), marbleM, 15.7, 3.05, 2.2);

  // floating wood shelves on the right part of the back wall (beside the window)
  for (const y of [8.5, 11]) add(rbox(5, 0.28, 1.2, 0.05), wood, 11.5, y, -13.3);
  for (const [x, y, c] of [[10, 9.2, 0xffffff], [11.3, 9.0, 0x5ec8ff], [12.6, 11.7, 0xffffff], [13.4, 9.3, 0x3ddc97]]) add(new THREE.CylinderGeometry(0.35, 0.35, 1.2, 16), plastic(c), x, y, -13.2);

  // island
  add(rbox(9, 2.9, 4, 0.06), cab(3), 0, 1.45, 0);
  const top = add(rbox(9.6, 0.32, 4.6, 0.1), marbleM, 0, COUNTER - 0.16, 0);
  top.receiveShadow = true;
  add(rbox(9.1, 0.25, 4.1, 0.03), plastic(0xd9d9d6), 0, 0.12, 0);

  // pendant lights above the island
  const glassBulb = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.1, transmission: 0, emissive: 0xfff2d6, emissiveIntensity: 0.6, transparent: true, opacity: 0.85 });
  for (const x of [-3, 0, 3]) {
    add(new THREE.CylinderGeometry(0.03, 0.03, 6.5, 6), frame, x, 15.75, 0).castShadow = false;
    const b = add(new THREE.SphereGeometry(0.7, 24, 16), glassBulb, x, 12.2, 0); b.castShadow = false;
  }

  // plants
  for (const [x, z, s] of [[-15.5, -12.5, 1.6], [14.8, -12.4, 1.8], [-14.5, 8, 1.4]]) { const p = plantPot(potM, leafM); p.position.set(x, 0, z); p.scale.setScalar(s); p.traverse((o) => { if (o.isMesh) o.castShadow = o.receiveShadow = true; }); scene.add(p); }
  const herb = plantPot(potM, leafM); herb.scale.setScalar(0.45); herb.position.set(-12, COUNTER, -12.4); scene.add(herb);

  return {
    scene, sun, hemi, COUNTER,
    oven: { pos: new THREE.Vector3(ovenFront, 5, OZ), door: doorPivot, cavity, win, light: ovenLight },
    /** open 0..1 (door folds down toward the room), glow 0..1 */
    setOven(open, glow) {
      doorPivot.rotation.z = open * Math.PI * 0.5; // hinge at the bottom, opens toward -x (into the room)
      cavity.material.emissiveIntensity = glow * 1.6; win.material.emissiveIntensity = glow * 0.9; ovenLight.intensity = glow * 40;
    },
  };
}
