// LIL BRO'S ROOM at night (style/05-the-house.png "LIL BRO'S ROOM" + the look of the 3 AM short JbCxC0k_SEU):
// striped carpet, white walls, window wall with a night garden + driveway (car headlights sweep in and throw the window
// frame's shadow across the room), bunk bed, gaming desk with RGB monitor + red gaming chair, closet with double doors,
// bedroom door, purple LED strip, warm desk lamp. Plus the JUNK: ~46 items with a messy pose, a closet-stuffed pose and
// an avalanche pose (for "When you hear mom's car in the driveway").
// Units: studs. Room x -13..13, z -11..11. Window wall at z = -11. Closet on the right wall (x = 13).
import * as THREE from 'three';
import { RoomEnvironment } from '../../vendor/addons/environments/RoomEnvironment.js';
import { plastic, fabric, rbox } from '../chars/avatar.js';
import { tex, canvas, star } from '../core/tex.js';
import { hash, clamp, lerp, E } from '../core/util.js';

const rnd = (i) => hash(i * 3.17 + 0.71);

function carpetTex() {
  const c = canvas(512, 512), x = c.getContext('2d');
  x.fillStyle = '#c9cbe0'; x.fillRect(0, 0, 512, 512);
  for (let y = 0; y < 512; y += 6) { x.fillStyle = y % 12 ? 'rgba(80,84,130,0.16)' : 'rgba(255,255,255,0.22)'; x.fillRect(0, y, 512, 3); }
  for (let i = 0; i < 4000; i++) { x.fillStyle = `rgba(60,60,100,${0.04 + rnd(i) * 0.06})`; x.fillRect(rnd(i + 9) * 512, rnd(i + 19) * 512, 2, 2); }
  return c;
}
function nightView() {
  const w = 2048, h = 1024, c = canvas(w, h), x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#13205a'); g.addColorStop(0.6, '#2c3f8f'); g.addColorStop(1, '#3a4a7a');
  x.fillStyle = g; x.fillRect(0, 0, w, h);
  for (let i = 0; i < 260; i++) { x.fillStyle = `rgba(255,255,255,${0.3 + rnd(i) * 0.7})`; x.fillRect(rnd(i + 1) * w, rnd(i + 2) * h * 0.55, 2, 2); }
  x.fillStyle = '#f4f1d8'; x.beginPath(); x.arc(w * 0.78, h * 0.18, 46, 0, 7); x.fill();
  for (let k = 0; k < 40; k++) { // tree silhouettes
    const tx = rnd(k + 70) * w, th = h * (0.25 + rnd(k + 71) * 0.35), tw = 90 + rnd(k + 72) * 120, base = h * 0.78;
    x.fillStyle = `rgb(${20 + rnd(k) * 14},${46 + rnd(k + 3) * 26},${52 + rnd(k + 5) * 26})`;
    for (let b = 0; b < 6; b++) { x.beginPath(); x.arc(tx + (rnd(k * 7 + b) - 0.5) * tw, base - th * (0.4 + rnd(k * 5 + b) * 0.55), tw * 0.4, 0, 7); x.fill(); }
  }
  x.fillStyle = '#1a2a22'; x.fillRect(0, h * 0.76, w, h * 0.24); // lawn
  x.fillStyle = '#3a3d48'; x.fillRect(w * 0.3, h * 0.8, w * 0.7, h * 0.2); // driveway
  return c;
}
function poster(kind) {
  const c = canvas(512, 704), x = c.getContext('2d');
  if (kind === 'palm') {
    x.fillStyle = '#efe6dc'; x.fillRect(0, 0, 512, 704);
    x.strokeStyle = '#141414'; x.lineWidth = 14; x.beginPath(); x.moveTo(250, 640); x.quadraticCurveTo(230, 420, 270, 250); x.stroke();
    x.fillStyle = '#141414'; for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i - 3) * 0.48; x.beginPath(); x.ellipse(270 + Math.cos(a) * 95, 250 + Math.sin(a) * 75, 120, 24, a, 0, 7); x.fill(); }
  } else if (kind === 'rocket') {
    const g = x.createLinearGradient(0, 0, 0, 704); g.addColorStop(0, '#1d1b5e'); g.addColorStop(1, '#6a2fb0'); x.fillStyle = g; x.fillRect(0, 0, 512, 704);
    for (let i = 0; i < 80; i++) { x.fillStyle = '#fff'; x.fillRect(rnd(i + 300) * 512, rnd(i + 301) * 704, 3, 3); }
    x.fillStyle = '#f2f2f2'; x.beginPath(); x.moveTo(256, 140); x.quadraticCurveTo(330, 260, 310, 470); x.lineTo(202, 470); x.quadraticCurveTo(182, 260, 256, 140); x.fill();
    x.fillStyle = '#ff3b30'; x.beginPath(); x.moveTo(202, 420); x.lineTo(150, 520); x.lineTo(210, 480); x.fill(); x.beginPath(); x.moveTo(310, 420); x.lineTo(362, 520); x.lineTo(302, 480); x.fill();
    x.fillStyle = '#5ec8ff'; x.beginPath(); x.arc(256, 300, 34, 0, 7); x.fill();
    x.fillStyle = '#ffb02e'; x.beginPath(); x.moveTo(214, 470); x.quadraticCurveTo(256, 640, 298, 470); x.fill();
  } else {
    x.fillStyle = '#2bb673'; x.fillRect(0, 0, 512, 704); x.fillStyle = '#145a3a';
    x.beginPath(); x.ellipse(256, 420, 170, 90, 0, 0, 7); x.fill(); x.fillRect(120, 470, 40, 120); x.fillRect(340, 470, 40, 120);
    x.beginPath(); x.moveTo(390, 400); x.quadraticCurveTo(470, 300, 430, 200); x.lineWidth = 50; x.strokeStyle = '#145a3a'; x.stroke();
    x.beginPath(); x.arc(430, 190, 40, 0, 7); x.fill();
    x.fillStyle = '#ffffff'; x.font = 'bold 70px sans-serif'; x.textAlign = 'center'; x.fillText('RAWR', 256, 130);
  }
  return c;
}

/** the junk: deterministic list of items with messy / closet / avalanche poses */
function makeJunk(scene) {
  const cols = [0xff3b30, 0x2f63e0, 0x3ddc97, 0xffd43b, 0xff6fae, 0xb28dff, 0xff8a1f, 0x5ec8ff, 0xf7f7f5, 0x222428];
  const card = plastic(0xc89462, { roughness: 0.85, clearcoat: 0 });
  const kinds = [];
  const items = [];
  const add = (mesh, kind) => { mesh.traverse((o) => { if (o.isMesh) o.castShadow = o.receiveShadow = true; }); scene.add(mesh); items.push({ mesh, kind }); };
  for (let i = 0; i < 46; i++) {
    const r = rnd(i * 13), col = cols[Math.floor(rnd(i * 7 + 1) * cols.length)];
    let m, kind;
    if (r < 0.16) { kind = 'pizzabox'; m = new THREE.Mesh(rbox(2.0, 0.26, 2.0, 0.04), card); }
    else if (r < 0.32) { kind = 'can'; m = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.56, 18), plastic(col, { metalness: 0.5, roughness: 0.25 })); }
    else if (r < 0.52) { kind = 'shirt'; m = new THREE.Mesh(rbox(1.4, 0.14, 1.15, 0.06), fabric(col)); }
    else if (r < 0.62) { kind = 'sock'; m = new THREE.Mesh(rbox(0.36, 0.14, 0.95, 0.06), fabric(col)); }
    else if (r < 0.72) { kind = 'book'; m = new THREE.Mesh(rbox(0.85, 0.2, 1.15, 0.03), plastic(col, { roughness: 0.5 })); }
    else if (r < 0.82) { kind = 'ball'; m = new THREE.Mesh(new THREE.SphereGeometry(0.38, 20, 14), plastic(col)); }
    else if (r < 0.9) { kind = 'chips'; m = new THREE.Mesh(rbox(0.75, 0.22, 1.05, 0.08), plastic(col, { roughness: 0.2, metalness: 0.3 })); }
    else { kind = 'block'; m = new THREE.Mesh(rbox(0.55, 0.55, 0.55, 0.06), plastic(col)); }
    add(m, kind);
  }
  // poses
  const floorSpot = (i) => { // scattered over the floor, avoiding the bed footprint and the closet door swing
    for (let k = 0; k < 20; k++) {
      const x = lerp(-9.5, 9.5, rnd(i * 31 + k)), z = lerp(-8.5, 8.5, rnd(i * 37 + k + 5));
      if (x < -8.5 && z < 1) continue; if (x > 8 && z < -1) continue;
      return [x, z];
    }
    return [0, 0];
  };
  items.forEach((it, i) => {
    const h = it.mesh.geometry.boundingBox ? 0 : (it.mesh.geometry.computeBoundingBox(), 0);
    const bb = it.mesh.geometry.boundingBox, half = (bb.max.y - bb.min.y) / 2;
    let p;
    if (i % 9 === 3) p = [lerp(-12.0, -9.6, rnd(i + 1)), 1.95 + half, lerp(-9.5, -1.5, rnd(i + 2))]; // on the lower bunk
    else if (i % 11 === 5) p = [lerp(-9.5, -4.5, rnd(i + 3)), 3.15 + half, lerp(-10.2, -8.6, rnd(i + 4))]; // on the desk
    else { const [x, z] = floorSpot(i); p = [x, half + (rnd(i + 5) < 0.25 ? 0.3 : 0), z]; }
    it.mess = { p, r: [it.kind === 'can' && rnd(i + 6) < 0.5 ? Math.PI / 2 : (rnd(i + 7) - 0.5) * 0.3, rnd(i + 8) * 6.28, (rnd(i + 9) - 0.5) * 0.3] };
    // stuffed into the closet: a jumbled heap that fills it to the top
    const col = i % 3, row = Math.floor(i / 3);
    it.closet = { p: [13.5 + col * 0.8 + (rnd(i + 10) - 0.5) * 0.4, 0.4 + row * 0.58 + rnd(i + 11) * 0.2, -7.2 + rnd(i + 12) * 4.4], r: [rnd(i + 13) * 6, rnd(i + 14) * 6, rnd(i + 15) * 6] };
    // the avalanche heap in front of the closet (buries whoever stands at x≈8.8, z≈-4.8)
    const a = rnd(i + 16) * Math.PI * 2, rr = Math.sqrt(rnd(i + 17)) * 3.2;
    it.heap = { p: [8.6 + Math.cos(a) * rr * 0.9 - 0.4, 0, -4.8 + Math.sin(a) * rr], r: [rnd(i + 18) * 6, rnd(i + 19) * 6, rnd(i + 20) * 6] };
    it.heap.p[1] = half + Math.max(0, 3.9 - rr * 1.15) * (0.55 + rnd(i + 21) * 0.45);
    it.order = rnd(i + 22);
  });
  return items;
}

export function buildBedroom(renderer) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x101433);
  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 0.18;

  // ---- lights (night) ----
  const hemi = new THREE.HemisphereLight(0x5d6fd0, 0x221a38, 0.32); scene.add(hemi);
  const moon = new THREE.DirectionalLight(0x7f93ff, 1.6); moon.position.set(-6, 22, -40); moon.castShadow = true;
  moon.shadow.mapSize.set(2048, 2048); Object.assign(moon.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 1, far: 90 }); moon.shadow.bias = -0.0005; moon.shadow.normalBias = 0.03;
  scene.add(moon); scene.add(moon.target);
  const lamp = new THREE.PointLight(0xffa955, 26, 22, 1.6); lamp.position.set(-4.6, 5.4, -9.4); lamp.castShadow = true; lamp.shadow.mapSize.set(1024, 1024); lamp.shadow.bias = -0.002; scene.add(lamp);
  const screen = new THREE.PointLight(0x55c8ff, 14, 14, 1.8); screen.position.set(-7.2, 4.6, -8.6); scene.add(screen);
  const led1 = new THREE.PointLight(0xa04dff, 18, 22, 1.6); led1.position.set(-6, 14, 6); scene.add(led1);
  const led2 = new THREE.PointLight(0xff4de0, 12, 22, 1.6); led2.position.set(8, 14, -6); scene.add(led2);
  const ceiling = new THREE.PointLight(0xfff4e6, 0, 40, 1.2); ceiling.position.set(0, 13.5, 0); ceiling.castShadow = true; ceiling.shadow.mapSize.set(2048, 2048); ceiling.shadow.bias = -0.002; scene.add(ceiling);
  const hallway = new THREE.SpotLight(0xffc488, 0, 30, 0.6, 0.6, 1.4); hallway.position.set(18, 7, 6); hallway.target.position.set(4, 0, 4); hallway.castShadow = true; scene.add(hallway, hallway.target);
  const heads = [0, 1].map(() => { const s = new THREE.SpotLight(0xfff1d0, 0, 90, 0.3, 0.55, 1.0); s.castShadow = true; s.shadow.mapSize.set(1024, 1024); s.shadow.bias = -0.0008; scene.add(s, s.target); return s; });
  const glareTex = (() => { const c = canvas(128, 128), x = c.getContext('2d'); const g = x.createRadialGradient(64, 64, 0, 64, 64, 64); g.addColorStop(0, 'rgba(255,255,240,1)'); g.addColorStop(0.2, 'rgba(255,240,200,0.6)'); g.addColorStop(1, 'rgba(255,240,200,0)'); x.fillStyle = g; x.fillRect(0, 0, 128, 128); return new THREE.CanvasTexture(c); })();
  const glares = [0, 1].map(() => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glareTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false })); s.scale.setScalar(5); scene.add(s); return s; });

  const car = new THREE.Group(); scene.add(car);
  { const paint = plastic(0x2a2f3a, { roughness: 0.25, clearcoat: 1 }), glass = plastic(0x0d1220, { roughness: 0.1 }), tyre = plastic(0x111111);
    const body = new THREE.Mesh(rbox(4.6, 1.3, 9, 0.4), paint); body.position.y = 1.3; car.add(body);
    const cab = new THREE.Mesh(rbox(4.0, 1.3, 4.6, 0.5), glass); cab.position.set(0, 2.55, -0.6); car.add(cab);
    for (const [x, z] of [[-2.1, 2.9], [2.1, 2.9], [-2.1, -2.9], [2.1, -2.9]]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.6, 18), tyre); w.rotation.z = Math.PI / 2; w.position.set(x, 0.75, z); car.add(w); }
    for (const x of [-1.5, 1.5]) { const hl = new THREE.Mesh(new THREE.SphereGeometry(0.35, 12, 8), new THREE.MeshBasicMaterial({ color: 0xfff6dc, toneMapped: false })); hl.position.set(x, 1.5, 4.55); car.add(hl); } }
  // ---- materials ----
  const wallM = new THREE.MeshStandardMaterial({ color: 0xeceaf2, roughness: 0.9 });
  const floorM = new THREE.MeshStandardMaterial({ map: tex(carpetTex(), { repeat: [7, 7] }), roughness: 0.95 });
  const white = plastic(0xf4f4f6, { roughness: 0.35, clearcoat: 0.4 });
  const frame = plastic(0x3a332f, { roughness: 0.5 });
  const wood = plastic(0x8a5a3a, { roughness: 0.5, clearcoat: 0.3 });
  const add = (geo, mat, x, y, z, ry = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.y = ry; m.castShadow = m.receiveShadow = true; scene.add(m); return m; };

  const fl = add(new THREE.PlaneGeometry(26, 22), floorM, 0, 0, 0); fl.rotation.x = -Math.PI / 2; fl.castShadow = false;
  const ce = add(new THREE.PlaneGeometry(26, 22), wallM, 0, 15, 0); ce.rotation.x = Math.PI / 2; ce.castShadow = false;
  add(new THREE.BoxGeometry(1, 15, 22), wallM, -13.5, 7.5, 0);
  // right wall with the closet opening (z -8..-2, h 0..10) and the bedroom door opening (z 3.5..7.5, h 0..9.5)
  add(new THREE.BoxGeometry(1, 15, 3), wallM, 13.5, 7.5, -9.5);
  add(new THREE.BoxGeometry(1, 5, 6), wallM, 13.5, 12.5, -5);
  add(new THREE.BoxGeometry(1, 15, 5.5), wallM, 13.5, 7.5, 0.75);
  add(new THREE.BoxGeometry(1, 5.5, 4), wallM, 13.5, 12.25, 5.5);
  add(new THREE.BoxGeometry(1, 15, 3.5), wallM, 13.5, 7.5, 9.25);
  add(new THREE.BoxGeometry(26, 15, 1), wallM, 0, 7.5, 11.5).castShadow = false;
  // window wall z = -11 with an opening x -1.5..7.5, y 3.5..11
  const WZ = -11.5;
  add(new THREE.BoxGeometry(11.5, 15, 1), wallM, -7.25, 7.5, WZ);
  add(new THREE.BoxGeometry(5.5, 15, 1), wallM, 10.25, 7.5, WZ);
  add(new THREE.BoxGeometry(9, 3.5, 1), wallM, 3, 1.75, WZ);
  add(new THREE.BoxGeometry(9, 4, 1), wallM, 3, 13, WZ);
  for (const x of [-1.5, 3, 7.5]) add(new THREE.BoxGeometry(0.32, 7.6, 0.6), frame, x, 7.25, WZ + 0.2);
  for (const y of [3.5, 11]) add(new THREE.BoxGeometry(9.3, 0.32, 0.6), frame, 3, y, WZ + 0.2);
  add(new THREE.BoxGeometry(9.6, 0.3, 1.2), white, 3, 3.35, WZ + 0.6); // sill
  const view = new THREE.Mesh(new THREE.PlaneGeometry(120, 60), new THREE.MeshBasicMaterial({ map: tex(nightView()), toneMapped: false, color: 0xffffff }));
  view.position.set(3, 12, -48); scene.add(view);
  // curtains
  const curtain = fabric(0x3c4fb8);
  for (const x of [-2.6, 8.6]) add(rbox(1.6, 9.5, 0.5, 0.2), curtain, x, 7.6, WZ + 0.9);
  // baseboards
  for (const [w, x, z, ry] of [[26, 0, -10.95, 0], [22, -12.95, 0, Math.PI / 2]]) add(new THREE.BoxGeometry(w, 0.45, 0.12), white, x, 0.22, z, ry);

  // bunk bed on the left wall
  const bedM = fabric(0x2f5fd0), sheet = fabric(0xf2f4ff), pillow = fabric(0xffffff);
  for (const [x, z] of [[-12.6, -10.2], [-8.6, -10.2], [-12.6, -1.0], [-8.6, -1.0]]) add(rbox(0.45, 10.5, 0.45, 0.06), white, x, 5.25, z);
  for (const y of [1.5, 6.6]) {
    add(rbox(4.4, 0.4, 9.6, 0.06), white, -10.6, y, -5.6);
    add(rbox(4.0, 0.55, 9.1, 0.2), sheet, -10.6, y + 0.45, -5.6);
    add(rbox(4.1, 0.4, 6.0, 0.25), bedM, -10.6, y + 0.85, -4.0);
    add(rbox(2.6, 0.5, 1.4, 0.24), pillow, -10.6, y + 0.95, -9.3);
  }
  add(rbox(4.4, 1.0, 0.25, 0.05), white, -10.6, 8.0, -1.0);
  for (let k = 0; k < 6; k++) add(rbox(0.25, 0.15, 1.6, 0.04), white, -8.4, 1.6 + k * 1.1, -0.8, Math.PI / 2);

  // gaming desk + RGB monitor + lamp + red gaming chair
  add(rbox(6.4, 0.3, 2.6, 0.05), white, -6.8, 3.05, -9.8);
  for (const x of [-9.8, -3.8]) add(rbox(0.3, 3.0, 2.4, 0.04), white, x, 1.5, -9.8);
  const mon = add(rbox(3.6, 2.1, 0.22, 0.06), plastic(0x15161a), -7.2, 4.9, -10.4);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(3.3, 1.8), new THREE.MeshBasicMaterial({ map: tex((() => { const c = canvas(512, 288), x = c.getContext('2d'); const g = x.createLinearGradient(0, 0, 512, 288); g.addColorStop(0, '#13206b'); g.addColorStop(1, '#4b1e8f'); x.fillStyle = g; x.fillRect(0, 0, 512, 288); x.fillStyle = '#fff'; x.beginPath(); x.arc(380, 70, 26, 0, 7); x.fill(); for (let i = 0; i < 9; i++) { x.fillStyle = ['#3ddc97', '#ffd43b', '#ff6fae'][i % 3]; x.fillRect(40 + i * 50, 200 - (i % 4) * 30, 34, 34); } return c; })()), toneMapped: false }));
  scr.position.set(-7.2, 4.9, -10.28); scene.add(scr);
  add(new THREE.BoxGeometry(3.7, 0.08, 0.1), new THREE.MeshBasicMaterial({ color: 0xff3df0, toneMapped: false }), -7.2, 3.82, -10.45);
  add(rbox(2.6, 0.12, 0.9, 0.04), plastic(0x1b1c22), -7.0, 3.26, -9.1);
  add(new THREE.CylinderGeometry(0.06, 0.06, 1.8, 10), frame, -4.6, 4.1, -10.0);
  add(new THREE.ConeGeometry(0.55, 0.6, 20, 1, true), plastic(0xffd9a8, { emissive: 0xffa040, emissiveIntensity: 0.8 }), -4.6, 5.1, -9.8);
  const chair = new THREE.Group(); chair.position.set(-7.0, 0, -6.6); scene.add(chair);
  const red = plastic(0xd8262c, { roughness: 0.4 }), blk = plastic(0x18181c, { roughness: 0.45 });
  for (const [g, m, x, y, z] of [[rbox(2.2, 0.5, 2.1, 0.2), blk, 0, 2.0, 0], [rbox(2.2, 3.6, 0.5, 0.2), red, 0, 3.9, 0.95], [rbox(1.4, 2.6, 0.55, 0.2), blk, 0, 3.8, 1.0], [new THREE.CylinderGeometry(0.15, 0.15, 1.6, 10), blk, 0, 1.0, 0]]) { const mm = new THREE.Mesh(g, m); mm.position.set(x, y, z); mm.castShadow = mm.receiveShadow = true; chair.add(mm); }
  for (let k = 0; k < 5; k++) { const a = k / 5 * Math.PI * 2; const leg = new THREE.Mesh(rbox(0.25, 0.15, 1.3, 0.05), blk); leg.position.set(Math.sin(a) * 0.6, 0.2, Math.cos(a) * 0.6); leg.rotation.y = a; chair.add(leg); }
  for (const s of [-1, 1]) { const arm = new THREE.Mesh(rbox(0.3, 0.25, 1.6, 0.08), red); arm.position.set(s * 1.15, 3.0, 0.1); chair.add(arm); }

  // closet (right wall, z -8..-2): dark inside, two doors hinged at the outer edges
  const IN = 12.0;
  add(new THREE.BoxGeometry(3.0, 10, 6), new THREE.MeshStandardMaterial({ color: 0x2a2630, roughness: 1, side: THREE.BackSide }), 14.5, 5, -5);
  add(rbox(0.3, 0.3, 6.4, 0.04), white, 13.0, 10.1, -5);
  const doorM = plastic(0xf6f6f8, { roughness: 0.4, clearcoat: 0.3, map: tex((() => { const c = canvas(256, 512), x = c.getContext('2d'); x.fillStyle = '#f6f6f8'; x.fillRect(0, 0, 256, 512); x.strokeStyle = 'rgba(0,0,0,0.14)'; x.lineWidth = 6; x.strokeRect(26, 26, 204, 200); x.strokeRect(26, 270, 204, 216); return c; })()) });
  const knob = plastic(0xc0c4cc, { metalness: 0.8, roughness: 0.25 });
  const closetDoors = [-1, 1].map((s) => { // s=-1 → hinge at z=-8, s=+1 → hinge at z=-2
    const piv = new THREE.Group(); piv.position.set(13.0, 0, s < 0 ? -8 : -2); scene.add(piv);
    const d = new THREE.Mesh(rbox(0.22, 9.9, 2.98, 0.04), doorM); d.position.set(-0.05, 4.95, s < 0 ? 1.5 : -1.5); d.castShadow = d.receiveShadow = true; piv.add(d);
    const k = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 8), knob); k.position.set(-0.25, 4.6, s < 0 ? 2.75 : -2.75); piv.add(k);
    return { piv, s };
  });
  // bedroom door (right wall, z 3.5..7.5), hinge at z = 7.5
  const bdPiv = new THREE.Group(); bdPiv.position.set(13.0, 0, 7.5); scene.add(bdPiv);
  const bdoor = new THREE.Mesh(rbox(0.3, 9.4, 3.96, 0.05), wood); bdoor.position.set(0, 4.7, -1.98); bdoor.castShadow = bdoor.receiveShadow = true; bdPiv.add(bdoor);
  const bkHandle = new THREE.Group(); bkHandle.position.set(-0.32, 4.4, -3.45); bdPiv.add(bkHandle); const lever = new THREE.Mesh(rbox(0.16, 0.16, 0.95, 0.06), knob); lever.position.z = 0.4; bkHandle.add(lever); const rose = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.08, 16), knob); rose.rotation.z = Math.PI / 2; bkHandle.add(rose);
  const hallGlow = new THREE.Mesh(new THREE.PlaneGeometry(4, 9.5), new THREE.MeshBasicMaterial({ color: 0xffc98a, toneMapped: false })); hallGlow.position.set(14.2, 4.75, 5.5); hallGlow.rotation.y = -Math.PI / 2; scene.add(hallGlow);

  // wall art + LED strip + rug
  const art = (kind, x, y, z, ry) => { add(rbox(2.5, 3.4, 0.12, 0.03), frame, x, y, z, ry); const p = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 3.05), new THREE.MeshStandardMaterial({ map: tex(poster(kind)), roughness: 0.6 })); p.position.set(x + Math.sin(ry) * 0.08, y, z + Math.cos(ry) * 0.08); p.rotation.y = ry; scene.add(p); };
  art('rocket', 9.8, 8, -10.9, 0); art('dino', -12.9, 11.2, 4.5, Math.PI / 2); art('palm', 13.0, 8.2, 0.9, -Math.PI / 2);
  const ledM = new THREE.MeshBasicMaterial({ color: 0xb04dff, toneMapped: false });
  add(new THREE.BoxGeometry(25.5, 0.12, 0.12), ledM, 0, 14.6, -10.9).castShadow = false;
  add(new THREE.BoxGeometry(0.12, 0.12, 21.5), ledM, -12.9, 14.6, 0).castShadow = false;
  const rug = add(new THREE.CylinderGeometry(4.6, 4.6, 0.06, 48), fabric(0x3d66d8), 1.5, 0.03, 2.5); rug.castShadow = false;
  const plant = new THREE.Group(); plant.position.set(10.5, 0, -9.6); scene.add(plant);
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.45, 1.2, 20), plastic(0xd98a5a)); pot.position.y = 0.6; plant.add(pot);
  for (let i = 0; i < 9; i++) { const a = i / 9 * 6.28; const l = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 8), plastic(0x2e7d3a, { roughness: 0.6 })); l.scale.set(0.45, 1.6, 0.2); l.position.set(Math.cos(a) * 0.4, 1.9 + (i % 3) * 0.3, Math.sin(a) * 0.4); l.rotation.set(Math.sin(a) * 0.6, a, Math.cos(a) * 0.6); plant.add(l); }
  plant.traverse((o) => { if (o.isMesh) o.castShadow = o.receiveShadow = true; });

  const junk = makeJunk(scene);

  const S = {
    scene, hemi, moon, lamp, screen, ceiling, hallway, heads, glares, chair, closetDoors, bedroomDoor: bdPiv, doorHandle: bkHandle, hallGlow, junk,
    /** car headlights: u 0..1 = the car rolls into the driveway left→right and stops; on 0..1 */
    setHeadlights(u, on = 1) {
      const x = lerp(-40, 6, E.out(clamp(u))), z = -34;
      heads.forEach((s, k) => {
        s.position.set(x + k * 2.2, 4.4, z); s.target.position.set(x * 0.15 + 2 + k * 2.2, 3.2, 6); s.intensity = 520 * on;
        glares[k].position.set(x + k * 2.2, 4.4, z + 1.6); glares[k].material.opacity = on; glares[k].visible = on > 0.01;
      });
      car.visible = on > 0.01 || u > 0; car.position.set(x + 1.1, 0, z - 3.2);
    },
    setCloset(open) { closetDoors.forEach(({ piv, s }) => { piv.rotation.y = s < 0 ? -open * 1.9 : open * 1.9; }); },
    setDoor(open, hall = 0) { bdPiv.rotation.y = open * 1.6; hallway.intensity = hall * 140; hallGlow.visible = open > 0.02; },
    setRoomLight(on) { ceiling.intensity = on * 70; hemi.intensity = lerp(0.32, 0.9, on); hemi.color.set(0x6f7fd8).lerp(new THREE.Color(0xfff4ea), on); },
    /** junk: mode 'mess' | 'closet' | 'heap'; for transitions pass from/to + progress per item */
    poseJunk(fn) { junk.forEach((it, i) => { const p = fn(it, i); it.mesh.visible = p.visible ?? true; it.mesh.position.set(...p.p); it.mesh.rotation.set(...p.r); }); },
    reset() {
      this.setHeadlights(0, 0); car.visible = false; this.setCloset(0); this.setDoor(0, 0); this.setRoomLight(0); chair.rotation.y = 0; bkHandle.rotation.set(0, 0, 0);
      this.poseJunk((it) => it.mess);
    },
  };
  return S;
}
