// All sets + the family + props. world.use(set) moves the cast (and the camera key light) into that set's scene.
import * as THREE from 'three';
import { buildKitchen, COUNTER } from './sets/kitchen.js';
import { buildBedroom } from './sets/bedroom.js';
import { buildCast } from './chars/cast.js';
import { makeSlice, makePizzaBox, makeWholePizza, makeSparkles } from './props/props.js';

export async function buildWorld(renderer) {
  const k = buildKitchen(renderer);
  const bed = buildBedroom(renderer);
  const cast = buildCast();
  const box = makePizzaBox(); box.rotation.y = -Math.PI / 2; k.scene.add(box);
  const slice = makeSlice(); k.scene.add(slice);
  const pizza = makeWholePizza(); k.scene.add(pizza);
  const sparkles = makeSparkles(7); k.scene.add(sparkles);
  const key = new THREE.DirectionalLight(0xffffff, 0); // soft camera-side key so faces read in any light
  const sets = { kitchen: { ...k, keyDefault: 0 }, bedroom: { ...bed, keyDefault: 1.3, keyColor: 0xdfe6ff } };
  const W = { ...k, sets, cast, box, slice, pizza, sparkles, key, COUNTER, bedroom: bed, kitchen: k };
  W.use = (name) => {
    const s = sets[name];
    for (const a of Object.values(cast)) if (a.root.parent !== s.scene) s.scene.add(a.root);
    if (key.parent !== s.scene) { s.scene.add(key); s.scene.add(key.target); }
    W.active = name; W.scene = s.scene; W.set = s;
  };
  W.reset = () => {
    for (const a of Object.values(cast)) { a.root.visible = false; if (a.shades) a.shades.visible = false; if (a.cane) a.cane.rotation.set(0, 0, 0); }
    box.visible = true; box.position.set(0, COUNTER, 0.3); box.rotation.set(0, -Math.PI / 2, 0);
    if (slice.parent !== k.scene) k.scene.add(slice);
    slice.visible = true; slice.position.set(0.15, COUNTER + 0.06, 0.45); slice.rotation.set(0, 0.5, 0); slice.scale.setScalar(1); slice.userData.shine.material.opacity = 0;
    sparkles.visible = false; k.setOven(0, 0); pizza.visible = true;
    bed.reset();
  };
  W.use('kitchen');
  return W;
}
