// Film router: ?film=pizza | car (default: the newest). Each film module exports build<Name>(W) → shots[].
import { blinkAt } from './chars/avatar.js';
import { buildPizza } from './films/pizza.js';
import { buildCar } from './films/car.js';

const FILMS = { pizza: buildPizza, car: buildCar };
export function buildShots(W) {
  const q = new URLSearchParams(location.search);
  return (FILMS[q.get('film') || 'car'])(W);
}

export function buildLab(W, which) {
  const set = which === 'bedroom' ? 'bedroom' : 'kitchen';
  const lineup = (lt, ry = 0) => {
    const xs = { lilbro: -6.0, lilsis: -3.4, mom: 0.0, dad: 3.4, granny: 6.6 };
    for (const [k, a] of Object.entries(W.cast)) a.pose({ x: xs[k] ?? 0, z: set === 'bedroom' ? 2 : 5.5, ry, face: { expr: 'happy', blink: blinkAt(lt, k.length) } });
  };
  const z = set === 'bedroom' ? 2 : 5.5;
  const shots = [
    { id: 'L1', set, start: 0, note: 'lineup front', setup: (W, lt) => { lineup(lt); return { cam: { pos: [0, 4.2, z + 17], look: [0, 3.0, z], fov: 42 }, look: { focus: 17, aper: 0.03 } }; } },
    { id: 'L2', set, start: 1, note: 'faces', setup: (W, lt) => { lineup(lt, 0); return { cam: { pos: [0, 4.6, z + 7], look: [0, 4.4, z], fov: 50 }, look: { focus: 7, aper: 0.03 } }; } },
    { id: 'L3', set, start: 2, note: 'set wide', setup: () => ({ cam: { pos: set === 'bedroom' ? [9, 9, 10] : [0, 7, 22], look: set === 'bedroom' ? [-2, 3, -4] : [0, 4, -4], fov: 64 }, look: { focus: 14, aper: 0.02 } }) },
  ];
  shots.cues = []; shots[shots.length - 1].end = 3;
  return shots;
}
