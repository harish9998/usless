// Canvas-painted textures (no image files): wood planks, marble, clothing prints, window view.
import * as THREE from 'three';
import { hash } from './util.js';

export function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
export function tex(c, { repeat = [1, 1], srgb = true, aniso = 8 } = {}) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat); t.anisotropy = aniso;
  return t;
}
const rnd = (i) => hash(i * 7.31 + 0.17);

/** warm wood planks, long boards along x */
export function woodPlanks(size = 1024) {
  const c = canvas(size, size), x = c.getContext('2d');
  const rows = 8, rh = size / rows;
  for (let r = 0; r < rows; r++) {
    let px = -rnd(r) * size * 0.6, k = 0;
    while (px < size) {
      const len = size * (0.45 + rnd(r * 31 + k) * 0.5);
      const base = 0.82 + rnd(r * 13 + k * 7) * 0.22;
      const col = [154 * base, 104 * base, 68 * base];
      x.fillStyle = `rgb(${col.map((v) => Math.round(v)).join(',')})`; x.fillRect(px, r * rh, len, rh);
      // grain
      for (let g = 0; g < 26; g++) {
        const gy = r * rh + rnd(r * 97 + k * 11 + g) * rh, a = 0.04 + rnd(g + k) * 0.06;
        x.strokeStyle = `rgba(60,34,18,${a})`; x.lineWidth = 1 + rnd(g * 3 + k) * 2;
        x.beginPath(); x.moveTo(px, gy); x.bezierCurveTo(px + len * 0.3, gy + (rnd(g) - 0.5) * 6, px + len * 0.7, gy + (rnd(g + 1) - 0.5) * 6, px + len, gy); x.stroke();
      }
      x.fillStyle = 'rgba(40,22,10,0.55)'; x.fillRect(px, r * rh, 2, rh);
      px += len; k++;
    }
    x.fillStyle = 'rgba(40,22,10,0.5)'; x.fillRect(0, r * rh, size, 2);
  }
  return c;
}

/** white marble with soft grey veins */
export function marble(size = 1024) {
  const c = canvas(size, size), x = c.getContext('2d');
  x.fillStyle = '#f3f2ef'; x.fillRect(0, 0, size, size);
  for (let v = 0; v < 14; v++) {
    let px = rnd(v) * size, py = rnd(v + 50) * size, ang = rnd(v + 9) * Math.PI;
    x.strokeStyle = `rgba(120,120,128,${0.08 + rnd(v + 3) * 0.14})`; x.lineWidth = 1 + rnd(v + 4) * 3;
    x.beginPath(); x.moveTo(px, py);
    for (let s = 0; s < 40; s++) { ang += (rnd(v * 100 + s) - 0.5) * 0.7; px += Math.cos(ang) * 22; py += Math.sin(ang) * 22; x.lineTo(px, py); }
    x.stroke();
  }
  return c;
}

/** outdoor view for the big windows: sky, clouds, trees, hedge (blurred by DOF anyway) */
export function windowView(w = 2048, h = 1024) {
  const c = canvas(w, h), x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#3f9ee8'); g.addColorStop(0.55, '#8fd0ff'); g.addColorStop(1, '#d9f1ff');
  x.fillStyle = g; x.fillRect(0, 0, w, h);
  for (let k = 0; k < 16; k++) { // clouds
    const cx = rnd(k + 300) * w, cy = h * (0.08 + rnd(k + 301) * 0.3), s = 40 + rnd(k + 302) * 90;
    x.fillStyle = 'rgba(255,255,255,0.85)';
    for (let b = 0; b < 6; b++) { x.beginPath(); x.arc(cx + (b - 3) * s * 0.55, cy + Math.sin(b * 1.7) * s * 0.2, s * (0.5 + rnd(k * 9 + b) * 0.4), 0, 7); x.fill(); }
  }
  // far trees
  for (let k = 0; k < 60; k++) {
    const tx = rnd(k + 500) * w, th = h * (0.25 + rnd(k + 501) * 0.3), tw = 60 + rnd(k + 502) * 90, base = h * 0.8;
    const pine = rnd(k + 503) > 0.55;
    x.fillStyle = `hsl(${105 + rnd(k + 504) * 30}, ${45 + rnd(k) * 20}%, ${24 + rnd(k + 505) * 16}%)`;
    if (pine) { x.beginPath(); x.moveTo(tx, base - th); x.lineTo(tx - tw * 0.6, base); x.lineTo(tx + tw * 0.6, base); x.fill(); }
    else { for (let b = 0; b < 5; b++) { x.beginPath(); x.arc(tx + (rnd(k * 7 + b) - 0.5) * tw, base - th * (0.45 + rnd(k * 5 + b) * 0.5), tw * 0.42, 0, 7); x.fill(); } }
  }
  // lawn + hedge
  x.fillStyle = '#5aa53a'; x.fillRect(0, h * 0.8, w, h * 0.2);
  x.fillStyle = '#3d7d2a'; x.fillRect(0, h * 0.78, w, h * 0.04);
  // grey slatted fence far away
  x.fillStyle = '#8e939a'; x.fillRect(0, h * 0.7, w, h * 0.09);
  x.fillStyle = 'rgba(255,255,255,0.18)'; for (let y = h * 0.7; y < h * 0.79; y += 9) x.fillRect(0, y, w, 2);
  return c;
}

/** clothing print helpers: draw into a canvas sized for a box face */
export function star(x, cx, cy, r, col = '#ffffff') {
  x.fillStyle = col; x.beginPath();
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; x.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); }
  x.closePath(); x.fill();
}
export function heart(x, cx, cy, s, col = '#ffffff') {
  x.fillStyle = col; x.beginPath();
  x.moveTo(cx, cy + s * 0.9);
  x.bezierCurveTo(cx - s * 1.4, cy + s * 0.05, cx - s * 0.75, cy - s * 0.95, cx, cy - s * 0.35);
  x.bezierCurveTo(cx + s * 0.75, cy - s * 0.95, cx + s * 1.4, cy + s * 0.05, cx, cy + s * 0.9);
  x.fill();
}
export function daisy(x, cx, cy, r, petal = '#ffffff', mid = '#f7c531') {
  x.fillStyle = petal;
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; x.beginPath(); x.ellipse(cx + Math.cos(a) * r * 0.55, cy + Math.sin(a) * r * 0.55, r * 0.42, r * 0.26, a, 0, 7); x.fill(); }
  x.fillStyle = mid; x.beginPath(); x.arc(cx, cy, r * 0.28, 0, 7); x.fill();
}
/** fabric with scattered flowers */
export function floral(w, h, bg, petal, mid, n = 16, r = 22, seed = 1) {
  const c = canvas(w, h), x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, w, h);
  for (let i = 0; i < n; i++) daisy(x, rnd(seed * 50 + i) * w, rnd(seed * 50 + i + 0.5) * h, r * (0.8 + rnd(i + seed) * 0.5), petal, mid);
  return c;
}
/** soft fabric shading: darker seams at the edges so boxes read as clothes */
export function seams(x, w, h, a = 0.18) {
  const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, `rgba(0,0,0,0)`); g.addColorStop(0.85, `rgba(0,0,0,0)`); g.addColorStop(1, `rgba(0,0,0,${a})`);
  x.fillStyle = g; x.fillRect(0, 0, w, h);
}
